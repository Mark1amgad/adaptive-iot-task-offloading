ABDO DATASET HANDOFF PACKAGE

Read in this order:
1. MARK_RESEARCH_SPECIFICATION_V2.md — controlling research design and full/partial action semantics.
2. ABDO_FINAL_DATASET_SPECIFICATION_V2.md — exact dataset-workstream requirements and acceptance criteria.
3. ECW_TECHNICAL_AUDIT.md — verified facts and limitations for ECW.
4. SMD_TECHNICAL_AUDIT.md — verified facts and limitations for SMD.
5. TASK_OFFLOADING_FEATURE_COVERAGE.md — source coverage vs. required offloading fields.
6. DATASET_SUITABILITY_AND_INTEGRATION.md — why ECW/SMD cannot serve as direct task-offloading datasets and how they may be used cautiously.
7. Dataset_Research_Feasibility_Review.zip — Mostafa's provenance inventory, for reference only; do not duplicate his inventory work.
8. ABDO_EXECUTION_PROMPT.md — full implementation prompt.

The current repository and its existing team-work/Astta-Abdo folder remain the source of truth for existing code and prior audit outputs. This package is a focused handoff, not a replacement for repository history or existing files.

IMPORTANT BOUNDARY:
Abdo's deliverable is the synthetic workload input generator, task/scenario data, schemas, validation, and documentation. It is not the final simulator-measured experimental outcomes dataset. Decisions, execution traces, completion times, latency, deadline success, resource outcomes, and valid energy measurements must come from iFogSim2 integration and actual simulation runs. Do not fabricate them.
