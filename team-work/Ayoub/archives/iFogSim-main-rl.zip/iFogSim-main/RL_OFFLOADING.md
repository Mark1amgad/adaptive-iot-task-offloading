# ربط iFogSim2 مع موديل Q-Learning (Local / Edge / Cloud)

> **الحالة:** الكود اتكتب واتعمله compile فقط. **ماتشغّلش في simulation ولا اتختبر.** كل الافتراضات تحت محتاجة مراجعة قبل الاعتماد على أي نتيجة.

## اللي اتغيّر في المشروع
| ملف | التغيير |
|---|---|
| `src/org/fog/offloading/RLClient.java` (جديد) | بيشغّل عملية بايثون ويكلمها بسطور JSON (timeout + قراءة stderr). |
| `src/org/fog/offloading/RLOffloadingManager.java` (جديد) | بيبني الـ observation، ويطبّق الـ action، ويبعت الـ outcome، ويقفل العملية. |
| `src/org/fog/entities/FogDevice.java` | إضافة hook في `processTupleArrival` وhook في `checkCloudletCompletion` + 4 دوال مساعدة `rl*`. |
| `src/org/fog/placement/Controller.java` | سطر واحد في `STOP_SIMULATION` بيقفل الجلسة ويحفظ الموديل. |
| `rl_model/` (جديد) | مجلد الموديل بايثون كامل (الكود، config، docs). |

**مطفي افتراضياً:** من غير `-Drl.enabled=true` كل الـ hooks مابتعملش حاجة، والمحاكاة بتشتغل زي الأول بالظبط.

## التشغيل
متطلبات: Python 3.10+ على الجهاز (الموديل مش محتاج مكتبات خارجية).

أضف خيارات الـ JVM لأي مثال (Eclipse/IntelliJ: VM options):
```
-Drl.enabled=true -Drl.mode=train -Drl.runId=train-seed1 -Drl.phase=train -Drl.simSeed=1 -Drl.modelOut=rl_model/artifacts/train_seed1.json -Drl.deadlineMs=500
```
- **Train:** `-Drl.mode=train` (استكشاف ε-greedy + تعلّم). لمتابعة تدريب: `-Drl.modelIn=...`.
- **تقييم:** `-Drl.mode=eval -Drl.modelIn=... -Drl.phase=test` (موديل متجمّد).
- **Baseline:** `-Drl.mode=baseline -Drl.policy=local|edge|cloud|random -Drl.phase=test`.
- باقي الخيارات: `rl.python` (الافتراضي `python`)، `rl.home` (الافتراضي `rl_model`، نسبةً لمجلد التشغيل)، `rl.timeoutMs` (10000)، `rl.agentSeed`، `rl.reportPendingAsFailed=true`.
- شغّل الـ JVM من مجلد المشروع الرئيسي عشان `rl_model` يتلاقى.
- النتائج بتتكتب في `rl_model/logs/run_<runId>.jsonl`، والمقارنة: `python -m rl_model.aggregate logs/run_*.jsonl` (راجع `rl_model/docs/WORKFLOWS.md`).

## إزاي القرار بيتطبّق
القرار بيتاخد لكل tuple جاي من **Sensor** لأول جهاز يوصله (gateway / mobile):

| Action | اللي بيحصل |
|---|---|
| **Local** | بيكمّل المعالجة العادية على نفس الجهاز. |
| **Edge** | `sendUp(tuple)` للجهاز الأب (بنموذج الـ link الأصلي: queue وbandwidth وlatency). |
| **Cloud** | إرسال مباشر لأعلى الشجرة، بجمع (latency + حجم/bandwidth) لكل hop. |

- الـ action بيتحط في الـ mask بس لو الجهاز المستهدف **فيه نسخة من الـ module** المطلوب. لو أقل من خيارين متاحين، الموديل مابيتدخلش وبيشتغل الـ placement الأصلي.
- **عشان يبقى فيه اختيار حقيقي** لازم الـ module الأول يتحط على أكتر من طبقة، مثلاً بـ `ModuleMapping.addModuleToDevice(moduleName, deviceName)` مع `ModulePlacementMapping` لجهاز الـ gateway وجهاز الـ edge والـ cloud.
- لو الأب هو الـ cloud نفسه (طبقتين)، الـ Edge بيتشال من الـ mask.

## الـ observation (قبل التنفيذ) والـ outcome (بعد التنفيذ)
| الحقل | المصدر في الكود |
|---|---|
| `task_mi` | `tuple.getCloudletLength()` |
| `wan_latency_ms` | مجموع `getUplinkLatency()` من الجهاز لأعلى الشجرة |
| `edge_utilization` | `rlCpuUtilization()` للجهاز الأب لحظة القرار |
| `deadline_ms` | **ثابت** من `-Drl.deadlineMs` (iFogSim مفيهوش deadline للـ tuple) |
| `latency_ms` (outcome) | `CloudSim.clock()` عند اكتمال التنفيذ − لحظة القرار |
| `bandwidth_bytes` | `getCloudletFileSize()` لو اتنفّذ بره الجهاز، وصفر لو Local |
| `executing_node_utilization` | استخدام CPU للجهاز اللي نفّذ لحظة الاكتمال |
| `action_executed` | بيتحدد من الجهاز اللي نفّذ فعلاً (نفس الجهاز = Local، جهاز بدون أب = Cloud، غير كده = Edge) |

## افتراضات وحدود (لازم تتراجع)
1. وحدة الزمن في iFogSim اتعاملت كأنها **ms** (`wan_latency_ms` و`latency_ms`). تأكد من topology بتاعتكم.
2. الـ deadline ثابت لكل الـ tasks. لو عندكم deadline حقيقي لكل app أو tuple، عدّل `RLOffloadingManager.tryOffload`.
3. الـ latency بتتحسب لحد اكتمال تنفيذ **أول module فقط** (مش الـ loop كله) وبتبدأ من وصول الـ tuple للجهاز الأول (من غير زمن الـ sensor→gateway).
4. الـ Cloud بيتبعت مباشرة بحساب الـ delay، من غير طابور الـ link (`northTupleQueue`). الـ Edge بيستخدم الطابور الأصلي، فالمقارنة فيها تحيّز بسيط.
5. `energy_joules` مش بيتبعت (اختياري في config الموديل).
6. الـ tuples اللي لسه شغّالة في آخر المحاكاة بتتسجّل `unreported` (مش فاشلة) إلا لو فعّلت `-Drl.reportPendingAsFailed=true`. الـ tuples اللي iFogSim بيرميها بدون ما تكمل بتتحسب نفس الشكل.
7. مسارات الـ mobility/clustering/microservices ما اتفحصتش.
8. الـ thresholds اللي علامتها `placeholder` في `rl_model/config/default.json` لازم تتظبط من الـ workload الحقيقي (راجع `rl_model/docs/BLOCKERS.md`).
9. أي خطأ أو timeout من بايثون: الكود بيرجع للسلوك الأصلي لـ iFogSim، وبعد 3 أخطاء I/O متتالية بيقفل الـ RL.
10. `Controller` بيعمل `System.exit(0)` عند `STOP_SIMULATION`؛ عشان كده الإغلاق بيتم قبله وكمان بـ shutdown hook.
