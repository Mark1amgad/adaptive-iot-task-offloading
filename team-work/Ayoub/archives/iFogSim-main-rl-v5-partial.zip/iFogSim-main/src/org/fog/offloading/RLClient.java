package org.fog.offloading;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Persistent child process speaking the rl_model JSON-lines protocol (see rl_model/docs/PROTOCOL.md).
 * One request line -> exactly one reply line. stdout carries only protocol messages; stderr is drained.
 */
public final class RLClient {
    private static final String EOF = "\u0000EOF";

    private final Process process;
    private final BufferedWriter writer;
    private final BlockingQueue<String> replies = new LinkedBlockingQueue<String>();
    private final long timeoutMs;
    private boolean closed = false;

    public RLClient(List<String> command, File workDir, Map<String, String> extraEnv, long timeoutMs) throws IOException {
        this.timeoutMs = timeoutMs;
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(workDir);
        pb.environment().putAll(extraEnv);
        this.process = pb.start();
        this.writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
        final BufferedReader out = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
        final BufferedReader err = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8));
        Thread t1 = new Thread(new Runnable() {
            public void run() {
                try {
                    String line;
                    while ((line = out.readLine()) != null) replies.add(line);
                } catch (IOException ignored) {
                } finally {
                    replies.add(EOF);
                }
            }
        }, "rl-python-stdout");
        Thread t2 = new Thread(new Runnable() {
            public void run() {
                try {
                    String line;
                    while ((line = err.readLine()) != null) System.err.println("[rl-python] " + line);
                } catch (IOException ignored) {
                }
            }
        }, "rl-python-stderr");
        t1.setDaemon(true);
        t2.setDaemon(true);
        t1.start();
        t2.start();
    }

    /** Sends one JSON line (must not contain a newline) and returns the single reply line. */
    public synchronized String request(String jsonLine) throws IOException {
        if (closed) throw new IOException("rl client closed");
        if (jsonLine.indexOf('\n') >= 0) throw new IOException("message contains newline");
        writer.write(jsonLine);
        writer.write('\n');
        writer.flush();
        String reply;
        try {
            reply = replies.poll(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("interrupted while waiting for the rl process");
        }
        if (reply == null) throw new IOException("timeout (" + timeoutMs + " ms) waiting for the rl process");
        if (EOF.equals(reply)) throw new IOException("rl process ended (exit code " + safeExit() + ")");
        return reply;
    }

    private String safeExit() {
        try {
            return String.valueOf(process.exitValue());
        } catch (IllegalThreadStateException e) {
            return "still running";
        }
    }

    public synchronized void close() {
        if (closed) return;
        closed = true;
        try {
            writer.close();               // stdin EOF -> python saves the model and exits
        } catch (IOException ignored) {
        }
        try {
            if (!process.waitFor(10, TimeUnit.SECONDS)) process.destroyForcibly();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            process.destroyForcibly();
        }
    }
}
