package org.fog.offloading;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.fog.entities.FogDevice;
import org.fog.entities.Tuple;
import org.fog.utils.FogEvents;
import org.fog.utils.FogUtils;
import org.fog.utils.NetworkUsageMonitor;

/**
 * Partial (divisible-task) offloading: one task is split into a LOCAL branch and a REMOTE branch (Edge or Cloud) that
 * run concurrently. DISABLED by default (-Drl.partial.enabled=true to switch it on); nothing changes when it is off.
 *
 * The split is applied AFTER the agent has decided (it does not change the agent, its state, its reward or the protocol):
 *   decided EDGE  -> Local + Edge  split,      decided CLOUD -> Local + Cloud split,      decided LOCAL -> unchanged.
 *
 * Timeline of one task (all times are simulation clock, same units as the rest of iFogSim):
 *   decision ──partition──▶ [ local branch executes on the entry device                                   ]──┐
 *                           [ remote branch: uplink hops (queues) ─▶ executes on Edge/Cloud ─▶ result back ]──┴─▶ merge ─▶ FINAL
 *   FINAL = max(local branch finish, remote result arrival) + mergeTime.   That single FINAL instant is the task's
 *   completion time: it is what the outcome (latency_ms, deadline_met) reports to the agent. One outcome per task.
 *
 * What is modelled with real simulator mechanics: the local branch (CPU of the entry device), the remote branch's uplink
 * (the normal link queues and bandwidth, hop by hop) and its CPU on the remote device.
 * What is modelled analytically (a delay, no CPU/queue contention): partitioning, the result's trip back, merging.
 *
 * Options (all optional):
 *   rl.partial.enabled        true|false                                  (default false)
 *   rl.partial.ratios         remote share(s): 0.25, 0.5, 0.75 (comma list, cycled per split task; default 0.5)
 *   rl.partial.targets        which decided actions get split: Edge,Cloud (default both)
 *   rl.partial.minMi          tasks shorter than this are not divisible (default 0; always >= 2 MI needed)
 *   rl.partial.partitionBaseMs / rl.partial.partitionPerMi   partition time = base + perMi * MI     (defaults 0.5 / 0.0005)
 *   rl.partial.mergeBaseMs     / rl.partial.mergePerMi       merge time     = base + perMi * MI     (defaults 0.5 / 0.0005)
 *   rl.partial.resultRatio     result size = ratio * remote branch input size (default 0.1)
 */
final class PartialOffloader {
    static final double[] ALLOWED = {0.25, 0.5, 0.75};

    private final double[] ratios;
    private final boolean splitEdge, splitCloud;
    private final double minMi, partitionBaseMs, partitionPerMi, mergeBaseMs, mergePerMi, resultRatio;
    private int cursor = 0;
    private PrintWriter csv;
    private final File csvFile;

    /** One split task, from decision to merge. */
    static final class Task {
        Tuple parent, localChild, remoteChild;
        FogDevice entry, target, remoteNode;
        int action;                       // decided action (1 = Edge, 2 = Cloud)
        double ratio, localMi, remoteMi, resultBytes, partitionMs, mergeMs;
        double generation, decision = Double.NaN, partitionDone = Double.NaN, localFinish = Double.NaN,
                remoteSend = Double.NaN, remoteFinish = Double.NaN, resultArrival = Double.NaN,
                mergeStart = Double.NaN, mergeDone = Double.NaN;
        boolean localDone, resultArrived, mergeScheduled;
    }

    private final Map<Integer, Task> byBranch = new HashMap<Integer, Task>();   // branch cloudlet id -> task
    private long started = 0, merged = 0, routingWrong = 0;
    private double finalSum = 0, localSum = 0, remoteSum = 0;
    private final long[] mergedByRatio = new long[ALLOWED.length];

    private PartialOffloader(double[] ratios, boolean edge, boolean cloud, File csvFile) {
        this.ratios = ratios;
        this.splitEdge = edge;
        this.splitCloud = cloud;
        this.csvFile = csvFile;
        minMi = Double.parseDouble(System.getProperty("rl.partial.minMi", "0"));
        partitionBaseMs = Double.parseDouble(System.getProperty("rl.partial.partitionBaseMs", "0.5"));
        partitionPerMi = Double.parseDouble(System.getProperty("rl.partial.partitionPerMi", "0.0005"));
        mergeBaseMs = Double.parseDouble(System.getProperty("rl.partial.mergeBaseMs", "0.5"));
        mergePerMi = Double.parseDouble(System.getProperty("rl.partial.mergePerMi", "0.0005"));
        resultRatio = Double.parseDouble(System.getProperty("rl.partial.resultRatio", "0.1"));
    }

    /** Null when partial offloading is off (or misconfigured: then a message says why and the default behaviour is kept). */
    static PartialOffloader fromProperties(File csvFile) {
        if (!Boolean.getBoolean("rl.partial.enabled")) return null;
        try {
            String[] parts = System.getProperty("rl.partial.ratios", "0.5").split(",");
            double[] r = new double[parts.length];
            for (int i = 0; i < parts.length; i++) {
                r[i] = Double.parseDouble(parts[i].trim());
                boolean ok = false;
                for (double a : ALLOWED) if (Math.abs(a - r[i]) < 1e-9) ok = true;
                if (!ok) throw new IllegalArgumentException("rl.partial.ratios must be from {0.25, 0.5, 0.75}, got " + parts[i].trim());
            }
            String targets = System.getProperty("rl.partial.targets", "Edge,Cloud").toLowerCase(Locale.ROOT);
            boolean edge = targets.contains("edge"), cloud = targets.contains("cloud");
            if (!edge && !cloud) throw new IllegalArgumentException("rl.partial.targets must contain Edge and/or Cloud");
            PartialOffloader p = new PartialOffloader(r, edge, cloud, csvFile);
            System.err.println("[rl-partial] ENABLED ratios=" + System.getProperty("rl.partial.ratios", "0.5")
                    + " targets=" + (edge ? "Edge " : "") + (cloud ? "Cloud" : "")
                    + " partition=" + p.partitionBaseMs + "+" + p.partitionPerMi + "*MI"
                    + " merge=" + p.mergeBaseMs + "+" + p.mergePerMi + "*MI resultRatio=" + p.resultRatio
                    + " (partition/merge/result-return cost values are ASSUMPTIONS, TO CONFIRM)");
            return p;
        } catch (RuntimeException e) {
            System.err.println("[rl-partial] DISABLED, bad option: " + e.getMessage());
            return null;
        }
    }

    /** Is this decided action + tuple split by the partial path? */
    boolean eligible(int action, Tuple tuple) {
        if (action == RLOffloadingManager.EDGE && !splitEdge) return false;
        if (action == RLOffloadingManager.CLOUD && !splitCloud) return false;
        return tuple.getCloudletLength() >= Math.max(2.0, minMi);
    }

    boolean isBranch(Tuple tuple) {
        return byBranch.containsKey(tuple.getCloudletId());
    }

    // ------------------------------------------------------------------ 1) partition
    void start(RLOffloadingManager m, FogDevice dev, Tuple tuple, FogDevice target, int action, double decisionTime) {
        double ratio = ratios[cursor++ % ratios.length];
        long total = tuple.getCloudletLength();
        long remoteLen = Math.min(total - 1, Math.max(1, Math.round(total * ratio)));
        long localLen = total - remoteLen;
        long fileTotal = tuple.getCloudletFileSize();
        long remoteFile = Math.max(1, Math.round(fileTotal * ratio));
        long localFile = Math.max(1, fileTotal - remoteFile);

        Task t = new Task();
        t.parent = tuple;
        t.entry = dev;
        t.target = target;
        t.action = action;
        t.ratio = ratio;
        t.localMi = localLen;
        t.remoteMi = remoteLen;
        t.resultBytes = Math.max(1.0, resultRatio * remoteFile);
        t.partitionMs = partitionBaseMs + partitionPerMi * total;
        t.mergeMs = mergeBaseMs + mergePerMi * total;
        t.generation = m.generationOf(tuple);
        t.decision = decisionTime;
        t.localChild = branchOf(tuple, localLen, localFile);
        t.remoteChild = branchOf(tuple, remoteLen, remoteFile);
        byBranch.put(t.localChild.getCloudletId(), t);
        byBranch.put(t.remoteChild.getCloudletId(), t);
        m.adjustBacklog(dev.getId(), localLen);          // each branch is counted on the device that will run it
        m.adjustBacklog(target.getId(), remoteLen);
        started++;
        dev.rlSchedule(dev.getId(), t.partitionMs, FogEvents.RL_PARTIAL_EVENT, new Object[]{"PARTITION_DONE", t});
    }

    /** Branch tuple: same application data as the parent, only length and size differ; fresh cloudlet id. */
    private static Tuple branchOf(Tuple p, long length, long fileSize) {
        Tuple c = new Tuple(p.getAppId(), FogUtils.generateTupleId(), p.getDirection(), length, p.getNumberOfPes(),
                fileSize, p.getCloudletOutputSize(), p.getUtilizationModelCpu(), p.getUtilizationModelRam(),
                p.getUtilizationModelBw());
        c.setUserId(p.getUserId());
        c.setTupleType(p.getTupleType());
        c.setDestModuleName(p.getDestModuleName());
        c.setSrcModuleName(p.getSrcModuleName());
        c.setActualTupleId(p.getActualTupleId());
        c.setSourceDeviceId(p.getSourceDeviceId());
        c.setSourceModuleId(p.getSourceModuleId());
        c.setDestinationDeviceId(p.getDestinationDeviceId());
        c.setModuleCopyMap(new HashMap<String, Integer>(p.getModuleCopyMap()));
        return c;
    }

    // ------------------------------------------------------------------ 2) events at the entry device
    void onEvent(RLOffloadingManager m, FogDevice dev, Object data) {
        Object[] d = (Object[]) data;
        String stage = (String) d[0];
        Task t = (Task) d[1];
        double now = CloudSim.clock();
        if ("PARTITION_DONE".equals(stage)) {
            t.partitionDone = now;
            t.remoteSend = now;
            // both branches leave at the same instant and run concurrently
            dev.rlSchedule(dev.getId(), 0.0, FogEvents.TUPLE_ARRIVAL, t.localChild);   // local CPU (normal path)
            dev.rlSendUp(t.remoteChild);                                                // uplink queues -> Edge / Cloud
        } else if ("RESULT_ARRIVED".equals(stage)) {
            t.resultArrival = now;
            t.resultArrived = true;
            tryMerge(dev, t);
        } else if ("MERGE_DONE".equals(stage)) {
            t.mergeDone = now;
            finishTask(m, dev, t);
        }
    }

    private void tryMerge(FogDevice dev, Task t) {
        if (!t.localDone || !t.resultArrived || t.mergeScheduled) return;
        t.mergeScheduled = true;
        t.mergeStart = CloudSim.clock();                 // = max(local finish, result arrival)
        dev.rlSchedule(dev.getId(), t.mergeMs, FogEvents.RL_PARTIAL_EVENT, new Object[]{"MERGE_DONE", t});
    }

    // ------------------------------------------------------------------ 3) a branch finished executing
    /** @return true if the tuple was a branch (handled here, the manager must not treat it as a whole task). */
    boolean onBranchCompleted(RLOffloadingManager m, FogDevice executedOn, Tuple tuple) {
        Task t = byBranch.get(tuple.getCloudletId());
        if (t == null) return false;
        double now = CloudSim.clock();
        if (tuple == t.localChild) {
            t.localFinish = now;
            t.localDone = true;
            m.adjustBacklog(t.entry.getId(), -t.localMi);
            tryMerge(t.entry, t);                         // executedOn == entry device
        } else {
            t.remoteFinish = now;
            t.remoteNode = executedOn;
            m.adjustBacklog(t.target.getId(), -t.remoteMi);
            if (executedOn.getId() != t.target.getId()) routingWrong++;
            double back = resultTransferMs(t.entry, executedOn, t.resultBytes);
            executedOn.rlSchedule(t.entry.getId(), back, FogEvents.RL_PARTIAL_EVENT, new Object[]{"RESULT_ARRIVED", t});
        }
        return true;
    }

    /** Result trip from the executing device back down to the entry device: per hop latency + bytes / downlink bandwidth. */
    private static double resultTransferMs(FogDevice entry, FogDevice from, double bytes) {
        List<FogDevice> path = new ArrayList<FogDevice>();      // entry, parent, ..., from
        FogDevice cur = entry;
        path.add(cur);
        while (cur != null && cur.getId() != from.getId() && cur.getParentId() > 0) {
            SimEntity next = CloudSim.getEntity(cur.getParentId());
            cur = (next instanceof FogDevice) ? (FogDevice) next : null;
            if (cur != null) path.add(cur);
        }
        double delay = 0;
        for (int i = path.size() - 1; i > 0; i--) {
            FogDevice parent = path.get(i), child = path.get(i - 1);
            Double lat = parent.getChildToLatencyMap().get(child.getId());
            double hop = (lat != null ? lat : child.getUplinkLatency()) + bytes / parent.getDownlinkBandwidth();
            delay += hop;
            NetworkUsageMonitor.sendingTuple(lat != null ? lat : child.getUplinkLatency(), bytes);
        }
        return delay;
    }

    /** Cloud-targeted remote branch passing through an intermediate device: forward, do not execute there. */
    boolean forwardTransit(FogDevice dev, Tuple tuple) {
        Task t = byBranch.get(tuple.getCloudletId());
        if (t == null || tuple != t.remoteChild || t.action != RLOffloadingManager.CLOUD) return false;
        if (dev.getId() == t.entry.getId() || dev.getId() == t.target.getId()) return false;
        if (dev.getParentId() <= 0) {
            System.err.println("[rl-partial] ERROR transit has no parent branch=t-" + tuple.getCloudletId() + " node=" + dev.getName());
            return true;
        }
        dev.rlSendUp(tuple);
        return true;
    }

    // ------------------------------------------------------------------ 4) merge done = the task's final completion
    private void finishTask(RLOffloadingManager m, FogDevice dev, Task t) {
        byBranch.remove(t.localChild.getCloudletId());
        byBranch.remove(t.remoteChild.getCloudletId());
        merged++;
        double fin = t.mergeDone - t.decision;
        finalSum += fin;
        localSum += t.localFinish - t.partitionDone;
        remoteSum += t.resultArrival - t.partitionDone;
        for (int i = 0; i < ALLOWED.length; i++) if (Math.abs(ALLOWED[i] - t.ratio) < 1e-9) mergedByRatio[i]++;
        writeRow(m, t);
        m.completePartial(dev, t.parent, t.action, t.remoteNode != null ? t.remoteNode : t.target,
                t.remoteChild.getCloudletFileSize() + t.resultBytes, t.remoteNode != null && t.remoteNode.getId() == t.target.getId());
    }

    // ------------------------------------------------------------------ log + summary
    private void writeRow(RLOffloadingManager m, Task t) {
        try {
            if (csv == null) {
                File dir = csvFile.getParentFile();
                if (dir != null) dir.mkdirs();
                csv = new PrintWriter(new FileWriter(csvFile));
                csv.println("task_id,action,ratio,local_mi,remote_mi,remote_node,generation,decision,partition_ms,partition_done,"
                        + "local_finish,remote_send,remote_finish,result_transfer_ms,result_arrival,merge_start,merge_ms,final_completion,"
                        + "local_branch_ms,remote_branch_ms,critical_branch,decision_to_final_ms,true_e2e_ms,"
                        + "formula_final,formula_ok");
            }
            double localBr = t.localFinish - t.partitionDone;
            double remoteBr = t.resultArrival - t.partitionDone;
            // final completion must equal max(local finish, result arrival) + merge time
            double formula = Math.max(t.localFinish, t.resultArrival) + t.mergeMs;
            csv.println(String.format(Locale.ROOT,
                    "t-%d,%s,%.2f,%.0f,%.0f,%s,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%s,%.6f,%.6f,%.6f,%b",
                    t.parent.getCloudletId(), t.action == RLOffloadingManager.EDGE ? "Edge" : "Cloud", t.ratio, t.localMi,
                    t.remoteMi, t.remoteNode != null ? t.remoteNode.getName() : "?", t.generation, t.decision,
                    t.partitionMs, t.partitionDone, t.localFinish, t.remoteSend, t.remoteFinish,
                    t.resultArrival - t.remoteFinish, t.resultArrival, t.mergeStart, t.mergeMs, t.mergeDone, localBr, remoteBr,
                    localBr >= remoteBr ? "Local" : "Remote", t.mergeDone - t.decision, t.mergeDone - t.generation, formula,
                    Math.abs(formula - t.mergeDone) < 1e-6));
            csv.flush();
        } catch (IOException e) {
            System.err.println("[rl-partial] could not write " + csvFile + ": " + e);
        }
    }

    String summary(int stillOpen) {
        String s = String.format(Locale.ROOT,
                "[rl] PARTIAL split=%d merged=%d (25%%=%d 50%%=%d 75%%=%d) unfinished_at_cutoff=%d wrong_remote_node=%d%n",
                started, merged, mergedByRatio[0], mergedByRatio[1], mergedByRatio[2], stillOpen, routingWrong);
        if (merged > 0) {
            s += String.format(Locale.ROOT,
                    "[rl] PARTIAL mean decision->final=%.2f | mean local branch=%.2f | mean remote branch (incl. result return)=%.2f | details: %s%n",
                    finalSum / merged, localSum / merged, remoteSum / merged, csvFile.getPath());
        }
        return s;
    }

    int openTasks() {
        return byBranch.size() / 2;
    }

}
