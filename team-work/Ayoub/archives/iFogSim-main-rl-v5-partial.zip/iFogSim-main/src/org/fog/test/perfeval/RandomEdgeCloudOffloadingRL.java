package org.fog.test.perfeval;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.Application;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.placement.Controller;
import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacementMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.Config;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.TimeKeeper;
import org.fog.utils.distribution.Distribution;

/**
 * Scenario for the RL offloading experiment:
 *
 *   IoT Device 1 + IoT Device 2 --> Edge Node 1 --\
 *                                                  >--> Cloud Server
 *   IoT Device 3 + IoT Device 4 --> Edge Node 2 --/
 *
 * Every IoT device has 3 sensors (small / medium / large tasks, random inter-arrival times seeded with 
 * -Drl.simSeed). The single application module "processing" is deployed on EVERY device (IoT, Edge, Cloud),
 * so each task can run Local (the IoT device), on its Edge node, or in the Cloud.
 * With -Drl.enabled=true the Q-learning agent picks one per task (see RL_OFFLOADING.md); without it,
 * iFogSim's normal flow runs every task Local.
 *
 * ALL NUMBERS BELOW ARE DEV DEFAULTS (not calibrated, not from a paper). Edge-1 -> Cloud latency is 40 ms and
 * Edge-2 -> Cloud 120 ms so that the WAN-latency feature actually varies.
 *
 * Optional JVM properties: -Dsim.time=20000 (simulated time, iFogSim clock units), -Drl.simSeed=1.
 */
public class RandomEdgeCloudOffloadingRL {
    static final String APP_ID = "offload_app";
    static final String MODULE = "processing";

    static List<FogDevice> fogDevices = new ArrayList<FogDevice>();
    static List<Sensor> sensors = new ArrayList<Sensor>();
    static List<Actuator> actuators = new ArrayList<Actuator>();

    // task classes: {name, cpuLength (MI), nwLength (bytes), min inter-arrival, max inter-arrival}
    static final Object[][] TASK_CLASSES = {
            {"TASK_S", 200, 2000, 5.0, 15.0},
            {"TASK_M", 1000, 10000, 20.0, 60.0},
            {"TASK_L", 4000, 50000, 80.0, 160.0},
    };

    public static void main(String[] args) {
        Log.printLine("Starting RandomEdgeCloudOffloadingRL...");
        try {
            Log.disable();
            Config.MAX_SIMULATION_TIME = Integer.getInteger("sim.time", 20000);
            long simSeed = Long.getLong("rl.simSeed", 1L);

            System.setProperty("topology.mode", "random");  // This standalone main always uses a random topology.
            // -Dtopology.mode=fixed (default): the original 4 IoT -> 2 Edge -> Cloud scenario below, unchanged.
            // -Dtopology.mode=random: topology + workload profile from RandomTopologyGenerator (see its javadoc).
            RandomTopologyGenerator.Topology randomTopology = null;
            if ("random".equalsIgnoreCase(System.getProperty("topology.mode", "fixed"))) {
                randomTopology = prepareRandomTopology();       // generates, checks seed sets, logs; may throw
            } else {
                System.setProperty("topology.mode", "fixed");
            }

            CloudSim.init(1, Calendar.getInstance(), false);
            FogBroker broker = new FogBroker("broker");

            Application application = (randomTopology == null)
                    ? createApplication(APP_ID, broker.getId())
                    : createApplicationFromSpec(APP_ID, broker.getId(), randomTopology);
            application.setUserId(broker.getId());

            if (randomTopology == null) {
                createTopology(broker.getId(), APP_ID, simSeed);
            } else {
                createTopologyFromSpec(broker.getId(), APP_ID, randomTopology);
            }

            ModuleMapping moduleMapping = ModuleMapping.createModuleMapping();
            for (FogDevice d : fogDevices) {
                moduleMapping.addModuleToDevice(MODULE, d.getName());   // one copy of "processing" everywhere
            }

            Controller controller = new Controller("master-controller", fogDevices, sensors, actuators);
            controller.submitApplication(application, new ModulePlacementMapping(fogDevices, application, moduleMapping));

            TimeKeeper.getInstance().setSimulationStartTime(Calendar.getInstance().getTimeInMillis());
//********************************************************************************
            //Show the IoT network topology
            org.fog.gui.example.FogGui.showTopology(fogDevices, sensors, actuators);
//********************************************************************************
            CloudSim.startSimulation();
            CloudSim.stopSimulation();
            org.fog.offloading.RLOffloadingManager.finishIfEnabled();
            Log.printLine("RandomEdgeCloudOffloadingRL finished!");
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happen");
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Random topology mode (-Dtopology.mode=random). The fixed scenario above/below is not touched.
    //   -Dtopology.seed=N      structure + per-device workload profile (default 1)
    //   -Dworkload.seed=M      sensor inter-arrival randomness (default: -Drl.simSeed, else 1)
    //   -Drl.agentSeed=K       agent RNG (Python side)
    //   -Dtopology.trainSeeds="1-20"   optional: train seeds must be inside, test seeds outside
    //   -Dtopo.*               ranges, see RandomTopologyGenerator.Config.fromSystemProperties()
    // Every run appends a line to <rl.home>/logs/topologies.jsonl (override dir with -Dtopology.logDir).
    // ------------------------------------------------------------------------------------------------
    private static RandomTopologyGenerator.Topology prepareRandomTopology() throws java.io.IOException {
        long topologySeed = Long.getLong("topology.seed", 1L);
        long workloadSeed = Long.getLong("workload.seed", Long.getLong("rl.simSeed", 1L));
        String phase = System.getProperty("rl.phase", "dev");
        if (System.getProperty("rl.runId") == null) {
            System.setProperty("rl.runId", "run-" + System.currentTimeMillis());   // same id in registry and Python log
        }
        RandomTopologyGenerator.checkSeedSets(topologySeed, phase);
        RandomTopologyGenerator.Topology topo =
                RandomTopologyGenerator.generate(topologySeed, workloadSeed, RandomTopologyGenerator.Config.fromSystemProperties());
        if (Boolean.getBoolean("rl.enabled")) {          // model-bound leakage guard (see RandomTopologyGenerator.checkModelLedger)
            String modelIn = org.fog.offloading.RLOffloadingManager.resolveOption("rl.modelIn", null);
            String modelOut = org.fog.offloading.RLOffloadingManager.resolveOption("rl.modelOut", null);
            if (modelOut == null) {
                modelOut = new java.io.File(org.fog.offloading.RLOffloadingManager.resolveOption("rl.artifactsDir",
                        new java.io.File(org.fog.offloading.RLOffloadingManager.modelHome(), "artifacts").getPath()),
                        "model_latest.json").getPath();
            }
            String refusal = RandomTopologyGenerator.checkModelLedger(System.getProperty("rl.mode", "train"), topo,
                    System.getProperty("rl.runId"), modelIn, modelOut);
            if (refusal != null) throw new IllegalStateException(refusal);
        }
        java.io.File logDir = new java.io.File(System.getProperty("topology.logDir",
                new java.io.File(System.getProperty("rl.home", "rl_model"), "logs").getPath())).getAbsoluteFile();
        RandomTopologyGenerator.record(topo, System.getProperty("rl.runId"), phase, System.getProperty("rl.agentSeed"), logDir);
        System.setProperty("topology.mode", "random");
        System.setProperty("topology.seed", String.valueOf(topologySeed));
        System.setProperty("workload.seed", String.valueOf(workloadSeed));
        System.setProperty("topology.fingerprint", topo.fingerprint);      // forwarded to the Python run log (hello.simulator)
        System.err.print("[topology] mode=random phase=" + phase + " runId=" + System.getProperty("rl.runId")
                + " agentSeed=" + System.getProperty("rl.agentSeed") + "\n[topology] " + topo.describe());
        return topo;
    }

    /** One AppEdge per sensor: iFogSim keys edges by tuple type, and task sizes differ per device in random mode. */
    private static Application createApplicationFromSpec(String appId, int userId, RandomTopologyGenerator.Topology topo) {
        Application application = Application.createApplication(appId, userId);
        application.addAppModule(MODULE, 10);
        for (RandomTopologyGenerator.SensorSpec sp : topo.sensors) {
            application.addAppEdge(sp.tupleType, MODULE, (double) sp.cpuLengthMi, (double) sp.nwLengthBytes,
                    sp.tupleType, Tuple.UP, AppEdge.SENSOR);
        }
        return application;
    }

    private static void createTopologyFromSpec(int userId, String appId, RandomTopologyGenerator.Topology topo) {
        List<FogDevice> built = new ArrayList<FogDevice>();
        for (RandomTopologyGenerator.DeviceSpec d : topo.devices) {
            FogDevice fd = createFogDevice(d.name, d.mips, d.ram, d.upBw, d.downBw, d.level, d.ratePerMips,
                    d.busyPower, d.idlePower);
            if (d.parentIndex < 0) {
                fd.setParentId(-1);
            } else {
                fd.setParentId(built.get(d.parentIndex).getId());
                fd.setUplinkLatency(d.uplinkLatency);
            }
            built.add(fd);
            fogDevices.add(fd);
        }
        for (RandomTopologyGenerator.SensorSpec sp : topo.sensors) {
            FogDevice gateway = built.get(sp.deviceIndex);
            Sensor s = new Sensor(sp.name, sp.tupleType, userId, appId,
                    new SeededUniform(sp.minInterArrival, sp.maxInterArrival, sp.arrivalSeed));
            s.setGatewayDeviceId(gateway.getId());
            s.setLatency(topo.sensorLatency);
            sensors.add(s);
        }
    }

    private static void createTopology(int userId, String appId, long simSeed) {
        FogDevice cloud = createFogDevice("cloud", 20000, 40000, 100000, 100000, 0, 0.01, 16 * 103, 16 * 83.25);
        cloud.setParentId(-1);
        fogDevices.add(cloud);

        double[] wanLatency = {40, 120};
        for (int e = 1; e <= 2; e++) {
            FogDevice edge = createFogDevice("edge-" + e, 300, 4000, 100000, 100000, 1, 0.0, 107.339, 83.4333);
            edge.setParentId(cloud.getId());
            edge.setUplinkLatency(wanLatency[e - 1]);
            fogDevices.add(edge);
            for (int k = 0; k < 2; k++) {
                int iotIndex = (e - 1) * 2 + k + 1;                       // IoT Device 1..4
                FogDevice iot = createFogDevice("iot-" + iotIndex, 100, 1000, 10000, 10000, 2, 0.0, 87.53, 82.44);
                iot.setParentId(edge.getId());
                iot.setUplinkLatency(5);
                fogDevices.add(iot);
                for (int c = 0; c < TASK_CLASSES.length; c++) {
                    Object[] tc = TASK_CLASSES[c];
                    Sensor s = new Sensor("s-" + iotIndex + "-" + tc[0], (String) tc[0], userId, appId,
                            new SeededUniform((Double) tc[3], (Double) tc[4], simSeed * 1000L + iotIndex * 10L + c));
                    s.setGatewayDeviceId(iot.getId());
                    s.setLatency(1.0);
                    sensors.add(s);
                }
            }
        }
    }

    /** Application: sensor tuple (TASK_*) -> "processing". No actuators, so there are no result tuples to route. */
    private static Application createApplication(String appId, int userId) {
        Application application = Application.createApplication(appId, userId);
        application.addAppModule(MODULE, 10);
        for (Object[] tc : TASK_CLASSES) {
            application.addAppEdge((String) tc[0], MODULE, ((Integer) tc[1]).doubleValue(),
                    ((Integer) tc[2]).doubleValue(), (String) tc[0], Tuple.UP, AppEdge.SENSOR);
        }
        return application;
    }

    private static FogDevice createFogDevice(String nodeName, long mips, int ram, long upBw, long downBw,
                                             int level, double ratePerMips, double busyPower, double idlePower) {
        List<Pe> peList = new ArrayList<Pe>();
        peList.add(new Pe(0, new PeProvisionerOverbooking(mips)));
        int hostId = FogUtils.generateEntityId();
        long storage = 1000000;
        int bw = 10000;
        PowerHost host = new PowerHost(hostId, new RamProvisionerSimple(ram), new BwProvisionerOverbooking(bw),
                storage, peList, new StreamOperatorScheduler(peList), new FogLinearPowerModel(busyPower, idlePower));
        List<Host> hostList = new ArrayList<Host>();
        hostList.add(host);
        FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics("x86", "Linux", "Xen", host,
                10.0, 3.0, 0.05, 0.001, 0.0);
        FogDevice fogdevice = null;
        try {
            fogdevice = new FogDevice(nodeName, characteristics, new AppModuleAllocationPolicy(hostList),
                    new LinkedList<Storage>(), 10, upBw, downBw, 0, ratePerMips);
        } catch (Exception e) {
            throw new RuntimeException("could not create device " + nodeName, e);
        }
        fogdevice.setLevel(level);
        return fogdevice;
    }

    /** Uniform inter-arrival times from a private seeded Random, so runs are reproducible for a given seed. */
    static class SeededUniform extends Distribution {
        private final double min, max;

        SeededUniform(double min, double max, long seed) {
            this.min = min;
            this.max = max;
            setRandom(new Random(seed));
        }

        public double getNextValue() {
            return getRandom().nextDouble() * (max - min) + min;
        }

        public int getDistributionType() {
            return Distribution.UNIFORM;
        }

        public double getMeanInterTransmitTime() {
            return (min + max) / 2;
        }
    }
}
