package org.fog.test.perfeval;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TreeSet;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * Random but reproducible Cloud -> Edge -> IoT topologies (plus per-device workload profiles) for training the
 * offloading agent on many different environments.
 *
 * This class is a pure DATA generator: it does not touch any iFogSim/CloudSim class. It produces a {@link Topology}
 * (device specs + sensor specs); EdgeCloudOffloadingRL turns it into FogDevice/Sensor objects. The original fixed
 * topology in EdgeCloudOffloadingRL is NOT generated here and is not changed (-Dtopology.mode=fixed, the default).
 *
 * THREE INDEPENDENT SEEDS (never derived from each other):
 *   topologySeed : structure (number of Edge/IoT nodes, MIPS, RAM, bandwidth, latencies) AND the workload PROFILE of
 *                  each IoT device (which task classes it emits, task sizes, mean arrival rate).
 *   workloadSeed : only the random inter-arrival times of the sensors (the same topology can be run with several
 *                  workload seeds).   [-Dworkload.seed, falls back to -Drl.simSeed]
 *   agent seed   : the Q-learning agent's RNG (-Drl.agentSeed, handled by the Python side; not used here).
 *
 * Reproducibility: every component (cloud, each edge sub-tree, the node counts) has its own java.util.Random whose seed
 * is derived from topologySeed with a SplitMix64 mix and a fixed salt. So the same topologySeed gives the same topology
 * on every machine, and changing e.g. the number of IoT nodes of edge 2 does not shift the random draws of edge 3.
 *
 * ALL RANGES ARE DEV DEFAULTS (plausible, NOT calibrated against a real deployment). Override with -Dtopo.* (see
 * {@link Config#fromSystemProperties()}). Rules that keep the topology realistic:
 *   - cloud MIPS >= cloudToEdgeMinRatio x fastest edge, edge MIPS >= edgeToIotMinRatio x fastest IoT child;
 *   - Edge->Cloud (WAN) latency range is above the IoT->Edge (LAN) range; edge uplink bandwidth >= IoT uplink;
 *   - task classes keep the names/size bins TASK_S / TASK_M / TASK_L (jitter stays inside the MI bins 500 / 2000 used by
 *     rl_model/config/edge_cloud_scenario.json).
 */
public final class RandomTopologyGenerator {

    /** v1 = first version (uniform WAN 20..150, no load caps). v2 = WAN 5..150 log-uniform, edge pressure, utilisation caps. */
    public static final String GENERATOR_VERSION = "v2";

    private RandomTopologyGenerator() {
    }

    // ============================================================================================ configuration
    public static final class Config {
        public int edgeMin = 1, edgeMax = 4;                       // number of Edge nodes
        public int iotPerEdgeMin = 1, iotPerEdgeMax = 4;           // IoT devices under each Edge node

        public double cloudMipsMin = 20000, cloudMipsMax = 50000;
        public double edgeMipsMin = 200, edgeMipsMax = 1000;
        public double iotMipsMin = 50, iotMipsMax = 250;
        public double edgeToIotMinRatio = 1.5;                     // edge MIPS >= ratio x fastest IoT child
        public double cloudToEdgeMinRatio = 5.0;                   // cloud MIPS >= ratio x fastest edge

        public double iotLatMin = 2, iotLatMax = 15;               // IoT -> Edge uplink latency (ms / clock units)
        public double wanLatMin = 5, wanLatMax = 150;              // Edge -> Cloud uplink latency (log-uniform, so near/far both occur)
        public double iotBwMin = 5000, iotBwMax = 20000;           // IoT uplink/downlink bandwidth
        public double edgeBwMin = 50000, edgeBwMax = 200000;       // Edge uplink/downlink bandwidth
        public double cloudBw = 100000;
        public double sensorLatency = 1.0;                         // sensor -> IoT latency (as in the fixed scenario)

        public double loadFactorMin = 0.5, loadFactorMax = 2.0;    // scales inter-arrival times per IoT (>1 = slower)
        public double edgePressureMin = 0.6, edgePressureMax = 2.0; // per-EDGE multiplier on the arrival RATE of its IoT children
        public double iotMaxUtil = 2.0;                            // an IoT is never offered more than this x its own MIPS
        public double edgeMaxUtil = 2.0;                           // an Edge is never offered more than this x its MIPS (if all of it went there)
        public double miJitter = 0.3;                              // task MI = base x U(1-j, 1+j)

        // inclusion probability of each task class on an IoT device (at least one class is always kept)
        public double[] classProbability = {0.9, 0.7, 0.5};

        public static Config fromSystemProperties() {
            Config c = new Config();
            c.edgeMin = (int) p("topo.edge.min", c.edgeMin);
            c.edgeMax = (int) p("topo.edge.max", c.edgeMax);
            c.iotPerEdgeMin = (int) p("topo.iotPerEdge.min", c.iotPerEdgeMin);
            c.iotPerEdgeMax = (int) p("topo.iotPerEdge.max", c.iotPerEdgeMax);
            c.cloudMipsMin = p("topo.cloudMips.min", c.cloudMipsMin);
            c.cloudMipsMax = p("topo.cloudMips.max", c.cloudMipsMax);
            c.edgeMipsMin = p("topo.edgeMips.min", c.edgeMipsMin);
            c.edgeMipsMax = p("topo.edgeMips.max", c.edgeMipsMax);
            c.iotMipsMin = p("topo.iotMips.min", c.iotMipsMin);
            c.iotMipsMax = p("topo.iotMips.max", c.iotMipsMax);
            c.edgeToIotMinRatio = p("topo.edgeToIotRatio", c.edgeToIotMinRatio);
            c.cloudToEdgeMinRatio = p("topo.cloudToEdgeRatio", c.cloudToEdgeMinRatio);
            c.iotLatMin = p("topo.iotLat.min", c.iotLatMin);
            c.iotLatMax = p("topo.iotLat.max", c.iotLatMax);
            c.wanLatMin = p("topo.wanLat.min", c.wanLatMin);
            c.wanLatMax = p("topo.wanLat.max", c.wanLatMax);
            c.iotBwMin = p("topo.iotBw.min", c.iotBwMin);
            c.iotBwMax = p("topo.iotBw.max", c.iotBwMax);
            c.edgeBwMin = p("topo.edgeBw.min", c.edgeBwMin);
            c.edgeBwMax = p("topo.edgeBw.max", c.edgeBwMax);
            c.cloudBw = p("topo.cloudBw", c.cloudBw);
            c.sensorLatency = p("topo.sensorLat", c.sensorLatency);
            c.loadFactorMin = p("topo.loadFactor.min", c.loadFactorMin);
            c.loadFactorMax = p("topo.loadFactor.max", c.loadFactorMax);
            c.edgePressureMin = p("topo.edgePressure.min", c.edgePressureMin);
            c.edgePressureMax = p("topo.edgePressure.max", c.edgePressureMax);
            c.iotMaxUtil = p("topo.iotMaxUtil", c.iotMaxUtil);
            c.edgeMaxUtil = p("topo.edgeMaxUtil", c.edgeMaxUtil);
            c.miJitter = p("topo.miJitter", c.miJitter);
            c.validate();
            return c;
        }

        private static double p(String key, double dflt) {
            String v = System.getProperty(key);
            return v == null ? dflt : Double.parseDouble(v.trim());
        }

        void validate() {
            if (edgeMin < 1 || edgeMax < edgeMin) throw new IllegalArgumentException("bad edge range");
            if (iotPerEdgeMin < 1 || iotPerEdgeMax < iotPerEdgeMin) throw new IllegalArgumentException("bad iotPerEdge range");
            if (iotMipsMin <= 0 || iotMipsMax < iotMipsMin || edgeMipsMin <= 0 || edgeMipsMax < edgeMipsMin
                    || cloudMipsMin <= 0 || cloudMipsMax < cloudMipsMin) throw new IllegalArgumentException("bad MIPS range");
            if (iotLatMin < 0 || iotLatMax < iotLatMin || wanLatMin < 0 || wanLatMax < wanLatMin)
                throw new IllegalArgumentException("bad latency range");
            if (iotBwMin <= 0 || iotBwMax < iotBwMin || edgeBwMin <= 0 || edgeBwMax < edgeBwMin)
                throw new IllegalArgumentException("bad bandwidth range");
            if (loadFactorMin <= 0 || loadFactorMax < loadFactorMin) throw new IllegalArgumentException("bad loadFactor range");
            if (miJitter < 0 || miJitter >= 0.5) throw new IllegalArgumentException("miJitter must be in [0,0.5) to keep the size classes inside the MI bins");
            if (edgeToIotMinRatio < 1 || cloudToEdgeMinRatio < 1) throw new IllegalArgumentException("ratios must be >= 1");
            if (edgePressureMin <= 0 || edgePressureMax < edgePressureMin) throw new IllegalArgumentException("bad edgePressure range");
            if (iotMaxUtil <= 0 || edgeMaxUtil <= 0) throw new IllegalArgumentException("max utilisation must be > 0");
        }
    }

    /** Base task classes: {name, MI, network bytes, min inter-arrival, max inter-arrival}. Same as the fixed scenario. */
    static final Object[][] BASE_CLASSES = {
            {"TASK_S", 200, 2000, 5.0, 15.0},
            {"TASK_M", 1000, 10000, 20.0, 60.0},
            {"TASK_L", 4000, 50000, 80.0, 160.0},
    };

    // ============================================================================================ result types
    public static final class DeviceSpec {
        public String name;
        public int level;            // 0 cloud, 1 edge, 2 iot
        public int parentIndex;      // index in Topology.devices, -1 for the cloud
        public long mips;
        public int ram;
        public long upBw, downBw;
        public double uplinkLatency; // to the parent
        public double busyPower, idlePower, ratePerMips;
    }

    public static final class SensorSpec {
        public String name;
        public String tupleType;     // unique per sensor (iFogSim keeps one AppEdge per tuple type)
        public String taskClass;     // TASK_S / TASK_M / TASK_L
        public int deviceIndex;      // IoT device this sensor is attached to
        public long cpuLengthMi;
        public long nwLengthBytes;
        public double minInterArrival, maxInterArrival;
        public long arrivalSeed;     // derived from workloadSeed
    }

    public static final class Topology {
        public long topologySeed, workloadSeed;
        public int edgeCount, iotCount;
        public double sensorLatency;
        public final List<DeviceSpec> devices = new ArrayList<DeviceSpec>();
        public final List<SensorSpec> sensors = new ArrayList<SensorSpec>();
        public String fingerprint;   // SHA-256 of the structure (independent of workloadSeed and of run ids)

        /**
         * Compact JSON (one line). level 0 = structure only (the text the fingerprint is computed from, so two seeds that
         * happen to give the same structure get the same fingerprint); level 1 = + topologySeed; level 2 = + workload seeds.
         */
        public String toJson(int level) {
            boolean includeWorkloadSeed = level >= 2;
            StringBuilder sb = new StringBuilder(2048);
            sb.append("{\"generator\":\"" + GENERATOR_VERSION + "\",");
            if (level >= 1) sb.append("\"topologySeed\":").append(topologySeed).append(',');
            if (includeWorkloadSeed) sb.append("\"workloadSeed\":").append(workloadSeed).append(',');
            sb.append("\"edgeCount\":").append(edgeCount).append(",\"iotCount\":").append(iotCount);
            sb.append(",\"sensorLatency\":").append(num(sensorLatency));
            sb.append(",\"devices\":[");
            for (int i = 0; i < devices.size(); i++) {
                DeviceSpec d = devices.get(i);
                if (i > 0) sb.append(',');
                sb.append("{\"name\":\"").append(d.name).append("\",\"level\":").append(d.level)
                        .append(",\"parent\":").append(d.parentIndex).append(",\"mips\":").append(d.mips)
                        .append(",\"ram\":").append(d.ram).append(",\"upBw\":").append(d.upBw)
                        .append(",\"downBw\":").append(d.downBw).append(",\"uplinkLatency\":").append(num(d.uplinkLatency))
                        .append('}');
            }
            sb.append("],\"sensors\":[");
            for (int i = 0; i < sensors.size(); i++) {
                SensorSpec s = sensors.get(i);
                if (i > 0) sb.append(',');
                sb.append("{\"name\":\"").append(s.name).append("\",\"class\":\"").append(s.taskClass)
                        .append("\",\"device\":\"").append(devices.get(s.deviceIndex).name)
                        .append("\",\"mi\":").append(s.cpuLengthMi).append(",\"nwBytes\":").append(s.nwLengthBytes)
                        .append(",\"iatMin\":").append(num(s.minInterArrival)).append(",\"iatMax\":").append(num(s.maxInterArrival));
                if (includeWorkloadSeed) sb.append(",\"arrivalSeed\":").append(s.arrivalSeed);
                sb.append('}');
            }
            sb.append("]}");
            return sb.toString();
        }

        /** Human-readable summary for the console. */
        public String describe() {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format(Locale.ROOT, "topologySeed=%d workloadSeed=%d fingerprint=%s edges=%d iot=%d sensors=%d%n",
                    topologySeed, workloadSeed, fingerprint.substring(0, 12), edgeCount, iotCount, sensors.size()));
            for (DeviceSpec d : devices) {
                sb.append(String.format(Locale.ROOT, "  %-8s L%d mips=%-6d ram=%-6d bw=%d/%d uplinkLat=%.1f parent=%s%n",
                        d.name, d.level, d.mips, d.ram, d.upBw, d.downBw, d.uplinkLatency,
                        d.parentIndex < 0 ? "-" : devices.get(d.parentIndex).name));
            }
            for (SensorSpec s : sensors) {
                sb.append(String.format(Locale.ROOT, "  %-18s on %-7s %s mi=%d nw=%d iat=[%.1f,%.1f]%n", s.name,
                        devices.get(s.deviceIndex).name, s.taskClass, s.cpuLengthMi, s.nwLengthBytes,
                        s.minInterArrival, s.maxInterArrival));
            }
            return sb.toString();
        }
    }

    // ============================================================================================ generation
    /** Generates the topology for the two seeds. Pure function of (topologySeed, workloadSeed, cfg). */
    public static Topology generate(long topologySeed, long workloadSeed, Config cfg) {
        cfg.validate();
        Topology t = new Topology();
        t.topologySeed = topologySeed;
        t.workloadSeed = workloadSeed;
        t.sensorLatency = cfg.sensorLatency;

        Random counts = new Random(derive(topologySeed, 1));
        Random cloudRnd = new Random(derive(topologySeed, 2));
        int edges = uniformInt(counts, cfg.edgeMin, cfg.edgeMax);
        t.edgeCount = edges;

        // --- edge MIPS first (the cloud must be fast enough for the fastest edge)
        long[] edgeMips = new long[edges];
        Random[] edgeRnd = new Random[edges];
        long maxEdgeMips = 0;
        for (int e = 0; e < edges; e++) {
            edgeRnd[e] = new Random(derive(topologySeed, 1000 + e));
            edgeMips[e] = Math.round(logUniform(edgeRnd[e], cfg.edgeMipsMin, cfg.edgeMipsMax));
            maxEdgeMips = Math.max(maxEdgeMips, edgeMips[e]);
        }

        // --- cloud
        DeviceSpec cloud = new DeviceSpec();
        cloud.name = "cloud";                       // the Controller looks the cloud up by this name
        cloud.level = 0;
        cloud.parentIndex = -1;
        cloud.mips = Math.round(Math.max(logUniform(cloudRnd, cfg.cloudMipsMin, cfg.cloudMipsMax),
                cfg.cloudToEdgeMinRatio * maxEdgeMips));
        cloud.ram = 40000;
        cloud.upBw = Math.round(cfg.cloudBw);
        cloud.downBw = Math.round(cfg.cloudBw);
        cloud.uplinkLatency = 0;
        cloud.busyPower = 16 * 103;
        cloud.idlePower = 16 * 83.25;
        cloud.ratePerMips = 0.01;
        t.devices.add(cloud);

        int iotNumber = 0;
        for (int e = 0; e < edges; e++) {
            Random r = edgeRnd[e];                  // continues the stream that produced edgeMips[e]
            int edgeIndex = t.devices.size();
            DeviceSpec edge = new DeviceSpec();
            edge.name = "edge-" + (e + 1);
            edge.level = 1;
            edge.parentIndex = 0;
            edge.mips = edgeMips[e];
            edge.ram = pick(r, new int[]{2000, 4000, 8000});
            edge.upBw = edge.downBw = Math.round(logUniform(r, cfg.edgeBwMin, cfg.edgeBwMax));
            edge.uplinkLatency = round1(logUniform(r, cfg.wanLatMin, cfg.wanLatMax));
            // separate stream: adding this knob does not shift any other draw of the edge sub-tree
            double pressure = logUniform(new Random(derive(topologySeed, 5000 + e)), cfg.edgePressureMin, cfg.edgePressureMax);
            int firstSensor = t.sensors.size();
            edge.busyPower = 107.339;
            edge.idlePower = 83.4333;
            edge.ratePerMips = 0.0;
            t.devices.add(edge);

            int nIot = uniformInt(r, cfg.iotPerEdgeMin, cfg.iotPerEdgeMax);
            double iotCap = Math.min(cfg.iotMipsMax, edge.mips / cfg.edgeToIotMinRatio);
            double iotFloor = Math.min(cfg.iotMipsMin, iotCap);
            for (int k = 0; k < nIot; k++) {
                iotNumber++;
                DeviceSpec iot = new DeviceSpec();
                iot.name = "iot-" + iotNumber;
                iot.level = 2;
                iot.parentIndex = edgeIndex;
                iot.mips = Math.max(1, Math.round(logUniform(r, iotFloor, iotCap)));
                iot.ram = pick(r, new int[]{512, 1000, 2000});
                iot.upBw = iot.downBw = Math.round(logUniform(r, cfg.iotBwMin, cfg.iotBwMax));
                iot.uplinkLatency = round1(uniform(r, cfg.iotLatMin, cfg.iotLatMax));
                iot.busyPower = 87.53;
                iot.idlePower = 82.44;
                iot.ratePerMips = 0.0;
                int iotIndex = t.devices.size();
                t.devices.add(iot);
                addSensors(t, cfg, r, iotIndex, iotNumber, pressure);
                capLoad(t, firstSensorOf(t, iotIndex), t.sensors.size(), iot.mips, cfg.iotMaxUtil);   // IoT: <= iotMaxUtil x its MIPS
            }
            capLoad(t, firstSensor, t.sensors.size(), edge.mips, cfg.edgeMaxUtil);                    // Edge: <= edgeMaxUtil x its MIPS
        }
        t.iotCount = iotNumber;
        t.fingerprint = sha256(t.toJson(0));
        validate(t, cfg);
        return t;
    }

    private static int firstSensorOf(Topology t, int deviceIndex) {
        for (int i = 0; i < t.sensors.size(); i++) if (t.sensors.get(i).deviceIndex == deviceIndex) return i;
        return t.sensors.size();
    }

    /**
     * Load guard: if the sensors in [from, to) offer more than maxUtil x mips (MI per unit time, from the MEAN
     * inter-arrival), slow them all down by the same factor so they offer exactly maxUtil x mips. Slowing down only
     * ever lowers load, so a later (edge) guard can never undo an earlier (IoT) one.
     */
    private static void capLoad(Topology t, int from, int to, long mips, double maxUtil) {
        if (from >= to) return;
        double offered = 0;
        for (int i = from; i < to; i++) {
            SensorSpec s = t.sensors.get(i);
            offered += s.cpuLengthMi / ((s.minInterArrival + s.maxInterArrival) / 2.0);
        }
        double util = offered / mips;
        if (util <= maxUtil) return;
        double f = util / maxUtil;
        for (int i = from; i < to; i++) {
            SensorSpec s = t.sensors.get(i);
            s.minInterArrival = Math.max(1.0, round1(s.minInterArrival * f));
            s.maxInterArrival = Math.max(s.minInterArrival + 1.0, round1(s.maxInterArrival * f));
        }
    }

    private static void addSensors(Topology t, Config cfg, Random r, int iotIndex, int iotNumber, double pressure) {
        double loadFactor = logUniform(r, cfg.loadFactorMin, cfg.loadFactorMax) / pressure;
        boolean any = false;
        for (int c = 0; c < BASE_CLASSES.length; c++) {
            boolean take = r.nextDouble() < cfg.classProbability[c];
            double jitterMi = uniform(r, 1 - cfg.miJitter, 1 + cfg.miJitter);       // always drawn: stable stream layout
            double jitterNw = uniform(r, 0.8, 1.2);
            double jitterIat = uniform(r, 0.8, 1.25);
            if (c == BASE_CLASSES.length - 1 && !any) take = true;                  // keep at least one class
            if (!take) continue;
            any = true;
            Object[] b = BASE_CLASSES[c];
            double baseMi = ((Integer) b[1]).doubleValue(), baseNw = ((Integer) b[2]).doubleValue();
            SensorSpec s = new SensorSpec();
            s.taskClass = (String) b[0];
            s.name = "s-" + iotNumber + "-" + s.taskClass;
            s.tupleType = s.taskClass + "_i" + iotNumber;
            s.deviceIndex = iotIndex;
            s.cpuLengthMi = Math.round(baseMi * jitterMi);
            s.nwLengthBytes = Math.round(baseNw * jitterMi * jitterNw);             // data size follows the task size
            s.minInterArrival = Math.max(1.0, round1((Double) b[3] * loadFactor));
            s.maxInterArrival = Math.max(s.minInterArrival + 1.0, round1((Double) b[4] * loadFactor * jitterIat));
            s.arrivalSeed = derive(t.workloadSeed, iotNumber * 16L + c);
            t.sensors.add(s);
        }
    }

    private static void validate(Topology t, Config cfg) {
        if (t.sensors.isEmpty()) throw new IllegalStateException("topology without sensors");
        for (DeviceSpec d : t.devices) {
            if (d.level == 0) continue;
            DeviceSpec p = t.devices.get(d.parentIndex);
            if (d.level == 1 && p.mips < cfg.cloudToEdgeMinRatio * d.mips - 1)
                throw new IllegalStateException(d.name + ": cloud not fast enough");
            if (d.level == 2 && d.mips > p.mips / cfg.edgeToIotMinRatio + 1)
                throw new IllegalStateException(d.name + ": faster than allowed relative to " + p.name);
        }
        for (SensorSpec s : t.sensors) {
            // keep every size class inside the MI bins of the Python state (500 / 2000)
            if (s.taskClass.equals("TASK_S") && s.cpuLengthMi >= 500) throw new IllegalStateException(s.name + ": S out of bin");
            if (s.taskClass.equals("TASK_M") && (s.cpuLengthMi < 500 || s.cpuLengthMi >= 2000))
                throw new IllegalStateException(s.name + ": M out of bin");
            if (s.taskClass.equals("TASK_L") && s.cpuLengthMi < 2000) throw new IllegalStateException(s.name + ": L out of bin");
        }
    }

    // ============================================================================================ logging / leakage guard
    /**
     * Writes the full topology to <logDir>/topologies/topology_seed<seed>_<fingerprint12>.json and appends one line to
     * <logDir>/topologies.jsonl (the registry): runId, phase, seeds, fingerprint, node counts. When phase is "test" the
     * registry is first checked: a topology (same seed OR same fingerprint) that was used in a "train" run is rejected
     * unless -Dtopology.allowOverlap=true. This is the guard for "evaluate on topologies not used in training".
     * Runs are assumed to be sequential (the registry file is not locked).
     */
    public static void record(Topology t, String runId, String phase, String agentSeed, File logDir) throws IOException {
        if (!logDir.isDirectory() && !logDir.mkdirs()) throw new IOException("cannot create " + logDir);
        File registry = new File(logDir, "topologies.jsonl");
        if ("test".equals(phase) && !Boolean.getBoolean("topology.allowOverlap")) {
            String seedTok = "\"topologySeed\":" + t.topologySeed + ",";
            String fpTok = "\"fingerprint\":\"" + t.fingerprint + "\"";
            if (registry.isFile()) {
                BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(registry), StandardCharsets.UTF_8));
                try {
                    String line;
                    while ((line = in.readLine()) != null) {
                        if (line.contains("\"phase\":\"train\"") && (line.contains(seedTok) || line.contains(fpTok))) {
                            throw new IllegalStateException("topology seed " + t.topologySeed + " (fingerprint "
                                    + t.fingerprint.substring(0, 12) + ") was used for TRAINING; evaluation needs a new topology. "
                                    + "Registry: " + registry + " (override only on purpose with -Dtopology.allowOverlap=true)");
                        }
                    }
                } finally {
                    in.close();
                }
            }
        }
        File dir = new File(logDir, "topologies");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("cannot create " + dir);
        File full = new File(dir, "topology_seed" + t.topologySeed + "_" + t.fingerprint.substring(0, 12) + ".json");
        if (!full.exists()) writeLine(full, t.toJson(1), false);
        StringBuilder line = new StringBuilder();
        line.append("{\"runId\":\"").append(esc(runId)).append("\",\"phase\":\"").append(esc(phase))
                .append("\",\"mode\":\"random\",\"topologySeed\":").append(t.topologySeed)
                .append(",\"workloadSeed\":").append(t.workloadSeed)
                .append(",\"agentSeed\":").append(agentSeed == null ? "null" : "\"" + esc(agentSeed) + "\"")
                .append(",\"fingerprint\":\"").append(t.fingerprint).append("\",\"edges\":").append(t.edgeCount)
                .append(",\"iot\":").append(t.iotCount).append(",\"sensors\":").append(t.sensors.size())
                .append(",\"file\":\"").append(esc(full.getName())).append("\"}");
        writeLine(registry, line.toString(), true);
    }

    /**
     * Seed-set check. -Dtopology.trainSeeds="1-20,25" declares the training topologies. Phase "train" must use a seed from
     * the set; phase "test" must NOT. No property set: no check. Phase "dev": no check.
     */
    public static void checkSeedSets(long topologySeed, String phase) {
        String spec = System.getProperty("topology.trainSeeds");
        if (spec == null || spec.trim().isEmpty() || "dev".equals(phase)) return;
        boolean inTrain = false;
        for (String part : spec.split(",")) {
            String s = part.trim();
            if (s.isEmpty()) continue;
            int dash = s.indexOf('-', 1);
            long lo, hi;
            if (dash > 0) {
                lo = Long.parseLong(s.substring(0, dash).trim());
                hi = Long.parseLong(s.substring(dash + 1).trim());
            } else {
                lo = hi = Long.parseLong(s);
            }
            if (topologySeed >= lo && topologySeed <= hi) inTrain = true;
        }
        if ("test".equals(phase) && inTrain)
            throw new IllegalStateException("topology.seed=" + topologySeed + " belongs to topology.trainSeeds=" + spec
                    + "; use a different seed for evaluation");
        if ("train".equals(phase) && !inTrain)
            throw new IllegalStateException("topology.seed=" + topologySeed + " is not in topology.trainSeeds=" + spec);
    }

    // ============================================================================================ model-bound ledger
    /**
     * Guard tied to the MODEL, not to a log folder. A train run writes "<model>.topologies.json" next to the model it
     * saves (union with the ledger of -Drl.modelIn when training is continued); an eval run with -Drl.modelIn=<model>
     * is refused if its topology (same seed OR same fingerprint) is in that model's ledger, unless
     * -Dtopology.allowOverlap=true. It also works when training used phase=dev or another log folder.
     * The ledger is written when the run STARTS (conservative: a seed is marked used even if the run crashes).
     *
     * @param rlMode   value of -Drl.mode (train / eval / baseline)
     * @return null if fine; otherwise the refusal text
     */
    @SuppressWarnings("unchecked")
    public static String checkModelLedger(String rlMode, Topology t, String runId, String modelIn, String modelOut) {
        try {
            if ("train".equals(rlMode)) {
                TreeSet<Long> seeds = new TreeSet<Long>();
                TreeSet<String> fps = new TreeSet<String>();
                readLedger(modelIn, seeds, fps);
                readLedger(modelOut, seeds, fps);
                seeds.add(t.topologySeed);
                fps.add(t.fingerprint);
                JSONObject o = new JSONObject();
                JSONArray a = new JSONArray(); a.addAll(seeds);
                JSONArray f = new JSONArray(); f.addAll(fps);
                o.put("trained_topology_seeds", a);
                o.put("trained_fingerprints", f);
                o.put("generator", GENERATOR_VERSION);
                o.put("last_run_id", runId);
                File file = new File(modelOut + ".topologies.json");
                if (file.getParentFile() != null) file.getParentFile().mkdirs();
                writeLine(file, o.toJSONString(), false);
            } else if ("eval".equals(rlMode) && modelIn != null && !Boolean.getBoolean("topology.allowOverlap")) {
                File file = new File(modelIn + ".topologies.json");
                if (!file.isFile()) {
                    System.err.println("[topology] WARNING: " + file.getName() + " not found next to the model; cannot verify that topology "
                            + t.topologySeed + " is unseen by it.");
                    return null;
                }
                TreeSet<Long> seeds = new TreeSet<Long>();
                TreeSet<String> fps = new TreeSet<String>();
                readLedger(modelIn, seeds, fps);
                if (seeds.contains(t.topologySeed) || fps.contains(t.fingerprint))
                    return "this model was TRAINED on topology seed " + t.topologySeed + " (fingerprint "
                            + t.fingerprint.substring(0, 12) + "); evaluate on an unseen topology. Trained seeds: " + seeds
                            + ". (Override only on purpose: -Dtopology.allowOverlap=true)";
            }
        } catch (Exception e) {
            System.err.println("[topology] WARNING: model ledger problem: " + e);
        }
        return null;
    }

    private static void readLedger(String modelPath, TreeSet<Long> seeds, TreeSet<String> fps) throws Exception {
        if (modelPath == null) return;
        File file = new File(modelPath + ".topologies.json");
        if (!file.isFile()) return;
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
        try {
            JSONObject o = (JSONObject) new JSONParser().parse(in);
            for (Object x : (JSONArray) o.get("trained_topology_seeds")) seeds.add(((Number) x).longValue());
            for (Object x : (JSONArray) o.get("trained_fingerprints")) fps.add((String) x);
        } finally {
            in.close();
        }
    }

    // ============================================================================================ command line preview
    /** Prints a topology without running any simulation:  java ... RandomTopologyGenerator <topologySeed> [workloadSeed] */
    public static void main(String[] args) {
        if (args.length < 1) {
            System.err.println("usage: RandomTopologyGenerator <topologySeed> [workloadSeed]   (ranges: -Dtopo.*)");
            return;
        }
        long ts = Long.parseLong(args[0]);
        long ws = args.length > 1 ? Long.parseLong(args[1]) : 1L;
        Topology t = generate(ts, ws, Config.fromSystemProperties());
        System.out.print(t.describe());
        System.out.println(t.toJson(2));
    }

    // ============================================================================================ helpers
    /** SplitMix64 finaliser: independent-looking 64-bit seed per (seed, salt). */
    static long derive(long seed, long salt) {
        long z = seed + 0x9E3779B97F4A7C15L * (salt + 1);
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    private static double uniform(Random r, double lo, double hi) {
        return lo + r.nextDouble() * (hi - lo);
    }

    private static int uniformInt(Random r, int lo, int hi) {
        return lo + r.nextInt(hi - lo + 1);
    }

    private static double logUniform(Random r, double lo, double hi) {
        if (hi <= lo) return lo;
        return Math.exp(Math.log(lo) + r.nextDouble() * (Math.log(hi) - Math.log(lo)));
    }

    private static int pick(Random r, int[] values) {
        return values[r.nextInt(values.length)];
    }

    private static double round1(double x) {
        return Math.round(x * 10.0) / 10.0;
    }

    private static String num(double x) {
        return String.format(Locale.ROOT, "%.4f", x);
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String sha256(String text) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static void writeLine(File f, String line, boolean append) throws IOException {
        Writer w = new OutputStreamWriter(new FileOutputStream(f, append), StandardCharsets.UTF_8);
        try {
            w.write(line);
            w.write("\n");
        } finally {
            w.close();
        }
    }
}
