package org.fog.offloading;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.fog.entities.FogDevice;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Connects iFogSim to the Python Q-learning agent (rl_model).
 *
 * Decision point : a tuple emitted by a Sensor arrives at its first device (FogDevice.processTupleArrival).
 * Actions        : LOCAL = keep normal processing on that device,
 *                  EDGE  = send the tuple up to the parent device (normal link model, sendUp),
 *                  CLOUD = send it directly to the top of the tree (sum of per-hop delays).
 * Outcome        : reported when the tuple's execution completes (FogDevice.checkCloudletCompletion).
 *
 * DISABLED by default (existing simulations are unchanged). Enable with -Drl.enabled=true.
 * See RL_OFFLOADING.md at the project root. Every error falls back to iFogSim's normal behaviour.
 */
public final class RLOffloadingManager {
    public static final int LOCAL = 0, EDGE = 1, CLOUD = 2;
    private static final String[] NAMES = {"Local", "Edge", "Cloud"};
    private static final String V = "1.0";

    private static volatile boolean enabled = Boolean.getBoolean("rl.enabled");
    private static RLOffloadingManager instance;

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean on) {
        enabled = on;
    }

    public static synchronized RLOffloadingManager getInstance() {
        if (instance == null) instance = new RLOffloadingManager();
        return instance;
    }

    /** Called from Controller on STOP_SIMULATION and by a JVM shutdown hook; idempotent. */
    public static void finishIfEnabled() {
        if (instance != null) instance.finish();
    }

    private static final class Pending {
        int entryDeviceId;
        int decidedAction;
        double decisionTime;
        double targetArrivalTime = Double.NaN;
        double submitTime = Double.NaN;
        double deadlineMs;        // relative deadline, measured from generationTime (not from the decision)
        double generationTime;    // when the Sensor emitted the tuple
        double absoluteDeadline;  // generationTime + deadlineMs
        double fileSize;
        int countedDeviceId;     // device whose backlog includes this task
        int expectedDeviceId;    // expected execution target, for routing audit
        String lastStage = "DECIDED";
        String lastNode = "unknown";
        double lastStageTime = Double.NaN;
        double mi;               // task length, for the backlog bookkeeping
    }

    // Test 5: record actual Sensor emission; key is Tuple Cloudlet ID (not actualTupleId).
    private static final class Origin {
        final double generated;
        final String sensor;
        final String tupleType;
        double firstIotArrival = Double.NaN;
        double decision = Double.NaN;
        double completed = Double.NaN;
        final double deadlineMs;   // relative deadline, measured from 'generated'
        Origin(double time, String sensor, String type, double deadlineMs) {
            this.generated = time; this.sensor = sensor; this.tupleType = type; this.deadlineMs = deadlineMs;
        }
    }
    private final Map<Integer, Origin> origins = new HashMap<Integer, Origin>();
    private final boolean auditE2E = Boolean.getBoolean("rl.auditE2E");
    private long e2eCompleted = 0;
    private double e2eSum = 0;
    public static void recordSensorEmission(Sensor sensor, Tuple tuple) {
        // Always recorded when RL is enabled: the generation time is the anchor of every task's deadline.
        if (!isEnabled()) return;
        RLOffloadingManager manager = getInstance();
        int id = tuple.getCloudletId();
        Origin old = manager.origins.put(id, new Origin(CloudSim.clock(), sensor.getName(), tuple.getTupleType(),
                manager.deadlineFor(tuple)));
        if (manager.auditE2E) {
            if (old != null) System.err.println("[rl-e2e] DUPLICATE_SENSOR_ID task=t-" + id);
            System.err.println("[rl-e2e] GENERATED task=t-" + id + " sensor=" + sensor.getName()
                    + " type=" + tuple.getTupleType() + " time=" + CloudSim.clock());
        }
    }
    public void recordFirstIotArrival(FogDevice dev, Tuple tuple) {
        if (!auditE2E) return;
        Origin o = origins.get(tuple.getCloudletId());
        if (o != null && Double.isNaN(o.firstIotArrival)) {
            o.firstIotArrival = CloudSim.clock();
            System.err.println("[rl-e2e] IOT_ARRIVAL task=" + tid(tuple) + " node=" + dev.getName()
                    + " time=" + o.firstIotArrival + " sensorToIoT=" + (o.firstIotArrival-o.generated));
        }
    }
    private final Map<Integer, Pending> pending = new HashMap<Integer, Pending>();
    private final JSONParser parser = new JSONParser();
    private RLClient client;
    private boolean active = false;
    private boolean finished = false;
    private int ioFailures = 0;
    private long decisions = 0, outcomes = 0, fallbacks = 0;
    // Deadline policy. If -Drl.deadlineMs is given explicitly it is a constant for every task (old option, still valid).
    // Otherwise the deadline scales with task size:  deadline = rl.deadlineBaseMs + rl.deadlinePerMi * task MI.
    // In both cases the clock starts when the SENSOR generates the tuple:
    //   absoluteDeadline = generationTime + deadline;  deadline_met  <=>  completionTime <= absoluteDeadline  (true E2E).
    private final boolean constantDeadline = System.getProperty("rl.deadlineMs") != null;
    private final double constantDeadlineMs = Double.parseDouble(System.getProperty("rl.deadlineMs", "1000"));
    private final double deadlineBaseMs = Double.parseDouble(System.getProperty("rl.deadlineBaseMs", "20"));
    private final double deadlinePerMi = Double.parseDouble(System.getProperty("rl.deadlinePerMi", "0.05"));

    private double deadlineFor(Tuple tuple) {
        return constantDeadline ? constantDeadlineMs : deadlineBaseMs + deadlinePerMi * tuple.getCloudletLength();
    }
    // Partial (divisible-task) offloading; null unless -Drl.partial.enabled=true. See PartialOffloader.
    private final PartialOffloader partial = PartialOffloader.fromProperties(
            new File(abs("rl.logDir", new File(System.getProperty("rl.home", "rl_model"), "logs").getPath()),
                    "partial_" + System.getProperty("rl.runId", "run") + ".csv"));
    private final boolean pendingAsFailed = Boolean.getBoolean("rl.reportPendingAsFailed");
    private final boolean auditRouting = Boolean.getBoolean("rl.auditRouting");
    private final boolean auditLatency = Boolean.getBoolean("rl.auditLatency");
    private long routingMatched = 0, routingMismatched = 0;
    private final boolean auditLifecycle = Boolean.getBoolean("rl.auditLifecycle");
    private double cutoffTime = Double.NaN;
    private long postCutoffArrivals = 0;
    private boolean warnedDeadline = false;
    private boolean warnedNoOrigin = false;

    // Backlog bookkeeping (replaces iFogSim's 0/1 host utilization): work (MI) of tasks routed to a device and not
    // finished yet. load(d) = min(1, (backlogMI / deviceMIPS) / rl.backlogCapMs)  -> 0..1, capacity aware.
    private final Map<Integer, Double> backlogMi = new HashMap<Integer, Double>();
    private final double backlogCapMs = Double.parseDouble(System.getProperty("rl.backlogCapMs", "10"));

    // Statistics for the end-of-run summary (by action index: Local, Edge, Cloud)
    private final long[] decidedCount = new long[3];
    private final long[] doneCount = new long[3];
    private final long[] missCount = new long[3];
    private final double[] latSum = new double[3];
    private final double[] e2eSumByAction = new double[3];
    // Pending-at-cutoff classification (deadline already passed vs still within it), filled by classifyPending()
    private final long[] pendExpired = new long[3], pendWithin = new long[3];
    private long undecidedExpired = 0, undecidedWithin = 0;

    private RLOffloadingManager() {
        try {
            start();
            Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
                public void run() {
                    finish();
                }
            }, "rl-finish"));
        } catch (Exception e) {
            System.err.println("[rl] could not start the Python agent, using default iFogSim behaviour: " + e);
            active = false;
        }
    }

    // ------------------------------------------------------------------ startup
    private void start() throws IOException {
        File home = new File(System.getProperty("rl.home", "rl_model")).getAbsoluteFile();
        String python = System.getProperty("rl.python", "python");
        String mode = System.getProperty("rl.mode", "train");
        String runId = System.getProperty("rl.runId", "run-" + System.currentTimeMillis());
        String phase = System.getProperty("rl.phase", "dev");
        long timeout = Long.parseLong(System.getProperty("rl.timeoutMs", "10000"));

        List<String> cmd = new ArrayList<String>();
        cmd.add(python);
        cmd.add("-m");
        cmd.add("rl_model.server");
        cmd.add("--config");
        cmd.add(abs("rl.config", new File(home, "config/default.json").getPath()));
        cmd.add("--mode");
        cmd.add(mode);
        if ("baseline".equals(mode)) {
            cmd.add("--policy");
            cmd.add(System.getProperty("rl.policy", "edge"));
        }
        if (System.getProperty("rl.modelIn") != null) {
            cmd.add("--model-in");
            cmd.add(abs("rl.modelIn", null));
        }
        if (System.getProperty("rl.modelOut") != null) {
            cmd.add("--model-out");
            cmd.add(abs("rl.modelOut", null));
        }
        cmd.add("--log-dir");
        cmd.add(abs("rl.logDir", new File(home, "logs").getPath()));
        cmd.add("--artifacts-dir");
        cmd.add(abs("rl.artifactsDir", new File(home, "artifacts").getPath()));
        if (System.getProperty("rl.agentSeed") != null) {
            cmd.add("--seed");
            cmd.add(System.getProperty("rl.agentSeed"));
        }
        Map<String, String> env = new HashMap<String, String>();
        env.put("PYTHONPATH", new File(home, "src").getPath());
        env.put("PYTHONUNBUFFERED", "1");
        client = new RLClient(cmd, home, env, timeout);

        JSONObject hello = msg("hello");
        hello.put("run_id", runId);
        hello.put("phase", phase);
        if (System.getProperty("rl.simSeed") != null) hello.put("sim_seed", Long.valueOf(System.getProperty("rl.simSeed")));
        JSONObject sim = new JSONObject();
        sim.put("name", "iFogSim2");
        sim.put("version", "unknown");
        // topology / workload identification (set by EdgeCloudOffloadingRL); ends up in the Python run log (run_start.simulator)
        for (String k : new String[]{"topology.mode", "topology.seed", "topology.fingerprint", "workload.seed"}) {
            String v = System.getProperty(k);
            if (v != null) sim.put(k.replace('.', '_'), v);
        }
        if (partial != null) {
            sim.put("partial_offloading", "ratios=" + System.getProperty("rl.partial.ratios", "0.5")
                    + ";targets=" + System.getProperty("rl.partial.targets", "Edge,Cloud"));
        }
        hello.put("simulator", sim);
        JSONObject ack = call(hello);
        if (ack == null || !"hello_ack".equals(ack.get("type"))) {
            throw new IOException("handshake failed: " + (ack == null ? "no reply" : ack.toJSONString()));
        }
        active = true;
        System.err.println("[rl] agent ready: " + ack.toJSONString());
    }

    /**
     * Resolves a path option. Absolute paths are used as they are. A RELATIVE path is resolved against rl.home (the
     * model folder), not against the JVM working directory, so the result does not depend on how the IDE was set up.
     * Both "artifacts/m.json" and the older "rl_model/artifacts/m.json" (leading folder = the model folder's own
     * name) land inside the model folder.
     */
    /** Public wrapper for scenario classes: same path rules as the agent options; null if neither property nor default. */
    public static String resolveOption(String prop, String dflt) {
        if (System.getProperty(prop, dflt) == null) return null;
        return abs(prop, dflt);
    }

    /** Absolute path of the model folder (rl.home). */
    public static String modelHome() {
        return new File(System.getProperty("rl.home", "rl_model")).getAbsolutePath();
    }

    private static String abs(String prop, String dflt) {
        String p = System.getProperty(prop, dflt);
        File f = new File(p);
        if (f.isAbsolute()) return f.getAbsolutePath();
        File home = new File(System.getProperty("rl.home", "rl_model")).getAbsoluteFile();
        String norm = p.replace('\\', '/');
        String lead = home.getName() + "/";
        if (norm.startsWith(lead)) norm = norm.substring(lead.length());
        return new File(home, norm).getAbsolutePath();
    }

    // ------------------------------------------------------------------ decision
    /**
     * @return true if the tuple was forwarded elsewhere (caller must stop processing it);
     *         false to continue with the normal local flow (action LOCAL, or any fallback).
     */
    public boolean tryOffload(FogDevice dev, Tuple tuple) {
        if (!active || finished || tuple.getDestModuleName() == null) return false;
        try {
            FogDevice parent = dev.getParentId() > 0 ? (FogDevice) CloudSim.getEntity(dev.getParentId()) : null;
            FogDevice cloud = topOf(dev);
            String app = tuple.getAppId(), mod = tuple.getDestModuleName();
            boolean localOk = dev.rlHostsModule(app, mod);
            boolean cloudOk = cloud != null && cloud != dev && cloud.rlHostsModule(app, mod);
            boolean edgeOk = parent != null && parent != cloud && parent.rlHostsModule(app, mod);
            if (((localOk ? 1 : 0) + (edgeOk ? 1 : 0) + (cloudOk ? 1 : 0)) < 2) {
                return false;      // nothing to choose between: leave iFogSim's own placement alone
            }
            if (!warnedDeadline) {
                warnedDeadline = true;
                System.err.println(constantDeadline
                        ? "[rl] WARNING: iFogSim tuples carry no deadline; using constant rl.deadlineMs=" + constantDeadlineMs
                          + " counted from sensor generation (TO CONFIRM)"
                        : "[rl] deadline = " + deadlineBaseMs + " + " + deadlinePerMi
                          + " * task MI, counted from sensor generation (derived from task size; TO CONFIRM)");
            }
            double taskDeadlineMs = deadlineFor(tuple);
            Origin origin0 = origins.get(tuple.getCloudletId());
            if (origin0 == null && !warnedNoOrigin) {
                warnedNoOrigin = true;
                System.err.println("[rl] WARNING: no sensor-emission record for a decided tuple; its deadline is anchored at the decision time");
            }
            double generationTime = origin0 != null ? origin0.generated : CloudSim.clock();
            double absoluteDeadline = generationTime + taskDeadlineMs;
            // deadline_ms (state feature, currently disabled) = budget LEFT at decision time. With latency_ms measured from the
            // decision, "latency_ms <= deadline_ms" is then exactly "true E2E <= deadline", as the agent's consistency check expects.
            double remainingDeadlineMs = Math.max(0.0, absoluteDeadline - CloudSim.clock());

            JSONObject f = new JSONObject();
            f.put("task_mi", num(tuple.getCloudletLength()));
            f.put("wan_latency_ms", num(pathLatency(dev, cloud)));
            f.put("edge_utilization", num(parent != null ? load(parent) : 0.0));   // estimated backlog / cap, 0..1
            f.put("deadline_ms", num(remainingDeadlineMs));
            JSONArray avail = new JSONArray();
            if (localOk) avail.add(NAMES[LOCAL]);
            if (edgeOk) avail.add(NAMES[EDGE]);
            if (cloudOk) avail.add(NAMES[CLOUD]);
            JSONObject o = msg("observation");
            o.put("task_id", tid(tuple));
            o.put("sim_time_ms", num(CloudSim.clock()));
            o.put("features", f);
            o.put("available_actions", avail);

            JSONObject r = call(o);
            if (r == null || !"action".equals(r.get("type")) || !tid(tuple).equals(r.get("task_id"))) {
                fallbacks++;
                if (r != null) System.err.println("[rl] agent error, default behaviour used: " + r.toJSONString());
                return false;
            }
            int action = ((Number) r.get("action_id")).intValue();
            if (action < 0 || action > 2 || !allowed(action, localOk, edgeOk, cloudOk)) {
                fallbacks++;
                return false;
            }
            Pending p = new Pending();
            p.entryDeviceId = dev.getId();
            p.decidedAction = action;
            p.decisionTime = CloudSim.clock();
            if (origin0 != null) origin0.decision = p.decisionTime;
            else if (auditE2E) System.err.println("[rl-e2e] MISSING_ORIGIN task=" + tid(tuple));
            p.generationTime = generationTime;
            p.absoluteDeadline = absoluteDeadline;
            p.lastStageTime = p.decisionTime;
            p.lastNode = dev.getName();
            p.deadlineMs = taskDeadlineMs;
            p.fileSize = tuple.getCloudletFileSize();
            FogDevice target = action == LOCAL ? dev : (action == EDGE ? parent : cloud);
            p.countedDeviceId = target.getId();
            p.expectedDeviceId = target.getId();
            if (action == LOCAL) p.targetArrivalTime = p.decisionTime; // already on local device
            p.mi = tuple.getCloudletLength();
            Double cur = backlogMi.get(p.countedDeviceId);
            backlogMi.put(p.countedDeviceId, (cur == null ? 0.0 : cur) + p.mi);
            pending.put(tuple.getCloudletId(), p);
            decisions++;
            decidedCount[action]++;
            if (auditRouting) {
                System.err.println("[rl-audit] DECISION task=" + tid(tuple)
                        + " action=" + NAMES[action] + " source=" + dev.getName()
                        + " expected=" + target.getName() + " expectedId=" + p.expectedDeviceId
                        + " simTime=" + CloudSim.clock());
            }

            if (partial != null && action != LOCAL && localOk && partial.eligible(action, tuple)) {
                // Divisible task: Local + (Edge|Cloud) branches replace the whole-task transfer. The branches are
                // counted in the backlog of the device that runs them, and the final completion is reported once.
                adjustBacklog(p.countedDeviceId, -p.mi);
                p.mi = 0.0;
                partial.start(this, dev, tuple, target, action, p.decisionTime);
                return true;
            }
            if (action == EDGE) {
                dev.rlSendUp(tuple);
                return true;
            }
            if (action == CLOUD) {
                // Hop-by-hop transfer: both IoT and Edge uplinks use real link queues.
                dev.rlSendUp(tuple);
                return true;
            }
            return false;           // LOCAL
        } catch (RuntimeException e) {
            fallbacks++;
            System.err.println("[rl] unexpected error in tryOffload, default behaviour used: " + e);
            return false;
        }
    }

    private static boolean allowed(int a, boolean l, boolean e, boolean c) {
        return (a == LOCAL && l) || (a == EDGE && e) || (a == CLOUD && c);
    }

    /**
     * Forward a Cloud-targeted RL tuple at an intermediate FogDevice without executing
     * its locally deployed processing module. Returns true only for the transit hop.
     */
    public boolean forwardCloudTransit(FogDevice dev, Tuple tuple) {
        // Keep in-flight Cloud tuples on their route even if the Python agent
        // has already shut down at the simulation cutoff.
        if (!isEnabled()) return false;
        if (partial != null && partial.forwardTransit(dev, tuple)) return true;     // Cloud branch of a split task
        Pending p = pending.get(tuple.getCloudletId());
        if (p == null || p.decidedAction != CLOUD) return false;
        if (dev.getId() == p.entryDeviceId || dev.getId() == p.expectedDeviceId) return false;
        if (dev.getParentId() <= 0) {
            System.err.println("[rl-net] ERROR transit has no parent task=" + tid(tuple)
                    + " node=" + dev.getName());
            return true; // prevent execution on the incorrect tier
        }
        if (auditLatency) {
            System.err.println("[rl-latency] CLOUD_TRANSIT task=" + tid(tuple)
                    + " via=" + dev.getName() + " time=" + CloudSim.clock()
                    + " uplinkTx=" + (tuple.getCloudletFileSize() / dev.getUplinkBandwidth())
                    + " propagation=" + dev.getUplinkLatency());
        }
        p.lastStage = "TRANSIT_FORWARD";
        p.lastNode = dev.getName();
        p.lastStageTime = CloudSim.clock();
        dev.rlSendUp(tuple);
        return true;
    }

    // Diagnostic instrumentation only; no changes to tuple routing or agent decisions.
    public void auditTupleArrival(FogDevice dev, Tuple tuple) {
        if (!auditLatency && !auditLifecycle) return;
        Pending p = pending.get(tuple.getCloudletId());
        if (p == null) return;
        double now = CloudSim.clock();
        p.lastStage = "ARRIVED";
        p.lastNode = dev.getName();
        p.lastStageTime = now;
        if (finished && auditLifecycle) {
            postCutoffArrivals++;
            System.err.println("[rl-lifecycle] AFTER_CUTOFF_ARRIVAL task=" + tid(tuple)
                    + " node=" + dev.getName() + " time=" + now
                    + " cutoff=" + cutoffTime + " excludedFromReportedOutcomes=true");
        }
        if (!auditLatency) return;
        if (dev.getId() == p.expectedDeviceId && Double.isNaN(p.targetArrivalTime))
            p.targetArrivalTime = now;
        System.err.println("[rl-latency] ARRIVAL task=" + tid(tuple)
                + " node=" + dev.getName() + " time=" + now
                + " afterDecision=" + (now - p.decisionTime));
    }

    // This is application execution submission, NOT a scheduler-confirmed CPU start timestamp.
    public void auditExecutionSubmit(FogDevice dev, Tuple tuple) {
        if (!auditLatency && !auditLifecycle) return;
        Pending p = pending.get(tuple.getCloudletId());
        if (p == null) return;
        p.lastStage = "EXEC_SUBMIT";
        p.lastNode = dev.getName();
        p.lastStageTime = CloudSim.clock();
        if (!auditLatency) return;
        p.submitTime = CloudSim.clock();
        System.err.println("[rl-latency] EXEC_SUBMIT task=" + tid(tuple)
                + " node=" + dev.getName() + " time=" + p.submitTime);
    }

    // Called only for the normal edge uplink path (including queue state).
    public void auditEdgeSend(FogDevice dev, Tuple tuple, boolean queued) {
        if (!auditLatency || !pending.containsKey(tuple.getCloudletId())) return;
        System.err.println("[rl-latency] EDGE_LINK task=" + tid(tuple)
                + " from=" + dev.getName() + " mode=" + (queued ? "QUEUED" : "SENT")
                + " tx=" + (tuple.getCloudletFileSize() / dev.getUplinkBandwidth())
                + " propagation=" + dev.getUplinkLatency() + " time=" + CloudSim.clock());
    }

    // Called for the cloud shortcut and documents the actual delay scheduled by the simulator.
    public void auditDirectSend(FogDevice dev, Tuple tuple, int targetId, double delay) {
        if (!auditLatency || !pending.containsKey(tuple.getCloudletId())) return;
        System.err.println("[rl-latency] CLOUD_DIRECT task=" + tid(tuple)
                + " from=" + dev.getName() + " targetId=" + targetId
                + " scheduledDelay=" + delay + " bypassIntermediateQueues=true"
                + " time=" + CloudSim.clock());
    }

    // ------------------------------------------------------------------ outcome
    /** Called when the tuple finished executing on 'executedOn'. Ignores tuples that were never decided. */
    public void onTupleCompleted(FogDevice executedOn, Tuple tuple) {
        if (partial != null && partial.onBranchCompleted(this, executedOn, tuple)) return;   // one branch of a split task
        complete(executedOn, tuple, -1, executedOn, 0.0, true);
    }

    /** Final completion of a split task (after the merge): the one and only outcome of that task. */
    void completePartial(FogDevice mergeDev, Tuple parent, int action, FogDevice remoteNode, double bytes, boolean routingOk) {
        complete(mergeDev, parent, action, remoteNode, bytes, routingOk);
    }

    public void onPartialEvent(FogDevice dev, Object data) {
        if (partial != null) partial.onEvent(this, dev, data);
    }

    public boolean isPartialBranch(Tuple tuple) {
        return partial != null && partial.isBranch(tuple);
    }

    void adjustBacklog(int deviceId, double deltaMi) {
        Double cur = backlogMi.get(deviceId);
        backlogMi.put(deviceId, Math.max(0.0, (cur == null ? 0.0 : cur) + deltaMi));
    }

    double generationOf(Tuple tuple) {
        Origin o = origins.get(tuple.getCloudletId());
        return o != null ? o.generated : CloudSim.clock();
    }

    /**
     * @param forcedAction -1 = whole task (action derived from where it ran); otherwise the decided action of a split task
     * @param loadNode     device whose load is reported as executing_node_utilization
     */
    private void complete(FogDevice executedOn, Tuple tuple, int forcedAction, FogDevice loadNode, double bytes, boolean routingOk) {
        // Preserve cutoff snapshot: a completion after shutdown is NOT a pre-cutoff outcome.
        Pending p = pending.get(tuple.getCloudletId());
        if (p == null) return;
        if (finished || !active) {
            if (auditLifecycle) System.err.println("[rl-lifecycle] AFTER_CUTOFF_COMPLETION task=" + tid(tuple)
                    + " node=" + executedOn.getName() + " time=" + CloudSim.clock()
                    + " cutoff=" + cutoffTime + " excludedFromReportedOutcomes=true");
            return;
        }
        pending.remove(tuple.getCloudletId());
        Double cur = backlogMi.get(p.countedDeviceId);
        backlogMi.put(p.countedDeviceId, Math.max(0.0, (cur == null ? 0.0 : cur) - p.mi));
        double latency = CloudSim.clock() - p.decisionTime;          // decision -> finish (what the reward sees)
        double e2e = CloudSim.clock() - p.generationTime;            // sensor generation -> finish (true E2E)
        boolean deadlineMet = e2e <= p.deadlineMs;                   // == clock <= absoluteDeadline
        {
            Origin origin = origins.get(tuple.getCloudletId());
            if (origin != null) {
                origin.completed = CloudSim.clock();
                e2eCompleted++;
                e2eSum += origin.completed - origin.generated;
            }
            if (!auditE2E) {
                // no per-task audit output
            } else if (origin != null) {
                System.err.println("[rl-e2e] COMPLETED task=" + tid(tuple)
                        + " sensor=" + origin.sensor + " type=" + origin.tupleType
                        + " generated=" + origin.generated + " iotArrival=" + origin.firstIotArrival
                        + " decision=" + origin.decision + " targetArrival=" + p.targetArrivalTime
                        + " execSubmit=" + p.submitTime + " completed=" + origin.completed
                        + " sensorToDecision=" + (origin.decision-origin.generated)
                        + " decisionToFinish=" + latency
                        + " trueE2E=" + (origin.completed-origin.generated)
                        + " deadline=" + p.deadlineMs + " absoluteDeadline=" + p.absoluteDeadline
                        + " deadlineMet=" + deadlineMet);
            } else System.err.println("[rl-e2e] COMPLETION_WITHOUT_ORIGIN task=" + tid(tuple));
        }
        if (auditLatency) {
            double arrival = p.targetArrivalTime;
            double submit = p.submitTime;
            System.err.println("[rl-latency] FINISH task=" + tid(tuple)
                    + " action=" + NAMES[p.decidedAction] + " actual=" + executedOn.getName()
                    + " decision=" + p.decisionTime + " targetArrival=" + arrival
                    + " execSubmit=" + submit + " finish=" + CloudSim.clock()
                    + " decisionToArrival=" + (Double.isNaN(arrival) ? "NA" : String.valueOf(arrival-p.decisionTime))
                    + " arrivalToSubmit=" + (Double.isNaN(arrival) || Double.isNaN(submit) ? "NA" : String.valueOf(submit-arrival))
                    + " submitToFinish=" + (Double.isNaN(submit) ? "NA" : String.valueOf(CloudSim.clock()-submit))
                    + " decisionToFinish=" + latency);
        }
        boolean routingMatch = forcedAction >= 0 ? routingOk : executedOn.getId() == p.expectedDeviceId;
        if (routingMatch) routingMatched++; else routingMismatched++;
        if (auditRouting) {
            System.err.println("[rl-audit] COMPLETION task=" + tid(tuple)
                    + " decided=" + NAMES[p.decidedAction]
                    + " expectedId=" + p.expectedDeviceId
                    + " actual=" + executedOn.getName() + " actualId=" + executedOn.getId()
                    + " result=" + (routingMatch ? "MATCH" : "MISMATCH")
                    + " latency=" + latency + " simTime=" + CloudSim.clock());
        }
        int executedAction = forcedAction >= 0 ? forcedAction
                : (executedOn.getId() == p.entryDeviceId ? LOCAL : (executedOn.getParentId() <= 0 ? CLOUD : EDGE));
        JSONObject rm = new JSONObject();
        rm.put("bandwidth_bytes", num(forcedAction >= 0 ? bytes : (executedAction == LOCAL ? 0.0 : p.fileSize)));
        rm.put("executing_node_utilization", num(load(loadNode)));   // backlog-based load of the executing node (excl. this task)
        JSONObject o = msg("outcome");
        o.put("task_id", tid(tuple));
        o.put("action_executed", NAMES[executedAction]);
        o.put("status", "completed");
        o.put("latency_ms", num(latency));
        o.put("deadline_met", Boolean.valueOf(deadlineMet));
        o.put("resource_metrics", rm);
        o.put("terminal", Boolean.TRUE);
        o.put("sim_time_ms", num(CloudSim.clock()));
        doneCount[executedAction]++;
        latSum[executedAction] += latency;
        e2eSumByAction[executedAction] += e2e;
        if (!deadlineMet) missCount[executedAction]++;
        JSONObject r = call(o);
        outcomes++;
        if (r != null && "error".equals(r.get("type"))) {
            System.err.println("[rl] outcome rejected: " + r.toJSONString());
        }
    }

    // ------------------------------------------------------------------ end
    public synchronized void finish() {
        if (finished) return;
        finished = true;
        cutoffTime = CloudSim.clock();
        classifyPending();
        if (client == null) return;
        if (active && pendingAsFailed && auditLifecycle)
            System.err.println("[rl-lifecycle] WARNING rl.reportPendingAsFailed=true; pending tasks will be reported failed to agent (not recommended for this test)");
        if (active && pendingAsFailed) {
            for (Map.Entry<Integer, Pending> e : pending.entrySet()) {
                Pending p = e.getValue();
                JSONObject rm = new JSONObject();
                rm.put("bandwidth_bytes", num(p.decidedAction == LOCAL ? 0.0 : p.fileSize));
                JSONObject o = msg("outcome");
                o.put("task_id", "t-" + e.getKey());
                o.put("action_executed", NAMES[p.decidedAction]);
                o.put("status", "failed");
                o.put("failure_reason", "not_completed_by_simulation_end");
                o.put("latency_ms", null);
                o.put("deadline_met", Boolean.FALSE);
                o.put("resource_metrics", rm);
                call(o);
            }
        }
        if (active) {
            System.err.println("[rl-lifecycle] cutoffTime=" + CloudSim.clock()
                    + " completed=" + outcomes + " stillPending=" + pending.size()
                    + " (pending is not automatically a failed execution)");
            long pe = pendExpired[0] + pendExpired[1] + pendExpired[2], pw = pendWithin[0] + pendWithin[1] + pendWithin[2];
            System.err.println("[rl] PENDING_AT_CUTOFF decided_pending=" + pending.size()
                    + " deadline_already_passed=" + pe + " still_within_deadline=" + pw
                    + " | by action [expired/within] Local=" + pendExpired[0] + "/" + pendWithin[0]
                    + " Edge=" + pendExpired[1] + "/" + pendWithin[1] + " Cloud=" + pendExpired[2] + "/" + pendWithin[2]
                    + " | generated_but_undecided: deadline_already_passed=" + undecidedExpired
                    + " still_within_deadline=" + undecidedWithin
                    + " (deadline counted from sensor generation; 'passed' tasks are certain misses, 'within' are undetermined)");
            if (auditLifecycle) {
                long local=0, edge=0, cloud=0, arrived=0, submitted=0, inTransit=0, deadlineExpired=0;
                for (Pending task : pending.values()) {
                    if (task.decidedAction == LOCAL) local++;
                    else if (task.decidedAction == EDGE) edge++;
                    else cloud++;
                    if ("EXEC_SUBMIT".equals(task.lastStage)) submitted++;
                    else if ("ARRIVED".equals(task.lastStage)) arrived++;
                    else inTransit++;
                    if (cutoffTime > task.absoluteDeadline) deadlineExpired++;
                }
                System.err.println("[rl-lifecycle] CUTOFF_LEDGER decisions=" + decisions
                        + " completed=" + outcomes + " pending=" + pending.size()
                        + " reconcile=" + (decisions == outcomes + pending.size())
                        + " pendingLocal=" + local + " pendingEdge=" + edge + " pendingCloud=" + cloud
                        + " stageInTransitOrDecided=" + inTransit + " stageArrived=" + arrived
                        + " stageExecSubmit=" + submitted + " deadlineExpiredAmongPending=" + deadlineExpired);
                for (Map.Entry<Integer, Pending> entry : pending.entrySet()) {
                    Pending task = entry.getValue();
                    System.err.println("[rl-lifecycle] CUTOFF_TASK task=t-" + entry.getKey()
                            + " action=" + NAMES[task.decidedAction]
                            + " stage=" + task.lastStage + " lastNode=" + task.lastNode
                            + " lastStageTime=" + task.lastStageTime
                            + " generated=" + task.generationTime
                            + " decision=" + task.decisionTime + " age=" + (cutoffTime-task.decisionTime)
                            + " ageSinceGeneration=" + (cutoffTime-task.generationTime)
                            + " deadline=" + task.deadlineMs + " absoluteDeadline=" + task.absoluteDeadline
                            + " deadlineExpired=" + (cutoffTime > task.absoluteDeadline)
                            + " status=PENDING_AT_CUTOFF");
                }
            }
            if (auditLatency && !auditLifecycle) {
                for (Map.Entry<Integer, Pending> entry : pending.entrySet()) {
                    Pending task = entry.getValue();
                    System.err.println("[rl-lifecycle] PENDING task=t-" + entry.getKey()
                            + " action=" + NAMES[task.decidedAction]
                            + " age=" + (CloudSim.clock() - task.decisionTime)
                            + " deadline=" + task.deadlineMs
                            + " targetArrival=" + task.targetArrivalTime
                            + " submit=" + task.submitTime);
                }
            }
            if (auditE2E) {
                int generated=origins.size(), noIot=0, noDecision=0, decisionPending=0, done=0;
                for (Map.Entry<Integer, Origin> item : origins.entrySet()) {
                    int id=item.getKey(); Origin origin=item.getValue();
                    if (Double.isNaN(origin.firstIotArrival)) noIot++;
                    if (Double.isNaN(origin.decision)) noDecision++;
                    if (!Double.isNaN(origin.completed)) done++;
                    else if (!Double.isNaN(origin.decision)) decisionPending++;
                    if (Double.isNaN(origin.completed)) {
                        String status = Double.isNaN(origin.decision) ? "NO_DECISION_AT_CUTOFF" : "PENDING_AT_CUTOFF";
                        System.err.println("[rl-e2e] CUTOFF_TASK task=t-" + id + " status=" + status
                                + " sensor=" + origin.sensor + " generated=" + origin.generated
                                + " iotArrival=" + origin.firstIotArrival + " decision=" + origin.decision);
                    }
                }
                System.err.println("[rl-e2e] CUTOFF_LEDGER generated=" + generated
                        + " firstIotMissing=" + noIot + " noDecision=" + noDecision
                        + " decided=" + decisions + " completed=" + done
                        + " decidedPending=" + decisionPending
                        + " generatedReconcile=" + (generated==done+decisionPending+noDecision)
                        + " decisionsReconcile=" + (decisions==done+decisionPending)
                        + " avgTrueE2E=" + (e2eCompleted==0 ? "NA" : String.valueOf(e2eSum/e2eCompleted))
                        + " time=" + cutoffTime);
            }
            printSummary();
            JSONObject r = call(msg("shutdown"));
            System.err.println("[rl] finished: decisions=" + decisions + " outcomes=" + outcomes
                    + " fallbacks=" + fallbacks + " unreported=" + pending.size()
                    + (r != null ? " ack=" + r.toJSONString() : ""));
        }
        active = false;
        client.close();
    }

    /** At the cutoff: a pending task whose deadline (counted from sensor generation) has already passed is a certain miss. */
    private void classifyPending() {
        for (Pending q : pending.values()) {
            if (cutoffTime > q.absoluteDeadline) pendExpired[q.decidedAction]++; else pendWithin[q.decidedAction]++;
        }
        for (Origin o : origins.values()) {
            if (!Double.isNaN(o.completed) || !Double.isNaN(o.decision)) continue;   // finished or decided (covered above)
            if (cutoffTime - o.generated > o.deadlineMs) undecidedExpired++; else undecidedWithin++;
        }
    }

    // ------------------------------------------------------------------ summary
    private void printSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n[rl] ================== SUMMARY ==================\n");
        long totalDecided = decidedCount[0] + decidedCount[1] + decidedCount[2];
        long totalDone = doneCount[0] + doneCount[1] + doneCount[2];
        if (auditRouting) sb.append("[rl-audit] routing MATCH=" + routingMatched + " MISMATCH=" + routingMismatched + "\n");
        sb.append(String.format(Locale.ROOT, "[rl] decisions=%d  completed=%d  unreported=%d  fallbacks=%d%n",
                totalDecided, totalDone, pending.size(), fallbacks));
        sb.append(String.format(Locale.ROOT,
                "[rl] deadline = sensor generation + budget; unreported: already past deadline=%d, still within=%d; generated-but-undecided: past=%d, within=%d%n",
                pendExpired[0] + pendExpired[1] + pendExpired[2], pendWithin[0] + pendWithin[1] + pendWithin[2],
                undecidedExpired, undecidedWithin));
        for (int a = 0; a < 3; a++) {
            double share = totalDecided == 0 ? 0 : 100.0 * decidedCount[a] / totalDecided;
            double meanLat = doneCount[a] == 0 ? 0 : latSum[a] / doneCount[a];
            double meanE2e = doneCount[a] == 0 ? 0 : e2eSumByAction[a] / doneCount[a];
            double miss = doneCount[a] == 0 ? 0 : 100.0 * missCount[a] / doneCount[a];
            sb.append(String.format(Locale.ROOT,
                    "[rl]   %-5s chosen=%6d (%5.1f%%) | completed=%6d | mean latency=%8.2f (decision->finish) | mean E2E=%8.2f | deadline missed (E2E)=%5.1f%%%n",
                    NAMES[a], decidedCount[a], share, doneCount[a], meanLat, meanE2e, miss));
        }
        JSONObject s = call(msg("summary"));
        if (s != null && "summary".equals(s.get("type"))) {
            sb.append(String.format(Locale.ROOT, "[rl] epsilon now=%s  updates=%s  (Q = expected reward, closer to 0 is better)%n",
                    s.get("epsilon"), s.get("updates")));
            sb.append("[rl] Learned policy per state (greedy action among tried actions):\n");
            JSONArray states = (JSONArray) s.get("states");
            if (states != null) {
                for (Object o : states) {
                    JSONObject st = (JSONObject) o;
                    JSONArray q = (JSONArray) st.get("q");
                    JSONArray v = (JSONArray) st.get("visits");
                    sb.append(String.format(Locale.ROOT, "[rl]   %-52s -> %-5s  Q[L,E,C]=[%s, %s, %s]  visits=[%s, %s, %s]%n",
                            st.get("label"), st.get("greedy"),
                            qv(q, v, 0), qv(q, v, 1), qv(q, v, 2), v.get(0), v.get(1), v.get(2)));
                }
            }
        } else {
            sb.append("[rl] (no policy summary available from the agent)\n");
        }
        if (partial != null) sb.append(partial.summary(partial.openTasks()));
        sb.append("[rl] =============================================\n");
        System.err.print(sb.toString());
    }

    private static String qv(JSONArray q, JSONArray v, int i) {
        if (((Number) v.get(i)).longValue() == 0) return "  n/a ";
        return String.format(Locale.ROOT, "%6.3f", ((Number) q.get(i)).doubleValue());
    }

    /** Load estimate in [0,1]: (work in flight on the device / its MIPS) / rl.backlogCapMs, clipped. */
    private double load(FogDevice d) {
        Double mi = backlogMi.get(d.getId());
        if (mi == null || mi <= 0) return 0.0;
        double mips = d.rlTotalMips();
        if (mips <= 0) return 1.0;
        return Math.min(1.0, (mi / mips) / backlogCapMs);
    }

    // ------------------------------------------------------------------ helpers
    private JSONObject call(JSONObject m) {
        try {
            String line = client.request(m.toJSONString());
            ioFailures = 0;
            return (JSONObject) parser.parse(line);
        } catch (IOException e) {
            System.err.println("[rl] I/O problem: " + e.getMessage());
            if (++ioFailures >= 3) {
                System.err.println("[rl] too many failures: RL disabled, default iFogSim behaviour from now on");
                active = false;
            }
            return null;
        } catch (ParseException e) {
            System.err.println("[rl] unparsable reply: " + e);
            return null;
        }
    }

    private static JSONObject msg(String type) {
        JSONObject m = new JSONObject();
        m.put("protocol_version", V);
        m.put("type", type);
        return m;
    }

    private static String tid(Tuple t) {
        return "t-" + t.getCloudletId();
    }

    private static Double num(double x) {
        if (Double.isNaN(x) || Double.isInfinite(x) || x < 0) return Double.valueOf(0.0);
        return Double.valueOf(x);
    }

    /** Top of the tree reached by following parent ids (the cloud in the usual topologies). */
    private static FogDevice topOf(FogDevice dev) {
        FogDevice cur = dev;
        while (cur.getParentId() > 0) {
            SimEntity next = CloudSim.getEntity(cur.getParentId());
            if (!(next instanceof FogDevice)) break;
            cur = (FogDevice) next;
        }
        return cur;
    }

    /** Sum of uplink latencies from 'from' up to 'to' (iFogSim clock units, taken as ms). */
    static double pathLatency(FogDevice from, FogDevice to) {
        double sum = 0;
        FogDevice cur = from;
        while (cur != null && cur != to && cur.getParentId() > 0) {
            sum += cur.getUplinkLatency();
            SimEntity next = CloudSim.getEntity(cur.getParentId());
            cur = (next instanceof FogDevice) ? (FogDevice) next : null;
        }
        return sum;
    }
}
