#!/usr/bin/env python3
"""Train the RL agent on SEVERAL random topologies one after the other, then evaluate it (and the fixed baselines)
on NEW topologies it has never seen.

One simulation = one topology (iFogSim cannot rebuild its world inside one JVM), so "training on many topologies" is a
chain of runs: run k starts from the model saved by run k-1 (-Drl.modelIn / -Drl.modelOut). The learning state, including
the epsilon schedule counter, is carried along in the model file.

Example (from the project root, after compiling; 'bin' = your compiled classes folder):
    python tools/run_topology_curriculum.py --classes bin --train-seeds 1-8 --test-seeds 101-104 --sim-time 20000

Everything goes to --out (default rl_model/artifacts/curriculum): models, logs, topology files, summary.csv.
Nothing here changes the agent, the reward or the state: it only launches the existing main class with VM options.
"""
import argparse
import csv
import glob
import json
import os
import statistics
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

MAIN = "org.fog.test.perfeval.RandomEdgeCloudOffloadingRL"


def parse_seeds(text):
    seeds = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            lo, hi = part.split("-", 1)
            seeds.extend(range(int(lo), int(hi) + 1))
        else:
            seeds.append(int(part))
    if len(set(seeds)) != len(seeds):
        raise SystemExit(f"duplicate seeds in {text!r}")
    return seeds


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--classes", required=True, help="folder with the compiled classes (e.g. bin, out/production/...)")
    ap.add_argument("--train-seeds", required=True, help='topology seeds to train on, in order, e.g. "1-8" or "1,2,5"')
    ap.add_argument("--test-seeds", required=True, help='NEW topology seeds for evaluation, e.g. "101-104"')
    ap.add_argument("--sim-time", type=int, default=20000)
    ap.add_argument("--agent-seed", type=int, default=1)
    ap.add_argument("--train-workload-base", type=int, default=0, help="train workload seed = base + topology seed")
    ap.add_argument("--test-workload-base", type=int, default=5000, help="test workload seed = base + topology seed")
    ap.add_argument("--baselines", default="local,edge,cloud", help="comma list, or '' to skip")
    ap.add_argument("--jobs", type=int, default=2, help="parallel evaluation/baseline runs")
    ap.add_argument("--home", default="rl_model", help="rl.home (model folder)")
    ap.add_argument("--config", default=None, help="rl.config (default: <home>/config/edge_cloud_scenario.json)")
    ap.add_argument("--out", default=None, help="output folder (default: <home>/artifacts/curriculum)")
    ap.add_argument("--java", default="java")
    ap.add_argument("--python", default="python")
    ap.add_argument("--gui", action="store_true", help="show the topology window (default: headless)")
    ap.add_argument("--vm", action="append", default=[], help="extra VM option, e.g. --vm=-Dtopo.wanLat.max=100 (repeatable)")
    ap.add_argument("--dry-run", action="store_true", help="print the commands only")
    a = ap.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    home = os.path.abspath(a.home)
    config = os.path.abspath(a.config or os.path.join(home, "config", "edge_cloud_scenario.json"))
    out = os.path.abspath(a.out or os.path.join(home, "artifacts", "curriculum"))
    logs = os.path.join(out, "logs")
    train, test = parse_seeds(a.train_seeds), parse_seeds(a.test_seeds)
    if set(train) & set(test):
        raise SystemExit(f"train and test topology seeds overlap: {sorted(set(train) & set(test))}")
    jars = glob.glob(os.path.join(root, "jars", "*.jar")) + glob.glob(os.path.join(root, "jars", "commons-math3-3.5", "*.jar"))
    cp = os.pathsep.join([os.path.abspath(a.classes)] + jars)
    os.makedirs(logs, exist_ok=True)
    train_spec = f"{min(train)}-{max(train)}" if train == list(range(min(train), max(train) + 1)) else ",".join(map(str, train))

    def run(name, extra):
        cmd = [a.java, "-Drl.enabled=true", f"-Drl.home={home}", f"-Drl.config={config}", f"-Drl.python={a.python}",
               f"-Drl.runId={name}", f"-Drl.logDir={logs}", f"-Drl.artifactsDir={out}", f"-Dtopology.logDir={logs}",
               f"-Dtopology.trainSeeds={train_spec}", f"-Dsim.time={a.sim_time}", f"-Drl.agentSeed={a.agent_seed}"]
        cmd += ["-Dtopology.seconds=1"] if a.gui else ["-Djava.awt.headless=true"]
        cmd += a.vm + extra + ["-cp", cp, MAIN]
        if a.dry_run:
            print(" ".join(f'"{c}"' if " " in c else c for c in cmd))
            return
        err_path = os.path.join(logs, f"{name}.stderr")
        with open(os.path.join(logs, f"{name}.stdout"), "w", encoding="utf-8") as so, \
                open(err_path, "w", encoding="utf-8") as se:
            rc = subprocess.call(cmd, stdout=so, stderr=se, cwd=root)
        err = open(err_path, encoding="utf-8", errors="replace").read()
        ok = rc == 0 and os.path.exists(os.path.join(logs, f"run_{name}.jsonl")) and "Unwanted errors happen" not in err
        if not ok:
            lines = [l for l in err.splitlines() if "Exception" in l or "REFUSED" in l or "ERROR" in l]
            raise SystemExit(f"run {name} FAILED (rc={rc}). See {err_path}\n  " + "\n  ".join(lines[:5]))
        print(f"  done {name}")

    # ------------------------------------------------------------------ 1) sequential training
    print(f"TRAIN on topologies {train} (sim.time={a.sim_time}), chained models in {out}")
    prev = None
    for seed in train:
        name = f"train-t{seed}"
        model = os.path.join(out, f"model_after_t{seed}.json")
        extra = ["-Drl.mode=train", "-Drl.phase=train", f"-Drl.simSeed={a.train_workload_base + seed}",
                 f"-Dtopology.seed={seed}", f"-Drl.modelOut={model}"]
        if prev:
            extra.append(f"-Drl.modelIn={prev}")
        run(name, extra)
        prev = model
    final_model = prev

    # ------------------------------------------------------------------ 2) evaluation + baselines on NEW topologies
    print(f"EVAL on unseen topologies {test} with {os.path.basename(final_model) if final_model else '(dry run)'}")
    jobs = []
    for seed in test:
        w = a.test_workload_base + seed
        common = ["-Drl.phase=test", f"-Drl.simSeed={w}", f"-Dtopology.seed={seed}"]
        jobs.append((f"eval-t{seed}", ["-Drl.mode=eval", f"-Drl.modelIn={final_model}"] + common))
        for pol in [p for p in a.baselines.split(",") if p]:
            jobs.append((f"base-{pol}-t{seed}", ["-Drl.mode=baseline", f"-Drl.policy={pol}"] + common))
    with ThreadPoolExecutor(max_workers=max(1, a.jobs)) as ex:
        for f in [ex.submit(run, n, e) for n, e in jobs]:
            f.result()
    if a.dry_run:
        return

    # ------------------------------------------------------------------ 3) summary
    def stats(name):
        tasks = [json.loads(l) for l in open(os.path.join(logs, f"run_{name}.jsonl"), encoding="utf-8")]
        tasks = [x for x in tasks if x["record"] == "task"]
        lat = [x["outcome"]["latency_ms"] for x in tasks if x["outcome"].get("latency_ms") is not None]
        mix = {k: sum(1 for x in tasks if x["action_executed"] == k) for k in ("Local", "Edge", "Cloud")}
        return dict(n=len(tasks), reward=statistics.mean(x["reward"]["reward"] for x in tasks),
                    latency=statistics.mean(lat) if lat else float("nan"),
                    miss=100.0 * statistics.mean(x["reward"]["deadline_miss"] for x in tasks),
                    mix="/".join(str(mix[k]) for k in ("Local", "Edge", "Cloud")))

    pols = ["eval"] + [p for p in a.baselines.split(",") if p]
    rows = []
    print("\nmean reward per task on UNSEEN topologies (higher is better); agent mix = Local/Edge/Cloud task counts")
    print(f"{'topology':>9} " + " ".join(f"{p:>9}" for p in pols) + "   best      agent mix")
    for seed in test:
        res = {p: stats(f"eval-t{seed}" if p == "eval" else f"base-{p}-t{seed}") for p in pols}
        best = max(res, key=lambda p: res[p]["reward"])
        print(f"{seed:>9} " + " ".join(f"{res[p]['reward']:9.3f}" for p in pols) + f"   {best:8s}  {res['eval']['mix']}")
        for p in pols:
            rows.append(dict(topology_seed=seed, policy="agent" if p == "eval" else p, **res[p]))
    mean_by = {p: statistics.mean(r["reward"] for r in rows if r["policy"] == ("agent" if p == "eval" else p)) for p in pols}
    print(f"{'mean':>9} " + " ".join(f"{mean_by[p]:9.3f}" for p in pols))
    with open(os.path.join(out, "summary.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["topology_seed", "policy", "n", "reward", "latency", "miss", "mix"])
        w.writeheader()
        w.writerows(rows)
    print(f"\nfiles: {os.path.join(out, 'summary.csv')}, models model_after_t*.json (+ .topologies.json ledgers), logs in {logs}")


if __name__ == "__main__":
    sys.exit(main())
