# Random Topology Mode (V5)

Main class: `org.fog.test.perfeval.RandomEdgeCloudOffloadingRL` (الـ Fixed ما اتغيّرش: `EdgeCloudOffloadingRL` زي ما هو).

## الـ 3 seeds (مستقلين)
| Seed | الخيار | بيتحكم في |
|---|---|---|
| Topology | `-Dtopology.seed=N` | الهيكل (عدد Edge/IoT، MIPS، bandwidth، latency) وبروفايل المهام لكل IoT (الأنواع والمعدل) |
| Workload | `-Drl.simSeed=M` (أو `-Dworkload.seed=M`، خلّيهم نفس القيمة) | أزمنة وصول المهام العشوائية بس |
| Agent | `-Drl.agentSeed=K` | عشوائية الـ agent في Python |

## نطاقات الـ generator (الإصدار v2، كلها قيم تطويرية مش معايَرة)
- Edge nodes 1..4، IoT لكل Edge 1..4، IoT MIPS 50..250، Edge MIPS 200..1000، Cloud MIPS 20000..50000.
- IoT→Edge latency 2..15، **Edge→Cloud (WAN) 5..150 بتوزيع log-uniform** (فبيوصل لـ bin `low` أقل من 20).
- **ضغط الـ Edge:** كل Edge ليه مُضاعِف لمعدل وصول مهام الـ IoT بتوعه (0.6..2.0)، فبعض الـ Edges بتتشبّع.
- **سقف الحمل:** IoT ما يتعرضش عليه أكتر من 2× MIPS بتاعه، والـ Edge أكتر من 2× MIPS بتاعه (لو كل المهام راحت له). بيتغيّر بـ `-Dtopo.iotMaxUtil` و`-Dtopo.edgeMaxUtil`.
- أي حد بيتغيّر بـ `-Dtopo.*` (راجع `RandomTopologyGenerator.Config.fromSystemProperties`). معاينة بدون سيميولاشن:
  `java -cp <classes>;<jars> org.fog.test.perfeval.RandomTopologyGenerator 7`

## الحماية من التسريب (train/test)
1. **مربوط بالموديل:** كل تدريب بيكتب `<model>.json.topologies.json` جنب الموديل (seeds والـ fingerprints اللي اتدرّب عليها، ومتراكمة لو كملت من `rl.modelIn`). أي `eval` بـ `rl.modelIn` على topology من دول بيتقفل، حتى لو الـ log folder أو الـ phase مختلف. للتخطي عن قصد: `-Dtopology.allowOverlap=true`.
2. `-Dtopology.trainSeeds=1-8`: التدريب لازم يكون جواها، والتقييم لازم يكون برّاها.
3. سجل `topologies.jsonl` (في `topology.logDir`) بيسجّل كل run.

## VM options جاهزة (استبدل D:/... بمسارك)
مشترك (الصق في كل run):
```
-Drl.enabled=true
-Drl.home="D:/computer network research/iFogSim2 (The New Version)/iFogSim-main-rl-v5/iFogSim-main/rl_model"
-Drl.config="D:/computer network research/iFogSim2 (The New Version)/iFogSim-main-rl-v5/iFogSim-main/rl_model/config/edge_cloud_scenario.json"
-Drl.python=python
-Dsim.time=20000
-Dtopology.trainSeeds=1-8
-Dtopology.seconds=1
```
**تدريب على topology 1** (الأولى، من غير modelIn):
```
-Drl.mode=train -Drl.phase=train -Drl.runId=train-t1 -Drl.agentSeed=1
-Dtopology.seed=1 -Drl.simSeed=1
-Drl.modelOut=artifacts/model_after_t1.json
```
**تدريب على topology 2** (كمّل من اللي قبلها، وكرّر بنفس النمط لحد 8):
```
-Drl.mode=train -Drl.phase=train -Drl.runId=train-t2 -Drl.agentSeed=1
-Dtopology.seed=2 -Drl.simSeed=2
-Drl.modelIn=artifacts/model_after_t1.json
-Drl.modelOut=artifacts/model_after_t2.json
```
**تقييم على topology جديدة** (101 مش في 1-8):
```
-Drl.mode=eval -Drl.phase=test -Drl.runId=eval-t101 -Drl.agentSeed=1
-Dtopology.seed=101 -Drl.simSeed=5101
-Drl.modelIn=artifacts/model_after_t8.json
```
**Baseline** على نفس الـ topology (غيّر `edge` لـ `local` أو `cloud`):
```
-Drl.mode=baseline -Drl.policy=edge -Drl.phase=test -Drl.runId=base-edge-t101
-Dtopology.seed=101 -Drl.simSeed=5101
```
المسارات النسبية (`artifacts/...`) بتتحسب من `rl.home` مهما كان الـ working directory.

## من سطر الأوامر (بدل Eclipse): كل الـ curriculum بأمر واحد
```
python tools/run_topology_curriculum.py --classes bin --train-seeds 1-8 --test-seeds 101-104 --sim-time 20000
```
بيدرّب على الـ topologies بالترتيب (كل run بيكمّل من موديل اللي قبله)، وبعدين بيقيّم الـ agent و3 baselines على topologies جديدة، ويطبع جدول ويكتب `summary.csv`. ملاحظة: `epsilon_decay_steps` (8000 قرار) بيتستهلك في أول topology، فكبّره في الـ config بما يناسب عدد الـ topologies.
