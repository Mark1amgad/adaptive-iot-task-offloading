# Partial Offloading (تقسيم المهمة)

مسار تنفيذ للمهام القابلة للتقسيم. **مقفول افتراضيًا** (`-Drl.partial.enabled=true` لتفعيله)، ولما يكون مقفول السلوك القديم ما بيتغيرش.

## الفكرة
الـ agent بيقرر زي ما هو (Local / Edge / Cloud). بعد القرار، لو التفعيل شغّال:

| قرار الـ agent | اللي بيتنفّذ |
|---|---|
| Local | المهمة كاملة محلي (زي الأول) |
| Edge | فرع محلي + فرع على الـ Edge |
| Cloud | فرع محلي + فرع على الـ Cloud |

نسبة الجزء البعيد: **25% أو 50% أو 75%** (`rl.partial.ratios`). الـ State والـ Reward والـ Algorithm والـ protocol ما اتغيروش.

## خط الزمن للمهمة الواحدة
```
قرار ──partition──▶ فرع محلي: CPU الـ IoT ────────────────────────────┐
                    فرع بعيد: uplink (queues حقيقية) ─▶ CPU الـ Edge/Cloud ─▶ رجوع النتيجة ─┴─▶ merge ─▶ FINAL
```
`FINAL = max(نهاية الفرع المحلي, وصول النتيجة) + زمن الدمج`

الفرعين بيخرجوا في نفس اللحظة وبيشتغلوا بالتوازي. **FINAL** هو زمن الإكمال الوحيد للمهمة، وهو اللي بيتبعت للـ agent كـ `latency_ms` (من القرار) و`deadline_met` (E2E من لحظة توليد الـ Sensor). ناتج واحد لكل مهمة.

## اللي بيتحسب
| الخطوة | إزاي |
|---|---|
| Partitioning | تأخير = `partitionBaseMs + partitionPerMi × MI` على الـ IoT |
| إرسال الفرع البعيد | الـ link queues والـ bandwidth والـ latency الحقيقية، hop by hop |
| تنفيذ الفرعين | CPU حقيقي في الجهازين (يتأثر بالـ backlog) |
| رجوع النتيجة | تأخير تحليلي = مجموع (latency + bytes ÷ downlink bandwidth) لكل hop، من غير queue |
| Merging | تأخير = `mergeBaseMs + mergePerMi × MI` على الـ IoT |

## الخيارات
| الخيار | الافتراضي | المعنى |
|---|---|---|
| `rl.partial.enabled` | false | تشغيل المسار |
| `rl.partial.ratios` | 0.5 | نسبة الجزء البعيد: 0.25 / 0.5 / 0.75، وممكن قايمة (`0.25,0.5,0.75`) بتتكرر بالتناوب على المهام المقسّمة |
| `rl.partial.targets` | Edge,Cloud | أي قرارات تتقسم: `Edge` أو `Cloud` أو الاتنين |
| `rl.partial.minMi` | 0 | المهام الأقصر من كده مش قابلة للتقسيم (والحد الأدنى 2 MI) |
| `rl.partial.partitionBaseMs` / `partitionPerMi` | 0.5 / 0.0005 | زمن التقسيم |
| `rl.partial.mergeBaseMs` / `mergePerMi` | 0.5 / 0.0005 | زمن الدمج |
| `rl.partial.resultRatio` | 0.1 | حجم النتيجة = النسبة × حجم الفرع البعيد |

قيم الـ partition والـ merge وحجم النتيجة **افتراضات (TO CONFIRM)**، مش من قياس حقيقي.

## VM options جاهزة
أضفها فوق الـ options العادية:
```
-Drl.partial.enabled=true
-Drl.partial.ratios=0.5
```
كل النسب بالتناوب: `-Drl.partial.ratios=0.25,0.5,0.75`
Local+Edge بس: `-Drl.partial.targets=Edge`
Local+Cloud بس: `-Drl.partial.targets=Cloud`

مع baseline: `-Drl.mode=baseline -Drl.policy=edge` (أو `cloud`) بيدّيك Local+Edge (أو Local+Cloud) ثابت لكل المهام.

## المخرجات
1. **`partial_<runId>.csv`** في فولدر `rl.logDir`: صف لكل مهمة مقسّمة فيه كل الأزمنة (decision, partition_done, local_finish, remote_send, remote_finish, result_transfer, result_arrival, merge, final_completion)، والفرع الحرج (`critical_branch`)، وعمود `formula_ok` اللي بيتأكد إن `final = max(local, result) + merge`.
2. سطر في الـ SUMMARY: `[rl] PARTIAL split=… merged=… (25%=… 50%=… 75%=…)` ومتوسطات الأزمنة.
3. `run_start.simulator.partial_offloading` في لوج الـ Python (النسب والأهداف).

## حدود معروفة
- المهام المقسّمة بتتحسب في الـ outcome بالـ action اللي الـ agent قرره (Edge أو Cloud)، مش Local.
- الفرع المحلي والبعيد بيتحسبوا في الـ backlog على الجهاز اللي بينفّذهم.
- التطبيق الحالي (`processing` من غير output edges) ما فيهوش tuples تانية بعد المعالجة. لو تطبيق ليه output edges، فروع المهمة المقسّمة **ما بتولّدش** tuples تالية (ومفيش tuple مدموج بتتولّد).
- رجوع النتيجة والـ partition والـ merge تأخيرات تحليلية، من غير تنافس على CPU أو queue.
- لو المهمة اتقسمت وما خلصتش قبل الـ cutoff، بتتحسب pending بنفس القرار (Edge أو Cloud) زي أي مهمة تانية.
- الـ agent لسه ما بيختارش النسبة بنفسه. النسبة بتتحدد بالـ option.
