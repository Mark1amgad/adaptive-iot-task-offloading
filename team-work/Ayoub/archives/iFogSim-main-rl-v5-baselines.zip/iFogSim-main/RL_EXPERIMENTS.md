# Baselines والـ Experiment Runner (Priority 4)

## الـ Baselines
| السياسة | الاستخدام | الفكرة |
|---|---|---|
| Local-only | `-Drl.mode=baseline -Drl.policy=local` | كل المهام محلي |
| Edge-only | `-Drl.policy=edge` | كل المهام على الـ Edge |
| Cloud-only | `-Drl.policy=cloud` | كل المهام على الـ Cloud |
| **EPCT** (جديد) | `-Drl.policy=epct` | أقل زمن إكمال متوقع |

### EPCT: Earliest Predicted Completion Time
- **Deterministic وغير معايَر:** مفيش تعلّم ولا تصحيح من نتايج سابقة، ولا عشوائية. لو التقديرين اتساووا بيختار الأقل ترتيبًا: Local ثم Edge ثم Cloud.
- **نموذج التوقيت (`TimingModel.java`)** هو نفس معادلات الـ simulator ونفس تعريف الـ latency اللي بيتقاس بيه الـ outcome (قرار ← نهاية التنفيذ):
  `النقل = Σ (bytes ÷ bandwidth الـ hop + latency الـ hop)` على المسار من الـ IoT للهدف، و`الانتظار + التنفيذ = (الشغل المتراكم على الهدف + MI المهمة) ÷ MIPS الهدف`.
  الشغل المتراكم هو نفس الـ backlog اللي بيتتبّعه الـ manager.
- **حدود:** مفيش queueing على الـ links، ولا time-sharing للـ CPU، ولا رجوع نتيجة. EPCT بيختار بين الأفعال الكاملة التلاتة بس (action space الحالي). الأفعال الـ partial مش مدخلة فيه.
- **التنفيذ:** Java بيحسب التقديرات ويبعتها في حقل اختياري `policy_hint` جوه الـ observation. Python بياخد argmin من التقديرات ويسجّلها في task record. الـ Q-learning بيتجاهل الحقل ده، والـ state ما اتغيرش.
- **لازم تستبدل فولدر `rl_model` بالجديد** (البروتوكول والـ server اتعدّلوا). اتعدّل `protocol.py` و`server.py` و`run_plan.py` والـ schema و`docs/PROTOCOL.md`.
- تسجيل التوقعات لأي سياسة (بما فيها الـ agent) من غير ما تأثر على القرار: `-Drl.logPredictions=true`. بيظهر في `task_metrics_<runId>.csv` عمودين: `predicted_completion_ms` و`prediction_error_ms` (الفعلي − المتوقع)، وده أساس المعايرة بعدين.

## الـ Runner: عدة workload seeds لكل test topology
```
python tools/run_topology_curriculum.py --classes bin --train-seeds 1-8 --test-seeds 101-104 ^
    --test-workload-seeds 1-5 --sim-time 20000 --epsilon-decay-steps auto
```
- لكل (test topology, workload seed): الـ agent وكل الـ baselines (local, edge, cloud, epct بشكل افتراضي) بيشتغلوا على **نفس** الـ topology ونفس الـ workload (`-Dtopology.seed` و`-Drl.simSeed` نفسهم).
- **التحقق من الـ pairing:** من الـ ledger بتاع كل run بيتأكد إن كل السياسات شافت نفس المهام (نفس الـ ids وأزمنة التوليد)، وبيطبع `PAIRING: OK` أو `NOT PAIRED`.
- **الفصل:** الـ topology seeds للـ train والـ test ما ينفعش يتقاطعوا، وكمان الـ workload seeds (train = `train-workload-base + seed`، test = `test-workload-base + workload seed`) ما ينفعش يتقاطعوا. وحارس Java بيرفض تقييم الموديل على topology اتدرّب عليها.
- من غير `--test-workload-seeds` السلوك القديم (seed واحد لكل topology).
- **الجداول:** جدول لكل (topology, workload seed)، وجدول لكل سياسة (reward وSE عبر الـ topologies، `ontime/gen%` و`completed%` و`mean E2E`)، وجدول الفرق المزدوج `agent − baseline` (المتوسط وSE ونسبة الفوز). الملفات: `summary.csv` و`paired_summary.csv`.
- الـ reward بيحسب المهام اللي خلصت بس، فقارنه مع `completed%` و`ontime/gen%` (المقام كل المهام المتولدة) عشان سياسة ما تبانش أحسن لمجرد إنها سابت مهام معلّقة.
- الـ SE محسوب بين الـ topologies (هي وحدة التعميم)، مش بين الـ seeds الفردية.

## مراجعة epsilon decay
الـ epsilon بيتناقص خطيًا من `epsilon_start` لـ `epsilon_end` على `epsilon_decay_steps` **قرار**، والعداد محفوظ في الموديل فبيكمل عبر الـ topologies.
- القيم الحالية: 8000 في `edge_cloud_scenario.json`، و16000 في `default.json`.
- تقدير حسابي من معدلات الوصول في الـ Fixed (متوسط inter-arrival لكل IoT: 10 و40 و120 ms على 20000 ms): ~10.7 ألف قرار في الـ run الواحد. يعني الـ 8000 بتخلص جوه أول topology تقريبًا، وباقي التدريب بيجري على epsilon=0.02. لو درّبت على 8 topologies (~85 ألف قرار) يبقى الاستكشاف على ~10% بس من القرارات. ده تقدير مش قياس (الـ random topologies معدلها مختلف).
- الحل في الـ runner:
  - `--epsilon-decay-steps auto`: يعدّ قرارات كل training topology بـ run baseline سريع بدون تعلّم، وبيحط `S = 0.5 × D` (قابلة للتغيير بـ `--epsilon-decay-fraction`) في نسخة config مشتقة `config_epsilon.json`، بدون ما يلمس ملفك.
  - `--epsilon-decay-steps 40000`: قيمة ثابتة.
  - في آخر كل تشغيل بيطبع `EPSILON REVIEW`: عدد القرارات الفعلي D وS وقيمة epsilon عند نهاية التدريب ومتوسطه، وتحذير لو S أكبر من ضعف D (الـ agent ما بيوصلش لمرحلة الاستغلال) أو لو الاستكشاف خلص بدري جدًا.
- الاختيار `0.5 × D` توصية مني (نص التدريب استكشاف ونصه استغلال)، مش رقم معاير.
