# ربط Workload Dataset (Abdo V1.1.1) بالـ Simulator

Main class جديد: `org.fog.test.perfeval.DatasetEdgeCloudOffloadingRL`. نفس التوبولوجي الثابتة (4 IoT / 2 Edge / 1 Cloud)، لكن المهام بتتعاد من ملف الـ generator بدل ما تتولّد عشوائي. `EdgeCloudOffloadingRL` و`RandomEdgeCloudOffloadingRL` ما اتغيروش.

## اللي بيتحفظ زي ما هو من الـ dataset
| الحاجة | إزاي |
|---|---|
| Task ID | الـ `task_id` بتاع الـ dataset هو نفسه اللي بيتبعت للـ agent وبيظهر في لوج Python وملفات الـ outcome |
| Arrival time | `DatasetSensor` بيطلّع كل مهمة عند `arrival_time_ms` بالظبط (latency الـ sensor = 0)، ولو في فرق بيطبع تحذير |
| Urgency class | موجودة في `dataset_audit_<runId>.csv` (البروتوكول مع Python ما بيقبلش حقول زيادة، فمفيش urgency في الـ state) |
| Deadlines | `relative_deadline_ms` و`absolute_deadline_ms` من الملف. الـ simulator **ما بيولّدش deadline**: الخيارات `rl.deadlineMs` و`rl.deadlineBaseMs` و`rl.deadlinePerMi` بتتجاهل في الوضع ده |
| الحجم | `required_mi` و`input_size_bytes` و`output_size_bytes` من الصف |
| Divisibility | `splittability` + overheads الـ partition/merge من الصف نفسه (مش من الافتراضات بتاعة Priority 1) |

الـ deadline_met = `completion_time <= absolute_deadline_ms` (E2E من لحظة الـ arrival).

## Loader صارم
أي مخالفة بتوقف التشغيل برقم السطر: `absolute != arrival + relative`، `task_id` مكرر، `units_version` غير `SI-ms-bytes-MI-v1`، urgency أو splittability غير معروفة، حقول partition على مهمة indivisible، أو partition model غير `PROPORTIONAL_TO_COMPUTE_ALPHA`، أو `required_mi` مش رقم صحيح. وبيتحقق من الـ manifest (`run_id` و`task_count`) لو موجود.

## Legal actions
| نوع المهمة | الأفعال المسموحة |
|---|---|
| `INDIVISIBLE` | `LOCAL` و`EDGE_FULL` و`CLOUD_FULL` |
| `DATA_PARALLEL_DIVISIBLE` | دول + `EDGE_PARTIAL_25/50/75` و`CLOUD_PARTIAL_25/50/75` |

- مسار الـ Partial (`rl.partial.enabled=true`) بيتطبق **على المهام القابلة للتقسيم بس**. المهمة indivisible بتتنفّذ دايمًا كاملة.
- فيه فحص صريح قبل التنفيذ (`LegalActions`)، وأي فعل غير legal بيتم رفضه وبيتعدّ في `illegal_actions_blocked`. وبعد الإكمال كل فعل بيتراجع، والعداد `illegal_actions_executed` لازم يطلع 0.
- الـ agent لسه عنده 3 أفعال (Local / Edge / Cloud) كلها legal للنوعين. اختيار الـ agent للنسبة (partial بـ25/50/75) محتاج توسيع action space في Python، وده مش اتعمل.

## VM options (Eclipse)
Main class: `org.fog.test.perfeval.DatasetEdgeCloudOffloadingRL`
```
-Drl.enabled=true
-Ddataset.tasks=dataset/abdo_v1_1_1/dev/stable_steady__seed_0007_tasks.csv
-Drl.mode=baseline
-Drl.policy=edge
-Drl.runId=ds_stable_edge
```
مع تقسيم المهام القابلة للتقسيم:
```
-Drl.partial.enabled=true
-Drl.partial.ratios=0.25,0.5,0.75
```
تدريب / تقييم: `-Drl.mode=train -Drl.modelOut=...` أو `-Drl.mode=eval -Drl.modelIn=...` (زي الباقي).

اختيارية: `-Ddataset.manifest=...` (الافتراضي نفس الاسم بـ `_scenario_manifest.csv`)، `-Ddataset.drainMs=10000` (وقت بعد آخر arrival، الافتراضي أطول deadline في الـ generator)، `-Dsim.time=...` (الافتراضي = آخر arrival + drain + 1).
المسار النسبي للملف بيتدوّر عليه من مكان تشغيل الـ JVM وبعدين من فولدر المشروع.

## المخرجات (في `rl.logDir`)
- **`dataset_outcomes_<runId>.csv`**: أعمدة `task_outcomes.schema.json`، صف نهائي واحد لكل مهمة. الحالات: `ON_TIME` و`LATE` و`UNRESOLVED_AT_HORIZON` (`FAILED` غير موجودة لأن الـ simulator مفيهوش failure handling).
- **`dataset_audit_<runId>.csv`**: قيم الـ dataset جنب القيم اللي الـ simulator استخدمها (`deadline_preserved`، `action_legal`، legal_actions).
- سطر `[rl] DATASET …` في الـ SUMMARY: العدد والحالات و`deadline_changed` (لازم 0) و`illegal_actions_*`.
- لوج Python: `run_start.simulator` فيه `dataset_run_id` و`dataset_config_hash` و`dataset_tasks_sha256`.
- `python tools/check_dataset_replay.py --tasks … --audit … --outcomes …` بيقارن الـ ids والـ arrivals والـ urgency والـ deadlines والأفعال بالـ dataset (قراءة فقط).

المهمة اللي ما خلصتش قبل الـ cutoff بتتسجل `UNRESOLVED_AT_HORIZON` من غير `deadline_met` (null مش miss)، وسبب الـ unresolved وهل الـ deadline فات ولا لأ في عمود `failure_or_unresolved_reason`.

## افتراضات وحدود (TO CONFIRM)
1. **ربط المصادر:** `iot-01…iot-04` ← الأجهزة `iot-1…iot-4` في التوبولوجي. الـ spec بيقول إن الربط ده لسه محتاج تأكيد.
2. **ظروف الـ manifest ما بتتطبقش:** `bandwidth_scale` و`WAN delay` (45/90) و`edge capacity scale` بتاعة السيناريوهات مش بتتغير في التوبولوجي. المهام بس هي اللي بتتعاد. يعني سيناريوهات `reduced_bandwidth` و`increased_wan_delay` و`reduced_edge_capacity` بتشتغل بنفس التوبولوجي العادية لحد ما نقرر نطبّقها. وكمان قدرات الأجهزة (100/300/20000 MIPS) هي قيم dev، مش 1000/2800/44800 بتاعة الـ reference.
3. **Timestamps:** بداية التنفيذ = لحظة تسليم المهمة لـ CPU الجهاز (application-level submit)، مش بداية الـ CPU الفعلية. نهاية نقل الـ input للفرع البعيد = نفس اللحظة.
4. **وحدات الزمن:** الـ clock بالـ ms والـ MIPS بتتعامل كـ MI لكل وحدة clock، زي باقي المشروع.
5. الـ `bandwidth` وحدته لسه `BLOCKED` في الـ spec، ومفيش تحويل جديد اتعمل.
