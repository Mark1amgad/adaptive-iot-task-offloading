package org.fog.offloading;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Legal action contract of the workload dataset (WORKLOAD_GENERATOR_SPEC.md, "Divisibility classes and legal action contract"):
 *   INDIVISIBLE              -> LOCAL, EDGE_FULL, CLOUD_FULL
 *   DATA_PARALLEL_DIVISIBLE  -> those three plus {EDGE,CLOUD}_PARTIAL_{25,50,75}
 * Partial actions use one remote tier only (never Edge and Cloud together).
 */
final class LegalActions {
    static final List<String> FULL = Arrays.asList("LOCAL", "EDGE_FULL", "CLOUD_FULL");
    static final List<String> PARTIAL = Arrays.asList(
            "EDGE_PARTIAL_25", "EDGE_PARTIAL_50", "EDGE_PARTIAL_75",
            "CLOUD_PARTIAL_25", "CLOUD_PARTIAL_50", "CLOUD_PARTIAL_75");

    private LegalActions() {}

    static boolean isLegal(boolean divisible, String action) {
        return FULL.contains(action) || (divisible && PARTIAL.contains(action));
    }

    static List<String> legalFor(boolean divisible) {
        List<String> l = new ArrayList<String>(FULL);
        if (divisible) l.addAll(PARTIAL);
        return l;
    }

    /** Whole-task action name for a base action (0 Local, 1 Edge, 2 Cloud). */
    static String fullName(int baseAction) {
        return baseAction == RLOffloadingManager.LOCAL ? "LOCAL"
                : (baseAction == RLOffloadingManager.EDGE ? "EDGE_FULL" : "CLOUD_FULL");
    }

    /** Partial action name for a remote tier (1 Edge, 2 Cloud) and remote fraction alpha in {0.25, 0.5, 0.75}. */
    static String partialName(int baseAction, double alpha) {
        return (baseAction == RLOffloadingManager.EDGE ? "EDGE_PARTIAL_" : "CLOUD_PARTIAL_") + Math.round(alpha * 100);
    }
}
