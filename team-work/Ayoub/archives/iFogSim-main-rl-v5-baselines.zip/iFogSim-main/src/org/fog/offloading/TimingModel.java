package org.fog.offloading;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.fog.entities.FogDevice;

/**
 * Predicted completion time of one task on one candidate site, measured the same way the outcome is measured
 * (decision -> end of execution, in simulator clock units = ms). It uses the simulator's OWN delay formulas, with no
 * learned correction (UNCALIBRATED):
 *
 *   transfer  = sum over the hops entry -> target of ( bytes / hop uplink bandwidth + hop uplink latency )   (FogDevice.sendUpFreeLink)
 *   wait+exec = (work already routed to the target and not finished + this task's MI) / target MIPS
 *
 * Link queueing, CPU time-sharing and the result's trip back are NOT modelled. Used by the `epct` baseline
 * (-Drl.mode=baseline -Drl.policy=epct) and, optionally, to log predictions (-Drl.logPredictions=true).
 */
final class TimingModel {
    static final String NAME = "epct-v1-uncalibrated";

    private TimingModel() {}

    static double predict(FogDevice entry, FogDevice target, double mi, double bytes, double backlogMiAtTarget) {
        double t = 0.0;
        FogDevice cur = entry;
        while (cur != null && cur.getId() != target.getId()) {
            t += bytes / cur.getUplinkBandwidth() + cur.getUplinkLatency();
            if (cur.getParentId() <= 0) break;
            SimEntity next = CloudSim.getEntity(cur.getParentId());
            cur = (next instanceof FogDevice) ? (FogDevice) next : null;
        }
        double mips = target.rlTotalMips();
        if (mips <= 0) return Double.MAX_VALUE / 4;
        return t + (Math.max(0.0, backlogMiAtTarget) + mi) / mips;
    }
}
