package org.fog.offloading;

import java.util.List;

import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEvent;
import org.fog.application.AppEdge;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.utils.FogEvents;
import org.fog.utils.FogUtils;
import org.fog.utils.distribution.DeterministicDistribution;

/**
 * Replays the dataset rows of ONE logical source (e.g. iot-01) into its gateway IoT device.
 * Row i is emitted at exactly arrival_time_ms (the sensor->gateway latency is 0, so the task is at the device at that instant).
 * Task length, input/output bytes and application profile come from the row; nothing is drawn from a random generator.
 */
public class DatasetSensor extends Sensor {
    private final List<DatasetWorkload.Row> rows;
    private final DatasetWorkload data;
    private final String moduleName;
    private int next = 0;
    private double maxDriftMs = 0;

    public DatasetSensor(String name, int userId, String appId, DatasetWorkload data, List<DatasetWorkload.Row> rows,
                         String moduleName, String firstProfile) {
        super(name, firstProfile, userId, appId, new DeterministicDistribution(1000.0));
        this.data = data;
        this.rows = rows;
        this.moduleName = moduleName;
        setLatency(0.0);
    }

    @Override
    public void startEntity() {
        send(getGatewayDeviceId(), CloudSim.getMinTimeBetweenEvents(), FogEvents.SENSOR_JOINED, getGeoLocation());
        scheduleNext();
    }

    private void scheduleNext() {
        if (next >= rows.size()) return;
        double at = rows.get(next).arrivalMs;
        double cutoff = Integer.getInteger("sim.time", org.fog.utils.Config.MAX_SIMULATION_TIME);
        if (at >= cutoff) return;                                   // same half-open window as the generated sensors
        send(getId(), Math.max(0.0, at - CloudSim.clock()), FogEvents.EMIT_TUPLE);
    }

    @Override
    public void processEvent(SimEvent ev) {
        switch (ev.getTag()) {
            case FogEvents.TUPLE_ACK:
                break;
            case FogEvents.EMIT_TUPLE:
                emit(rows.get(next++));
                scheduleNext();
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + ev.getTag());
        }
    }

    private void emit(DatasetWorkload.Row r) {
        AppEdge edge = null;
        for (AppEdge e : getApp().getEdges()) {
            if (e.getSource().equals(r.profile)) edge = e;
        }
        if (edge == null) throw new IllegalStateException("no application edge for profile " + r.profile + " (task " + r.taskId + ")");
        Tuple tuple = new Tuple(getAppId(), FogUtils.generateTupleId(), Tuple.UP, (long) r.requiredMi, 1, r.inputBytes, r.outputBytes,
                new UtilizationModelFull(), new UtilizationModelFull(), new UtilizationModelFull());
        tuple.setUserId(getUserId());
        tuple.setTupleType(r.profile);
        tuple.setDestModuleName(edge.getDestination());
        tuple.setSrcModuleName(r.profile);
        tuple.setDestinationDeviceId(getGatewayDeviceId());
        tuple.setActualTupleId(updateTimings(r.profile, tuple.getDestModuleName()));

        double drift = Math.abs(CloudSim.clock() - r.arrivalMs);
        if (drift > maxDriftMs) maxDriftMs = drift;
        if (drift > 1e-6) System.err.println("[rl-dataset] WARNING task " + r.taskId + " emitted at " + CloudSim.clock()
                + " instead of arrival_time_ms=" + r.arrivalMs);
        data.bind(r, tuple.getCloudletId(), CloudSim.clock());          // id mapping first: the manager looks the row up
        RLOffloadingManager.recordSensorEmission(this, tuple);
        send(getGatewayDeviceId(), getLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
    }
}
