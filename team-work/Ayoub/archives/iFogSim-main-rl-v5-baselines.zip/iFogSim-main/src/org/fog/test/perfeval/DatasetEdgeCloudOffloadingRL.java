package org.fog.test.perfeval;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.Application;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.offloading.DatasetSensor;
import org.fog.offloading.DatasetWorkload;
import org.fog.offloading.RLOffloadingManager;
import org.fog.placement.Controller;
import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacementMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.Config;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.TimeKeeper;

/**
 * Same IoT -> Edge -> Cloud scenario as EdgeCloudOffloadingRL (4 IoT, 2 Edge, 1 Cloud; that class is NOT modified), but the
 * workload is a REPLAY of the generator's task file instead of random sensors:
 *
 *   -Drl.enabled=true                         required (the outcome files are written by the offloading manager)
 *   -Ddataset.tasks=<..._tasks.csv>           the generated tasks (task id, arrival, source, urgency, size, divisibility, deadlines)
 *   -Ddataset.manifest=<..._scenario_manifest.csv>   optional; default = same prefix with _scenario_manifest.csv
 *   -Ddataset.drainMs=10000                   simulated time kept after the last arrival so the last tasks can finish
 *                                             (default = the longest generator deadline, 10 s)
 *   -Dsim.time=<ms>                           optional; default = last arrival + drainMs + 1
 *
 * Source mapping (ASSUMPTION, TO CONFIRM): logical source "iot-0k" -> simulator device "iot-k" (k = 1..4).
 * Deadlines are never generated here: -Drl.deadlineMs / rl.deadlineBaseMs / rl.deadlinePerMi are ignored in this mode.
 * See RL_DATASET_INTEGRATION.md.
 */
public class DatasetEdgeCloudOffloadingRL {
    static final String APP_ID = "offload_app";
    static final String MODULE = "processing";

    static List<FogDevice> fogDevices = new ArrayList<FogDevice>();
    static List<Sensor> sensors = new ArrayList<Sensor>();
    static List<Actuator> actuators = new ArrayList<Actuator>();

    public static void main(String[] args) {
        Log.printLine("Starting DatasetEdgeCloudOffloadingRL...");
        try {
            Log.disable();
            if (!Boolean.getBoolean("rl.enabled")) {
                throw new IllegalStateException("dataset replay needs -Drl.enabled=true (the offloading manager writes the outcome files)");
            }
            String tasksArg = System.getProperty("dataset.tasks");
            if (tasksArg == null) throw new IllegalStateException("missing -Ddataset.tasks=<..._tasks.csv>");
            File tasksFile = locate(tasksArg);
            String manifestArg = System.getProperty("dataset.manifest", DatasetWorkload.defaultManifestFor(tasksFile.getPath()));
            DatasetWorkload data = DatasetWorkload.load(tasksFile.getPath(), manifestArg == null ? null : locate(manifestArg).getPath());

            long drain = Long.getLong("dataset.drainMs", 10000L);
            if (System.getProperty("sim.time") == null) {
                System.setProperty("sim.time", String.valueOf(data.lastArrivalMs() + drain + 1));
            }
            Config.MAX_SIMULATION_TIME = Integer.getInteger("sim.time");
            System.setProperty("topology.mode", "fixed");
            if (System.getProperty("rl.deadlineMs") != null || System.getProperty("rl.deadlineBaseMs") != null
                    || System.getProperty("rl.deadlinePerMi") != null) {
                System.err.println("[rl-dataset] NOTE: rl.deadline* options are ignored; deadlines come from the dataset");
            }
            System.err.println("[rl-dataset] " + data.tasksPath + " sha256=" + data.tasksSha256.substring(0, 16)
                    + "... tasks=" + data.rows.size() + " run=" + data.runId + " sim.time=" + System.getProperty("sim.time"));

            CloudSim.init(1, Calendar.getInstance(), false);
            FogBroker broker = new FogBroker("broker");

            Application application = createApplication(APP_ID, broker.getId(), data);
            application.setUserId(broker.getId());
            createTopology();
            createSensors(broker.getId(), data);

            ModuleMapping moduleMapping = ModuleMapping.createModuleMapping();
            for (FogDevice d : fogDevices) {
                moduleMapping.addModuleToDevice(MODULE, d.getName());   // one copy of "processing" everywhere
            }

            Controller controller = new Controller("master-controller", fogDevices, sensors, actuators);
            controller.submitApplication(application, new ModulePlacementMapping(fogDevices, application, moduleMapping));

            TimeKeeper.getInstance().setSimulationStartTime(Calendar.getInstance().getTimeInMillis());
            if (!java.awt.GraphicsEnvironment.isHeadless() && !"false".equalsIgnoreCase(System.getProperty("topology.gui", "true"))) {
                org.fog.gui.example.FogGui.showTopology(fogDevices, sensors, actuators);
            }
            CloudSim.startSimulation();
            CloudSim.stopSimulation();
            RLOffloadingManager.finishIfEnabled();
            Log.printLine("DatasetEdgeCloudOffloadingRL finished!");
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happen");
        }
    }

    /** Path as given, else relative to the project root (the folder that contains rl.home). */
    private static File locate(String p) {
        File f = new File(p);
        if (f.isFile()) return f.getAbsoluteFile();
        File root = new File(RLOffloadingManager.modelHome()).getAbsoluteFile().getParentFile();
        File g = new File(root, p);
        if (g.isFile()) return g;
        throw new IllegalStateException("file not found: " + f.getAbsolutePath() + " (also tried " + g.getAbsolutePath() + ")");
    }

    /** One edge per application profile found in the file; the per-task sizes come from the rows, not from these defaults. */
    private static Application createApplication(String appId, int userId, DatasetWorkload data) {
        Application application = Application.createApplication(appId, userId);
        application.addAppModule(MODULE, 10);
        for (String profile : data.profiles()) {
            DatasetWorkload.Row first = null;
            for (DatasetWorkload.Row r : data.rows) { if (r.profile.equals(profile)) { first = r; break; } }
            application.addAppEdge(profile, MODULE, first.requiredMi, (double) first.inputBytes, profile, Tuple.UP, AppEdge.SENSOR);
        }
        return application;
    }

    /** One replaying sensor per logical source: "iot-01" -> device "iot-1". */
    private static void createSensors(int userId, DatasetWorkload data) {
        for (String src : data.sources()) {
            String digits = src.replaceAll("[^0-9]", "");
            if (digits.isEmpty()) throw new IllegalStateException("cannot map source_device_id '" + src + "' to an IoT device");
            String deviceName = "iot-" + Integer.parseInt(digits);
            FogDevice iot = null;
            for (FogDevice d : fogDevices) if (d.getName().equals(deviceName)) iot = d;
            if (iot == null) throw new IllegalStateException("source '" + src + "' maps to device '" + deviceName + "' which does not exist in this topology");
            List<DatasetWorkload.Row> rows = data.rowsOf(src);
            DatasetSensor s = new DatasetSensor("ds-" + src, userId, APP_ID, data, rows, MODULE, rows.get(0).profile);
            s.setGatewayDeviceId(iot.getId());
            s.setLatency(0.0);
            sensors.add(s);
        }
    }

    // ---- topology: identical numbers to EdgeCloudOffloadingRL (DEV DEFAULTS, not calibrated) ----
    private static void createTopology() {
        FogDevice cloud = createFogDevice("cloud", 20000, 40000, 100000, 100000, 0, 0.01, 16 * 103, 16 * 83.25);
        cloud.setParentId(-1);
        fogDevices.add(cloud);

        double[] wanLatency = {40, 120};
        for (int e = 1; e <= 2; e++) {
            FogDevice edge = createFogDevice("edge-" + e, 300, 4000, 100000, 100000, 1, 0.0, 107.339, 83.4333);
            edge.setParentId(cloud.getId());
            edge.setUplinkLatency(wanLatency[e - 1]);
            fogDevices.add(edge);
            for (int k = 0; k < 2; k++) {
                int iotIndex = (e - 1) * 2 + k + 1;                       // IoT Device 1..4
                FogDevice iot = createFogDevice("iot-" + iotIndex, 100, 1000, 10000, 10000, 2, 0.0, 87.53, 82.44);
                iot.setParentId(edge.getId());
                iot.setUplinkLatency(5);
                fogDevices.add(iot);
            }
        }
    }

    private static FogDevice createFogDevice(String nodeName, long mips, int ram, long upBw, long downBw,
                                             int level, double ratePerMips, double busyPower, double idlePower) {
        List<Pe> peList = new ArrayList<Pe>();
        peList.add(new Pe(0, new PeProvisionerOverbooking(mips)));
        int hostId = FogUtils.generateEntityId();
        long storage = 1000000;
        int bw = 10000;
        PowerHost host = new PowerHost(hostId, new RamProvisionerSimple(ram), new BwProvisionerOverbooking(bw),
                storage, peList, new StreamOperatorScheduler(peList), new FogLinearPowerModel(busyPower, idlePower));
        List<Host> hostList = new ArrayList<Host>();
        hostList.add(host);
        FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics("x86", "Linux", "Xen", host,
                10.0, 3.0, 0.05, 0.001, 0.0);
        FogDevice fogdevice = null;
        try {
            fogdevice = new FogDevice(nodeName, characteristics, new AppModuleAllocationPolicy(hostList),
                    new LinkedList<Storage>(), 10, upBw, downBw, 0, ratePerMips);
        } catch (Exception e) {
            throw new RuntimeException("could not create device " + nodeName, e);
        }
        fogdevice.setLevel(level);
        return fogdevice;
    }
}
