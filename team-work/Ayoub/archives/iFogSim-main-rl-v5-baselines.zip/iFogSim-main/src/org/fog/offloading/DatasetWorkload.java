package org.fog.offloading;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Replay of the workload generator's task inputs (Abdo, workload dataset v1.1.x) inside the simulator.
 *
 * The dataset is the ONLY source of: task ids, arrival times, source device, urgency class, task size (MI, input/output bytes),
 * divisibility + partition/merge overheads, and the deadline (relative and absolute). The simulator never invents or changes
 * any of them: DatasetSensor emits each row at exactly its arrival time, RLOffloadingManager reads the deadline from the row.
 * Dataset mode is off unless DatasetEdgeCloudOffloadingRL loads a file (-Ddataset.tasks=...).
 *
 * Besides the strict loader this class writes two files into rl.logDir:
 *   dataset_outcomes_<runId>.csv   columns of schemas/task_outcomes.schema.json (one final row per generated task)
 *   dataset_audit_<runId>.csv      dataset values next to the values the simulator actually used (proof nothing was altered)
 */
public final class DatasetWorkload {
    public static final String UNITS_VERSION = "SI-ms-bytes-MI-v1";
    public static final String ALPHA_MODEL = "PROPORTIONAL_TO_COMPUTE_ALPHA";
    static final List<String> URGENCY = Arrays.asList("CRITICAL", "TIME_SENSITIVE", "DELAY_TOLERANT");
    static final List<String> SPLIT = Arrays.asList("INDIVISIBLE", "DATA_PARALLEL_DIVISIBLE");
    private static final List<String> REQUIRED = Arrays.asList("task_id", "run_id", "seed", "scenario_id", "source_device_id",
            "application_profile", "urgency_class", "arrival_time_ms", "input_size_bytes", "output_size_bytes", "required_mi",
            "splittability", "partition_model_id", "partition_overhead_ms", "merge_overhead_ms", "input_partition_model",
            "output_partition_model", "relative_deadline_ms", "absolute_deadline_ms", "units_version", "config_hash");

    /** One generated task, exactly as in the CSV (final fields) plus what happened to it in the simulator (runtime fields). */
    public static final class Row {
        public String taskId, runId, scenarioId, sourceDeviceId, profile, urgency, splittability, configHash,
                partitionModelId, inputModel, outputModel;
        public long arrivalMs, inputBytes, outputBytes, relDeadlineMs, absDeadlineMs, seed;
        public double requiredMi, partitionOverheadMs, mergeOverheadMs;
        public boolean divisible;
        public int line;
        // runtime
        public int cloudletId = -1;
        public double emittedAt = Double.NaN, decisionAt = Double.NaN, execSubmitAt = Double.NaN;
        public double deadlineUsedAbs = Double.NaN;      // absolute deadline the simulator compared the completion with
        public String decidedAction = "";                // action type chosen (one of the nine names)
        public boolean written;
    }

    private static DatasetWorkload instance;

    public static boolean isActive() { return instance != null; }
    static DatasetWorkload get() { return instance; }
    public static Row byCloudlet(int cloudletId) { return instance == null ? null : instance.byCloudlet.get(cloudletId); }
    static String taskIdOf(int cloudletId) {
        Row r = byCloudlet(cloudletId);
        return r == null ? null : r.taskId;
    }

    public final List<Row> rows = new ArrayList<Row>();
    private final Map<Integer, Row> byCloudlet = new HashMap<Integer, Row>();
    public final String tasksPath, tasksSha256, runId, scenarioId, configHash;
    String split = "", manifestPath = "";
    long generationWindowEndMs = -1;
    int divisibleCount, indivisibleCount;
    private PrintWriter outcomes, audit;
    private final String policyId;
    private final File logDir;
    private final String logRunId;
    // counters for the summary
    long onTime, late, unresolved, illegalBlocked, illegalExecuted, deadlineMismatch;

    private DatasetWorkload(String tasksPath, String sha, String runId, String scenarioId, String configHash) {
        this.tasksPath = tasksPath;
        this.tasksSha256 = sha;
        this.runId = runId;
        this.scenarioId = scenarioId;
        this.configHash = configHash;
        String mode = System.getProperty("rl.mode", "train");
        this.policyId = System.getProperty("rl.policyId",
                "baseline".equals(mode) ? "baseline-" + System.getProperty("rl.policy", "edge") : "rl-" + mode);
        this.logDir = new File(RLOffloadingManager.resolveOption("rl.logDir",
                new File(RLOffloadingManager.modelHome(), "logs").getPath()));
        this.logRunId = System.getProperty("rl.runId", "run");
    }

    // ------------------------------------------------------------------ loading (strict: any violation aborts the run)
    public static DatasetWorkload load(String tasksCsv, String manifestCsv) throws IOException {
        File f = new File(tasksCsv);
        if (!f.isFile()) throw new IOException("dataset.tasks not found: " + f.getAbsolutePath());
        List<List<String>> table = readCsv(f);
        if (table.isEmpty()) throw new IOException("dataset tasks file is empty: " + f);
        List<String> header = table.get(0);
        Map<String, Integer> col = new HashMap<String, Integer>();
        for (int i = 0; i < header.size(); i++) col.put(header.get(i).trim(), i);
        for (String c : REQUIRED) if (!col.containsKey(c)) throw new IOException("dataset tasks file lacks column '" + c + "'");

        List<Row> rows = new ArrayList<Row>();
        Set<String> ids = new HashSet<String>();
        for (int li = 1; li < table.size(); li++) {
            List<String> v = table.get(li);
            if (v.size() == 1 && v.get(0).trim().isEmpty()) continue;
            int line = li + 1;
            if (v.size() != header.size()) throw bad(line, "expected " + header.size() + " fields, got " + v.size());
            Row r = new Row();
            r.line = line;
            r.taskId = req(v, col, "task_id", line);
            r.runId = req(v, col, "run_id", line);
            r.scenarioId = req(v, col, "scenario_id", line);
            r.sourceDeviceId = req(v, col, "source_device_id", line);
            r.profile = req(v, col, "application_profile", line);
            r.urgency = req(v, col, "urgency_class", line);
            r.splittability = req(v, col, "splittability", line);
            r.configHash = req(v, col, "config_hash", line);
            r.seed = (long) num(v, col, "seed", line, true);
            r.arrivalMs = (long) num(v, col, "arrival_time_ms", line, true);
            r.inputBytes = (long) num(v, col, "input_size_bytes", line, true);
            r.outputBytes = (long) num(v, col, "output_size_bytes", line, true);
            r.relDeadlineMs = (long) num(v, col, "relative_deadline_ms", line, true);
            r.absDeadlineMs = (long) num(v, col, "absolute_deadline_ms", line, true);
            r.requiredMi = num(v, col, "required_mi", line, false);
            if (!UNITS_VERSION.equals(req(v, col, "units_version", line))) throw bad(line, "units_version must be " + UNITS_VERSION);
            if (r.arrivalMs < 0) throw bad(line, "arrival_time_ms < 0");
            if (r.inputBytes <= 0 || r.outputBytes <= 0 || r.requiredMi <= 0 || r.relDeadlineMs <= 0) throw bad(line, "size, MI and relative deadline must be > 0");
            if (r.absDeadlineMs != r.arrivalMs + r.relDeadlineMs) throw bad(line, "absolute_deadline_ms != arrival_time_ms + relative_deadline_ms");
            if (!URGENCY.contains(r.urgency)) throw bad(line, "unknown urgency_class " + r.urgency);
            if (!SPLIT.contains(r.splittability)) throw bad(line, "unknown splittability " + r.splittability);
            r.divisible = "DATA_PARALLEL_DIVISIBLE".equals(r.splittability);
            String pm = opt(v, col, "partition_model_id"), po = opt(v, col, "partition_overhead_ms"), mo = opt(v, col, "merge_overhead_ms"),
                    im = opt(v, col, "input_partition_model"), om = opt(v, col, "output_partition_model");
            if (r.divisible) {
                if (pm == null || po == null || mo == null || im == null || om == null) throw bad(line, "divisible task needs partition model, overheads and input/output partition models");
                if (!ALPHA_MODEL.equals(im) || !ALPHA_MODEL.equals(om)) throw bad(line, "only " + ALPHA_MODEL + " partition models are supported, got " + im + "/" + om);
                r.partitionModelId = pm; r.inputModel = im; r.outputModel = om;
                r.partitionOverheadMs = Double.parseDouble(po);
                r.mergeOverheadMs = Double.parseDouble(mo);
                if (r.partitionOverheadMs < 0 || r.mergeOverheadMs < 0) throw bad(line, "negative partition/merge overhead");
            } else if (pm != null || po != null || mo != null || im != null || om != null) {
                throw bad(line, "indivisible task must have empty partition fields");
            }
            if (!ids.add(r.taskId)) throw bad(line, "duplicate task_id " + r.taskId);
            rows.add(r);
        }
        if (rows.isEmpty()) throw new IOException("dataset tasks file has no tasks: " + f);
        for (Row r : rows) {
            if (!r.runId.equals(rows.get(0).runId)) throw bad(r.line, "run_id differs inside one file");
            if (!r.configHash.equals(rows.get(0).configHash)) throw bad(r.line, "config_hash differs inside one file");
        }
        Row first = rows.get(0);
        DatasetWorkload d = new DatasetWorkload(f.getAbsolutePath(), sha256(f), first.runId, first.scenarioId, first.configHash);
        d.rows.addAll(rows);
        for (Row r : rows) { if (r.divisible) d.divisibleCount++; else d.indivisibleCount++; }
        if (manifestCsv != null && new File(manifestCsv).isFile()) d.readManifest(new File(manifestCsv));
        instance = d;
        return d;
    }

    /** Default manifest next to the tasks file: <prefix>_tasks.csv -> <prefix>_scenario_manifest.csv. */
    public static String defaultManifestFor(String tasksCsv) {
        return tasksCsv.endsWith("_tasks.csv") ? tasksCsv.substring(0, tasksCsv.length() - "_tasks.csv".length()) + "_scenario_manifest.csv" : null;
    }

    private void readManifest(File m) throws IOException {
        List<List<String>> t = readCsv(m);
        if (t.size() < 2) throw new IOException("manifest has no data row: " + m);
        Map<String, Integer> col = new HashMap<String, Integer>();
        for (int i = 0; i < t.get(0).size(); i++) col.put(t.get(0).get(i).trim(), i);
        List<String> v = t.get(1);
        String mrun = field(v, col, "run_id");
        if (mrun != null && !mrun.equals(runId)) throw new IOException("manifest run_id " + mrun + " != tasks run_id " + runId);
        String cnt = field(v, col, "task_count");
        if (cnt != null && Integer.parseInt(cnt) != rows.size())
            throw new IOException("manifest task_count " + cnt + " != " + rows.size() + " task rows");
        String ge = field(v, col, "generation_window_end_ms");
        if (ge != null) generationWindowEndMs = Long.parseLong(ge);
        String sp = field(v, col, "dataset_split");
        if (sp != null) split = sp;
        manifestPath = m.getAbsolutePath();
    }

    private static String field(List<String> v, Map<String, Integer> col, String name) {
        Integer i = col.get(name);
        if (i == null || i >= v.size() || v.get(i).trim().isEmpty()) return null;
        return v.get(i).trim();
    }

    private static IOException bad(int line, String msg) {
        return new IOException("dataset tasks file, line " + line + ": " + msg);
    }

    private static String req(List<String> v, Map<String, Integer> col, String name, int line) throws IOException {
        String s = v.get(col.get(name)).trim();
        if (s.isEmpty()) throw bad(line, "empty required field '" + name + "'");
        return s;
    }

    private static String opt(List<String> v, Map<String, Integer> col, String name) {
        String s = v.get(col.get(name)).trim();
        return s.isEmpty() ? null : s;
    }

    private static double num(List<String> v, Map<String, Integer> col, String name, int line, boolean integral) throws IOException {
        String s = req(v, col, name, line);
        try {
            double d = Double.parseDouble(s);
            if (integral && d != Math.rint(d)) throw bad(line, "field '" + name + "' must be an integer, got " + s);
            if (!integral && name.equals("required_mi") && d != Math.rint(d)) {
                throw bad(line, "required_mi must be a whole number of MI for the simulator's integer task length, got " + s);
            }
            return d;
        } catch (NumberFormatException e) {
            throw bad(line, "field '" + name + "' is not a number: " + s);
        }
    }

    /** Minimal RFC 4180 reader (quoted fields, doubled quotes, commas and line breaks inside quotes). */
    static List<List<String>> readCsv(File f) throws IOException {
        List<List<String>> out = new ArrayList<List<String>>();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
        try {
            List<String> cur = new ArrayList<String>();
            StringBuilder sb = new StringBuilder();
            boolean quoted = false;
            int c;
            boolean any = false, bom = true;
            while ((c = br.read()) >= 0) {
                if (bom) { bom = false; if (c == 0xFEFF) continue; }
                any = true;
                if (quoted) {
                    if (c == '"') {
                        br.mark(1);
                        int n = br.read();
                        if (n == '"') sb.append('"'); else { quoted = false; if (n >= 0) br.reset(); }
                    } else sb.append((char) c);
                } else if (c == '"') quoted = true;
                else if (c == ',') { cur.add(sb.toString()); sb.setLength(0); }
                else if (c == '\n' || c == '\r') {
                    if (c == '\r') { br.mark(1); int n = br.read(); if (n != '\n' && n >= 0) br.reset(); }
                    cur.add(sb.toString()); sb.setLength(0);
                    out.add(cur); cur = new ArrayList<String>(); any = false;
                } else sb.append((char) c);
            }
            if (any || !cur.isEmpty() || sb.length() > 0) { cur.add(sb.toString()); out.add(cur); }
        } finally {
            br.close();
        }
        return out;
    }

    private static String sha256(File f) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = new FileInputStream(f);
            try {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            } finally {
                in.close();
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }

    // ------------------------------------------------------------------ replay support
    /** Rows of one logical source, in arrival order (ties keep file order, so ids stay in the dataset's order). */
    public List<Row> rowsOf(String logicalSource) {
        List<Row> l = new ArrayList<Row>();
        for (Row r : rows) if (r.sourceDeviceId.equals(logicalSource)) l.add(r);
        Collections.sort(l, new Comparator<Row>() {
            public int compare(Row a, Row b) { return a.arrivalMs != b.arrivalMs ? Long.compare(a.arrivalMs, b.arrivalMs) : Integer.compare(a.line, b.line); }
        });
        return l;
    }

    public List<String> sources() {
        List<String> s = new ArrayList<String>();
        for (Row r : rows) if (!s.contains(r.sourceDeviceId)) s.add(r.sourceDeviceId);
        Collections.sort(s);
        return s;
    }

    public List<String> profiles() {
        List<String> s = new ArrayList<String>();
        for (Row r : rows) if (!s.contains(r.profile)) s.add(r.profile);
        return s;
    }

    public long lastArrivalMs() {
        long m = 0;
        for (Row r : rows) m = Math.max(m, r.arrivalMs);
        return m;
    }

    public void bind(Row r, int cloudletId, double emittedAt) {
        r.cloudletId = cloudletId;
        r.emittedAt = emittedAt;
        byCloudlet.put(cloudletId, r);
    }

    /** Metadata that goes into the Python run log (hello.simulator). */
    public Map<String, String> metadata() {
        Map<String, String> m = new LinkedHashMap<String, String>();
        m.put("dataset_run_id", runId);
        m.put("dataset_scenario_id", scenarioId);
        m.put("dataset_config_hash", configHash);
        m.put("dataset_tasks_sha256", tasksSha256);
        m.put("dataset_task_count", String.valueOf(rows.size()));
        if (!split.isEmpty()) m.put("dataset_split", split);
        return m;
    }

    // ------------------------------------------------------------------ outputs
    private static final String[] OUT_COLS = {"run_id", "task_id", "policy_id", "arrival_time_ms", "action_type", "offload_fraction",
            "local_fraction", "remote_tier", "full_execution_site_id", "local_execution_site_id", "remote_execution_site_id",
            "full_execution_start_ms", "full_execution_end_ms", "local_branch_start_ms", "local_branch_end_ms",
            "remote_input_transfer_start_ms", "remote_input_transfer_end_ms", "remote_branch_start_ms", "remote_branch_end_ms",
            "partition_start_ms", "partition_end_ms", "merge_start_ms", "merge_end_ms", "result_transfer_start_ms",
            "result_transfer_end_ms", "completion_time_ms", "end_to_end_latency_ms", "final_status", "deadline_met",
            "unresolved_at_horizon", "failure_or_unresolved_reason", "observed_until_ms"};
    private static final String[] AUDIT_COLS = {"run_id", "task_id", "source_device_id", "urgency_class", "splittability",
            "legal_actions", "arrival_time_ms", "emitted_at_ms", "decision_time_ms", "relative_deadline_ms", "absolute_deadline_ms",
            "absolute_deadline_used_ms", "deadline_preserved", "action_type", "action_legal", "completion_time_ms",
            "end_to_end_latency_ms", "final_status"};

    private PrintWriter open(String prefix, String[] cols) throws IOException {
        logDir.mkdirs();
        PrintWriter w = new PrintWriter(new FileWriter(new File(logDir, prefix + "_" + logRunId + ".csv")));
        w.println(join(Arrays.asList(cols)));
        return w;
    }

    private static String join(List<String> v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.size(); i++) { if (i > 0) sb.append(','); sb.append(v.get(i)); }
        return sb.toString();
    }

    private static String n(double x) {
        return Double.isNaN(x) ? "" : (x == Math.rint(x) && Math.abs(x) < 1e15 ? String.valueOf((long) x) : String.format(Locale.ROOT, "%.6f", x));
    }

    /** What the manager knows when a task reaches its final completion. */
    static final class Completion {
        String actionType, remoteTier, fullSite = "", localSite = "", remoteSite = "";
        double alpha, completion, decisionTime;
        boolean met;
        PartialOffloader.Task partial;     // null for whole-task actions
    }

    void writeCompleted(Row r, Completion c) {
        if (r.written) return;
        r.written = true;
        r.decidedAction = c.actionType;
        String status = c.met ? "ON_TIME" : "LATE";
        if (c.met) onTime++; else late++;
        boolean legal = LegalActions.isLegal(r.divisible, c.actionType);
        if (!legal) illegalExecuted++;
        Map<String, String> m = new LinkedHashMap<String, String>();
        for (String k : OUT_COLS) m.put(k, "");
        m.put("run_id", runId); m.put("task_id", r.taskId); m.put("policy_id", policyId);
        m.put("arrival_time_ms", n(r.arrivalMs));
        m.put("action_type", c.actionType);
        m.put("offload_fraction", n(c.alpha));
        m.put("local_fraction", n(1.0 - c.alpha));
        m.put("remote_tier", c.remoteTier == null ? "" : c.remoteTier);
        PartialOffloader.Task t = c.partial;
        if (t == null) {
            m.put("full_execution_site_id", c.fullSite);
            m.put("full_execution_start_ms", n(r.execSubmitAt));
            m.put("full_execution_end_ms", n(c.completion));
        } else {
            m.put("local_execution_site_id", c.localSite);
            m.put("remote_execution_site_id", c.remoteSite);
            m.put("partition_start_ms", n(t.decision));
            m.put("partition_end_ms", n(t.partitionDone));
            m.put("local_branch_start_ms", n(t.localSubmit));
            m.put("local_branch_end_ms", n(t.localFinish));
            m.put("remote_input_transfer_start_ms", n(t.remoteSend));
            m.put("remote_input_transfer_end_ms", n(t.remoteSubmit));
            m.put("remote_branch_start_ms", n(t.remoteSubmit));
            m.put("remote_branch_end_ms", n(t.remoteFinish));
            m.put("result_transfer_start_ms", n(t.remoteFinish));
            m.put("result_transfer_end_ms", n(t.resultArrival));
            m.put("merge_start_ms", n(t.mergeStart));
            m.put("merge_end_ms", n(t.mergeDone));
        }
        m.put("completion_time_ms", n(c.completion));
        m.put("end_to_end_latency_ms", n(c.completion - r.arrivalMs));
        m.put("final_status", status);
        m.put("deadline_met", String.valueOf(c.met));
        m.put("unresolved_at_horizon", "false");
        emit(m, r, status, c.completion);
    }

    /** Task with no completion before the cutoff: UNRESOLVED_AT_HORIZON (deadline result stays null, never faked as a miss). */
    void writeUnresolved(Row r, double cutoff, String reason) {
        if (r.written) return;
        r.written = true;
        unresolved++;
        Map<String, String> m = new LinkedHashMap<String, String>();
        for (String k : OUT_COLS) m.put(k, "");
        String action = r.decidedAction.isEmpty() ? "LOCAL" : r.decidedAction;
        boolean partialAction = LegalActions.PARTIAL.contains(action);
        m.put("run_id", runId); m.put("task_id", r.taskId); m.put("policy_id", policyId);
        m.put("arrival_time_ms", n(r.arrivalMs));
        m.put("action_type", action);
        double alpha = partialAction ? Integer.parseInt(action.substring(action.lastIndexOf('_') + 1)) / 100.0
                : (action.endsWith("_FULL") ? 1.0 : 0.0);
        m.put("offload_fraction", n(alpha));
        m.put("local_fraction", n(1.0 - alpha));
        m.put("remote_tier", action.startsWith("EDGE") ? "EDGE" : (action.startsWith("CLOUD") ? "CLOUD" : ""));
        m.put("final_status", "UNRESOLVED_AT_HORIZON");
        m.put("unresolved_at_horizon", "true");
        m.put("failure_or_unresolved_reason", reason + (cutoff > r.absDeadlineMs ? ";deadline_already_passed" : ";still_within_deadline"));
        m.put("observed_until_ms", n(cutoff));
        emit(m, r, "UNRESOLVED_AT_HORIZON", Double.NaN);
    }

    private void emit(Map<String, String> m, Row r, String status, double completion) {
        try {
            if (outcomes == null) outcomes = open("dataset_outcomes", OUT_COLS);
            if (audit == null) audit = open("dataset_audit", AUDIT_COLS);
            List<String> vals = new ArrayList<String>();
            for (String k : OUT_COLS) vals.add(csvCell(m.get(k)));
            outcomes.println(join(vals));
            outcomes.flush();
            boolean preserved = Double.isNaN(r.deadlineUsedAbs) ? true : Math.abs(r.deadlineUsedAbs - r.absDeadlineMs) < 1e-6;
            if (!preserved) deadlineMismatch++;
            List<String> a = new ArrayList<String>();
            a.add(runId); a.add(r.taskId); a.add(r.sourceDeviceId); a.add(r.urgency); a.add(r.splittability);
            a.add("\"" + join(LegalActions.legalFor(r.divisible)).replace(',', '|') + "\"");
            a.add(n(r.arrivalMs)); a.add(n(r.emittedAt)); a.add(n(r.decisionAt));
            a.add(n(r.relDeadlineMs)); a.add(n(r.absDeadlineMs)); a.add(n(r.deadlineUsedAbs));
            a.add(String.valueOf(preserved));
            a.add(m.get("action_type")); a.add(String.valueOf(LegalActions.isLegal(r.divisible, m.get("action_type"))));
            a.add(n(completion)); a.add(Double.isNaN(completion) ? "" : n(completion - r.arrivalMs)); a.add(status);
            audit.println(join(a));
            audit.flush();
        } catch (IOException e) {
            System.err.println("[rl-dataset] could not write outcome files in " + logDir + ": " + e);
        }
    }

    private static String csvCell(String s) {
        if (s == null) return "";
        return (s.indexOf(',') >= 0 || s.indexOf('"') >= 0) ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }

    String summary(long decided, long completedReported) {
        long emitted = 0;
        for (Row r : rows) if (!Double.isNaN(r.emittedAt)) emitted++;
        return String.format(Locale.ROOT,
                "[rl] DATASET run=%s scenario=%s tasks=%d (divisible=%d, indivisible=%d) emitted=%d decided=%d | ON_TIME=%d LATE=%d UNRESOLVED=%d"
                        + " | deadline_changed=%d illegal_actions_blocked=%d illegal_actions_executed=%d%n"
                        + "[rl] DATASET deadlines come from the dataset (relative_deadline_ms, absolute_deadline_ms); files: dataset_outcomes_%s.csv, dataset_audit_%s.csv%n",
                runId, scenarioId, rows.size(), divisibleCount, indivisibleCount, emitted, decided, onTime, late, unresolved,
                deadlineMismatch, illegalBlocked, illegalExecuted, logRunId, logRunId);
    }

    /** Rows that were never completed: write them as unresolved. Called once at the cutoff. */
    void closeUnresolved(double cutoff) {
        for (Row r : rows) {
            if (r.written) continue;
            String reason = Double.isNaN(r.emittedAt) ? "NOT_EMITTED_BEFORE_CUTOFF"
                    : (Double.isNaN(r.decisionAt) ? "NOT_DECIDED_BEFORE_CUTOFF" : "NOT_COMPLETED_BEFORE_CUTOFF");
            writeUnresolved(r, cutoff, reason);
        }
    }
}
