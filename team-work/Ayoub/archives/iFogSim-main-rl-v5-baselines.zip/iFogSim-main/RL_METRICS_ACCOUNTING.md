# المقاييس وحساب المهام (Metrics & Task Accounting)

شغّال في كل الـ mains (Fixed وRandom وDataset) لما `-Drl.enabled=true`. ما بيغيّرش الـ agent ولا الـ State ولا الـ Reward ولا البروتوكول.

## 1) زمنين منفصلين لكل مهمة
| المقياس | التعريف | فين بيظهر |
|---|---|---|
| **End-to-End latency** | لحظة توليد الـ Sensor ← الإكمال النهائي (بعد الدمج في المهام المقسّمة) | `e2e_latency_ms` |
| **Decision → completion** | لحظة قرار الـ agent ← الإكمال النهائي. هو اللي بيدخل في الـ reward وفي `latency_ms` المبعوتة لـ Python | `decision_to_completion_ms` |
| Sensor → decision | الانتظار قبل القرار (E2E = ده + decision→completion للمهام اللي اتقرر فيها) | `sensor_to_decision_ms` |

الـ SUMMARY بيطبع لكل واحد: العدد والمتوسط وp50 وp95 والأقصى. الـ reward ما اتغيرش، فالـ `latency_ms` لسه decision→completion.

## 2) دفتر المهام (`task_metrics_<runId>.csv`)
صف لكل مهمة اتولّدت، بالأعمدة: task_id، sensor، tuple_type، task_mi، generated، decision، completion، الأزمنة التلاتة، الـ deadline النسبي والمطلق، `deadline_met`، `decided_action` و`executed_action`، الجهاز، `final_status`، `default_flow`، وقت الـ cutoff وعمر المهمة عنده.
في وضع الـ dataset الـ task_id هو id الـ dataset. المهام اللي ما اتولّدتش قبل الـ cutoff بتظهر كـ `NOT_EMITTED_BEFORE_CUTOFF`.

## 3) الحالات الصريحة (المقام)
| الحالة | المعنى |
|---|---|
| `ON_TIME` / `LATE` | خلصت قبل الـ cutoff، ومتحسوبة بالـ deadline من لحظة التوليد |
| `PENDING_DEADLINE_PASSED` | اتقرر فيها ولسه ما خلصتش، والـ deadline فات (miss مؤكد) |
| `PENDING_WITHIN_DEADLINE` | اتقرر فيها ولسه ما خلصتش، والـ deadline لسه ما فاتش (غير محسومة) |
| `UNDECIDED_DEADLINE_PASSED` / `UNDECIDED_WITHIN_DEADLINE` | اتولّدت ولسه الـ agent ما قررش |
| `NOT_EMITTED_BEFORE_CUTOFF` | (dataset) مهمة في الملف وقتها بعد الـ cutoff |
| `FAILED` | دايمًا 0: iFogSim ما فيهوش نموذج لفشل المهمة |

سطر `TASK ACCOUNTING` في آخر التشغيل: `generated = ON_TIME + LATE + FAILED + PENDING… + UNDECIDED… + NOT_EMITTED | reconciled=true`. لو `reconciled=false` يبقى في مهمة اتفقدت.

المهمة اللي خلصت من غير قرار من الـ agent (fallback، أو مفيش خيارات) كانت قبل كده بتختفي من الحساب. دلوقتي بتتحسب (`default_flow=true`) ومش بتتبعت للـ agent.

المهمة اللي بتخلص بعد الـ cutoff بتفضل بحالتها وقت الـ cutoff. ومفيش مهمة بتتنقل لـ `FAILED` أو `LATE` غير لو خلصت فعلًا.

## 4) Backlog pressure مش CPU utilization
| الاسم | إيه هو بالظبط |
|---|---|
| **Backlog pressure** | تقدير: `min(1, (MI المنتظر على الجهاز ÷ MIPS) ÷ rl.backlogCapMs)`. هو ورا الـ state feature `edge_utilization` والـ `executing_node_utilization` في الـ outcome |
| **CPU utilization (فعلي)** | `MI اللي خلصت على الجهاز ÷ (MIPS × الزمن)` |

الاتنين بيتطبعوا لكل جهاز منفصلين في الـ SUMMARY وفي `device_metrics_<runId>.csv`: mips، completed_work_mi، `cpu_utilization_completed_work`، `mean_backlog_pressure` (متوسط زمني)، `peak_backlog_pressure`، `backlog_mi_at_cutoff`.
- الـ CPU الفعلي بيحسب الشغل **اللي خلص** بس، فالمهام اللي لسه شغّالة وقت الـ cutoff مش داخلة (يقلّل الرقم شوية).
- الأسماء `edge_utilization` و`executing_node_utilization` على الـ wire اتسابت زي ما هي عشان البروتوكول والـ state fingerprint ما يتغيروش. هي **backlog pressure** مش CPU. تغيير الاسم محتاج تعديل config وPython وإعادة تدريب (الـ fingerprint بيتغير).

## 5) الطاقة
الطاقة **مش** في أي مقياس أساسي هنا، ومفيش عمود طاقة في أي ملف جديد (ولا في `dataset_outcomes`). أرقام الطاقة بتاعة iFogSim نفسها (اللي بيطبعها هو) تتعامل كغير موثقة لحد ما نتأكد من الـ power model.

## الملفات (في `rl.logDir`)
`task_metrics_<runId>.csv` و`device_metrics_<runId>.csv` (+ ملفات الـ dataset والـ partial لو شغّالين).
