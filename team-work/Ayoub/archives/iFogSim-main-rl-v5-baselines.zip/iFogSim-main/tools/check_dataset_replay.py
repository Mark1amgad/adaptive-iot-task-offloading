#!/usr/bin/env python3
"""Compare a dataset replay run with the generator's task file (nothing is changed, read-only check).

    python tools/check_dataset_replay.py --tasks dataset/abdo_v1_1_1/dev/stable_steady__seed_0007_tasks.csv \
        --audit rl_model/logs/dataset_audit_<runId>.csv --outcomes rl_model/logs/dataset_outcomes_<runId>.csv

Checks, per task: id present exactly once, arrival time, urgency, relative/absolute deadline identical to the dataset,
the deadline the simulator used equals the dataset's, only legal actions, status counts add up to the generated count.
"""
import argparse
import csv
import sys

LEGAL = {
    "INDIVISIBLE": {"LOCAL", "EDGE_FULL", "CLOUD_FULL"},
    "DATA_PARALLEL_DIVISIBLE": {"LOCAL", "EDGE_FULL", "CLOUD_FULL", "EDGE_PARTIAL_25", "EDGE_PARTIAL_50", "EDGE_PARTIAL_75",
                                "CLOUD_PARTIAL_25", "CLOUD_PARTIAL_50", "CLOUD_PARTIAL_75"},
}


def rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", required=True)
    ap.add_argument("--audit", required=True)
    ap.add_argument("--outcomes", required=True)
    a = ap.parse_args()
    tasks = {r["task_id"]: r for r in rows(a.tasks)}
    audit = rows(a.audit)
    outs = rows(a.outcomes)
    problems = []

    def bad(msg):
        problems.append(msg)

    for name, table in (("audit", audit), ("outcomes", outs)):
        ids = [r["task_id"] for r in table]
        if len(ids) != len(set(ids)):
            bad(f"{name}: duplicate task ids")
        if set(ids) != set(tasks):
            bad(f"{name}: task ids differ from the dataset (missing {len(set(tasks) - set(ids))}, unknown {len(set(ids) - set(tasks))})")
    for r in audit:
        t = tasks.get(r["task_id"])
        if not t:
            continue
        for ours, theirs in (("arrival_time_ms", "arrival_time_ms"), ("urgency_class", "urgency_class"), ("splittability", "splittability"),
                             ("relative_deadline_ms", "relative_deadline_ms"), ("absolute_deadline_ms", "absolute_deadline_ms")):
            if str(r[ours]) != str(t[theirs]):
                bad(f"{r['task_id']}: {ours} {r[ours]} != dataset {t[theirs]}")
        if r["emitted_at_ms"] and float(r["emitted_at_ms"]) != float(t["arrival_time_ms"]):
            bad(f"{r['task_id']}: emitted at {r['emitted_at_ms']} not at arrival {t['arrival_time_ms']}")
        if r["absolute_deadline_used_ms"] and float(r["absolute_deadline_used_ms"]) != float(t["absolute_deadline_ms"]):
            bad(f"{r['task_id']}: deadline used {r['absolute_deadline_used_ms']} != dataset {t['absolute_deadline_ms']}")
        if r["action_type"] not in LEGAL[t["splittability"]]:
            bad(f"{r['task_id']}: illegal action {r['action_type']} for {t['splittability']}")
    counts = {}
    for r in outs:
        counts[r["final_status"]] = counts.get(r["final_status"], 0) + 1
    if sum(counts.values()) != len(tasks):
        bad(f"status counts {counts} do not add up to {len(tasks)} generated tasks")
    print(f"tasks={len(tasks)} statuses={counts}")
    if problems:
        print(f"{len(problems)} PROBLEM(S):")
        for p in problems[:30]:
            print("  -", p)
        return 1
    print("OK: ids, arrivals, urgency, deadlines and actions all match the dataset")
    return 0


if __name__ == "__main__":
    sys.exit(main())
