#!/usr/bin/env python3
"""Train the RL agent on SEVERAL random topologies one after the other, then evaluate it (and the baselines) on NEW
topologies it has never seen, with SEVERAL workload seeds per test topology.

One simulation = one topology (iFogSim cannot rebuild its world inside one JVM), so "training on many topologies" is a
chain of runs: run k starts from the model saved by run k-1 (-Drl.modelIn / -Drl.modelOut). The learning state, including
the epsilon schedule counter, is carried along in the model file.

Example (from the project root, after compiling; 'bin' = your compiled classes folder):
    python tools/run_topology_curriculum.py --classes bin --train-seeds 1-8 --test-seeds 101-104 \
        --test-workload-seeds 1-5 --sim-time 20000 --epsilon-decay-steps auto

Design guarantees
  * Train/test separation: topology seeds may not overlap, the WORKLOAD seeds used for training and testing may not overlap
    either, and the Java side refuses to evaluate a model on a topology it was trained on.
  * Pairing: for every (test topology, workload seed) the agent and every baseline run on the IDENTICAL topology and
    workload (same -Dtopology.seed and -Drl.simSeed). The script checks from the task ledgers that all policies saw the same
    generated tasks (same ids and generation times) and prints NOT PAIRED otherwise.
  * Without --test-workload-seeds the old behaviour is kept: one workload seed per topology (= --test-workload-base + topology seed).

Everything goes to --out (default <home>/artifacts/curriculum): models, logs, topology files, summary.csv, paired_summary.csv.
Nothing here changes the agent, the reward or the state: it only launches the existing main class with VM options.
"""
import argparse
import csv
import glob
import json
import math
import os
import statistics
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

MAIN = "org.fog.test.perfeval.RandomEdgeCloudOffloadingRL"


def parse_seeds(text):
    seeds = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            lo, hi = part.split("-", 1)
            seeds.extend(range(int(lo), int(hi) + 1))
        else:
            seeds.append(int(part))
    if len(set(seeds)) != len(seeds):
        raise SystemExit(f"duplicate seeds in {text!r}")
    return seeds


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def mean_or_nan(v):
    v = [x for x in v if x is not None and not math.isnan(x)]
    return statistics.mean(v) if v else float("nan")


def se(v):
    v = [x for x in v if x is not None and not math.isnan(x)]
    return statistics.stdev(v) / math.sqrt(len(v)) if len(v) > 1 else float("nan")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--classes", required=True, help="folder with the compiled classes (e.g. bin, out/production/...)")
    ap.add_argument("--train-seeds", required=True, help='topology seeds to train on, in order, e.g. "1-8" or "1,2,5"')
    ap.add_argument("--test-seeds", required=True, help='NEW topology seeds for evaluation, e.g. "101-104"')
    ap.add_argument("--test-workload-seeds", default=None,
                    help='workload seeds run on EVERY test topology, e.g. "1-5" (default: one seed per topology, old behaviour)')
    ap.add_argument("--sim-time", type=int, default=20000)
    ap.add_argument("--agent-seed", type=int, default=1)
    ap.add_argument("--train-workload-base", type=int, default=0, help="train workload seed = base + topology seed")
    ap.add_argument("--test-workload-base", type=int, default=5000, help="test workload seed = base + (workload seed | topology seed)")
    ap.add_argument("--baselines", default="local,edge,cloud,epct", help="comma list (local, edge, cloud, epct, random), or '' to skip")
    ap.add_argument("--epsilon-decay-steps", default=None,
                    help="override agent.epsilon_decay_steps (an integer), or 'auto' = --epsilon-decay-fraction x total training "
                         "decisions, counted with one cheap baseline run per training topology")
    ap.add_argument("--epsilon-decay-fraction", type=float, default=0.5,
                    help="with 'auto': the share of all training decisions over which epsilon decays (default 0.5)")
    ap.add_argument("--jobs", type=int, default=2, help="parallel evaluation/baseline runs")
    ap.add_argument("--home", default="rl_model", help="rl.home (model folder)")
    ap.add_argument("--config", default=None, help="rl.config (default: <home>/config/edge_cloud_scenario.json)")
    ap.add_argument("--out", default=None, help="output folder (default: <home>/artifacts/curriculum)")
    ap.add_argument("--java", default="java")
    ap.add_argument("--python", default="python")
    ap.add_argument("--gui", action="store_true", help="show the topology window (default: headless)")
    ap.add_argument("--vm", action="append", default=[], help="extra VM option, e.g. --vm=-Dtopo.wanLat.max=100 (repeatable)")
    ap.add_argument("--dry-run", action="store_true", help="print the commands only")
    a = ap.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    home = os.path.abspath(a.home)
    config = os.path.abspath(a.config or os.path.join(home, "config", "edge_cloud_scenario.json"))
    out = os.path.abspath(a.out or os.path.join(home, "artifacts", "curriculum"))
    logs = os.path.join(out, "logs")
    train, test = parse_seeds(a.train_seeds), parse_seeds(a.test_seeds)
    if set(train) & set(test):
        raise SystemExit(f"train and test topology seeds overlap: {sorted(set(train) & set(test))}")
    wl_seeds = parse_seeds(a.test_workload_seeds) if a.test_workload_seeds else None   # None = legacy single seed
    train_wl = {s: a.train_workload_base + s for s in train}
    test_wl = {}                                   # (topology seed, test workload key) -> simSeed
    for t in test:
        for w in (wl_seeds if wl_seeds else [t]):
            test_wl[(t, w if wl_seeds else None)] = a.test_workload_base + w
    if set(train_wl.values()) & set(test_wl.values()):
        raise SystemExit("train and test WORKLOAD seeds overlap: "
                         f"{sorted(set(train_wl.values()) & set(test_wl.values()))[:10]} (change --train/--test-workload-base)")
    baselines = [p for p in a.baselines.split(",") if p]
    jars = glob.glob(os.path.join(root, "jars", "*.jar")) + glob.glob(os.path.join(root, "jars", "commons-math3-3.5", "*.jar"))
    cp = os.pathsep.join([os.path.abspath(a.classes)] + jars)
    os.makedirs(logs, exist_ok=True)
    train_spec = f"{min(train)}-{max(train)}" if train == list(range(min(train), max(train) + 1)) else ",".join(map(str, train))
    cfg = json.load(open(config, encoding="utf-8"))
    agent_cfg = cfg.get("agent", {})
    eps0, eps1 = agent_cfg.get("epsilon_start", 0.3), agent_cfg.get("epsilon_end", 0.02)

    def run(name, extra, cfg_path):
        cmd = [a.java, "-Drl.enabled=true", f"-Drl.home={home}", f"-Drl.config={cfg_path}", f"-Drl.python={a.python}",
               f"-Drl.runId={name}", f"-Drl.logDir={logs}", f"-Drl.artifactsDir={out}", f"-Dtopology.logDir={logs}",
               f"-Dtopology.trainSeeds={train_spec}", f"-Dsim.time={a.sim_time}", f"-Drl.agentSeed={a.agent_seed}"]
        cmd += ["-Dtopology.seconds=1"] if a.gui else ["-Djava.awt.headless=true"]
        cmd += a.vm + extra + ["-cp", cp, MAIN]
        if a.dry_run:
            print(" ".join(f'"{c}"' if " " in c else c for c in cmd))
            return
        err_path = os.path.join(logs, f"{name}.stderr")
        with open(os.path.join(logs, f"{name}.stdout"), "w", encoding="utf-8") as so, \
                open(err_path, "w", encoding="utf-8") as se_:
            rc = subprocess.call(cmd, stdout=so, stderr=se_, cwd=root)
        err = open(err_path, encoding="utf-8", errors="replace").read()
        ok = rc == 0 and os.path.exists(os.path.join(logs, f"run_{name}.jsonl")) and "Unwanted errors happen" not in err
        if not ok:
            lines = [l for l in err.splitlines() if "Exception" in l or "REFUSED" in l or "ERROR" in l]
            raise SystemExit(f"run {name} FAILED (rc={rc}). See {err_path}\n  " + "\n  ".join(lines[:5]))
        print(f"  done {name}")

    def ledger(name):
        p = os.path.join(logs, f"task_metrics_{name}.csv")
        return read_csv(p) if os.path.exists(p) else []

    def decisions_in(name):
        return sum(1 for r in ledger(name) if r.get("decision_ms", "") != "")

    # ------------------------------------------------------------------ 0) epsilon schedule
    cfg_used = config
    eps_steps = agent_cfg.get("epsilon_decay_steps")
    if a.epsilon_decay_steps is not None:
        if a.epsilon_decay_steps == "auto":
            print(f"EPSILON census: counting the decisions of each training topology (baseline 'local', no learning)")
            total = 0
            for seed in train:
                name = f"census-t{seed}"
                run(name, ["-Drl.mode=baseline", "-Drl.policy=local", "-Drl.phase=train", f"-Drl.simSeed={train_wl[seed]}",
                           f"-Dtopology.seed={seed}"], config)
                if not a.dry_run:
                    total += decisions_in(name)
            eps_steps = max(1, int(round(a.epsilon_decay_fraction * total))) if not a.dry_run else eps_steps
            if not a.dry_run:
                print(f"  total training decisions D={total}  ->  epsilon_decay_steps = {a.epsilon_decay_fraction} x D = {eps_steps}")
        else:
            eps_steps = int(a.epsilon_decay_steps)
        if not a.dry_run:
            cfg2 = json.loads(json.dumps(cfg))
            cfg2.setdefault("agent", {})["epsilon_decay_steps"] = int(eps_steps)
            cfg_used = os.path.join(out, "config_epsilon.json")
            json.dump(cfg2, open(cfg_used, "w", encoding="utf-8"), indent=2)
            print(f"  derived config: {cfg_used}")

    # ------------------------------------------------------------------ 1) sequential training
    print(f"TRAIN on topologies {train} (sim.time={a.sim_time}), chained models in {out}")
    prev = None
    for seed in train:
        name = f"train-t{seed}"
        model = os.path.join(out, f"model_after_t{seed}.json")
        extra = ["-Drl.mode=train", "-Drl.phase=train", f"-Drl.simSeed={train_wl[seed]}",
                 f"-Dtopology.seed={seed}", f"-Drl.modelOut={model}"]
        if prev:
            extra.append(f"-Drl.modelIn={prev}")
        run(name, extra, cfg_used)
        prev = model
    final_model = prev

    # ------------------------------------------------------------------ 2) evaluation + baselines on NEW topologies
    keys = sorted(test_wl)
    print(f"EVAL on unseen topologies {test}, {len(keys)} (topology, workload seed) pairs, "
          f"policies: agent + {', '.join(baselines) or 'none'}")
    jobs = []

    def label(t, w):
        return f"t{t}" if w is None else f"t{t}-w{w}"

    for (t, w) in keys:
        sim_seed = test_wl[(t, w)]
        common = ["-Drl.phase=test", f"-Drl.simSeed={sim_seed}", f"-Dtopology.seed={t}"]
        jobs.append((f"eval-{label(t, w)}", ["-Drl.mode=eval", f"-Drl.modelIn={final_model}"] + common))
        for pol in baselines:
            jobs.append((f"base-{pol}-{label(t, w)}", ["-Drl.mode=baseline", f"-Drl.policy={pol}"] + common))
    with ThreadPoolExecutor(max_workers=max(1, a.jobs)) as ex:
        for f in [ex.submit(run, n, e, cfg_used) for n, e in jobs]:
            f.result()
    if a.dry_run:
        return

    # ------------------------------------------------------------------ 3) per-run statistics
    def stats(name):
        tasks = [json.loads(l) for l in open(os.path.join(logs, f"run_{name}.jsonl"), encoding="utf-8")]
        tasks = [x for x in tasks if x["record"] == "task"]
        lat = [x["outcome"]["latency_ms"] for x in tasks if x["outcome"].get("latency_ms") is not None]
        mix = {k: sum(1 for x in tasks if x["action_executed"] == k) for k in ("Local", "Edge", "Cloud")}
        led = ledger(name)
        gen = len(led)
        done = [r for r in led if r.get("completion_ms", "") != ""]
        on_time = sum(1 for r in led if r.get("final_status") == "ON_TIME")
        e2e = [float(r["e2e_latency_ms"]) for r in done if r.get("e2e_latency_ms", "") != ""]
        return dict(n=len(tasks), reward=mean_or_nan([x["reward"]["reward"] for x in tasks]),
                    latency=mean_or_nan(lat), miss=100.0 * mean_or_nan([x["reward"]["deadline_miss"] for x in tasks]),
                    mix="/".join(str(mix[k]) for k in ("Local", "Edge", "Cloud")),
                    generated=gen, completed_pct=100.0 * len(done) / gen if gen else float("nan"),
                    on_time_gen_pct=100.0 * on_time / gen if gen else float("nan"), e2e=mean_or_nan(e2e))

    pols = ["eval"] + baselines
    pname = lambda p: "agent" if p == "eval" else p
    rname = lambda p, t, w: f"eval-{label(t, w)}" if p == "eval" else f"base-{p}-{label(t, w)}"
    res = {}
    for (t, w) in keys:
        for p in pols:
            res[(t, w, p)] = stats(rname(p, t, w))

    # pairing check: every policy must have seen the same generated tasks
    unpaired = []
    for (t, w) in keys:
        ref = None
        for p in pols:
            led = ledger(rname(p, t, w))
            sig = sorted((r["task_id"], r["generated_ms"]) for r in led)
            if ref is None:
                ref = sig
            elif sig != ref:
                unpaired.append((t, w, p))
    print("\nPAIRING: " + ("OK, every policy saw the same generated tasks on every (topology, workload seed)" if not unpaired
                           else "NOT PAIRED for " + ", ".join(f"{label(t, w)}:{pname(p)}" for t, w, p in unpaired)))

    # ------------------------------------------------------------------ 4) tables
    print("\nmean reward per task on UNSEEN topologies (higher is better); agent mix = Local/Edge/Cloud task counts")
    print(f"{'pair':>12} " + " ".join(f"{pname(p):>9}" for p in pols) + "   best      agent mix")
    rows = []
    for (t, w) in keys:
        best = max(pols, key=lambda p: (res[(t, w, p)]["reward"] if not math.isnan(res[(t, w, p)]["reward"]) else -1e18))
        print(f"{label(t, w):>12} " + " ".join(f"{res[(t, w, p)]['reward']:9.3f}" for p in pols)
              + f"   {pname(best):8s}  {res[(t, w, 'eval')]['mix']}")
        for p in pols:
            r = res[(t, w, p)]
            rows.append(dict(topology_seed=t, workload_seed=("" if w is None else w), policy=pname(p), **r))

    topo_mean = {p: [mean_or_nan([res[(t, w, p)]["reward"] for (t2, w) in keys if t2 == t]) for t in test] for p in pols}
    print("\nper policy over all pairs (topology is the unit of generalisation: SE is across topologies)")
    print(f"{'policy':>9} {'reward':>9} {'SE':>7} {'ontime/gen%':>12} {'completed%':>11} {'meanE2E':>9}")
    for p in pols:
        ot = mean_or_nan([res[(t, w, p)]["on_time_gen_pct"] for (t, w) in keys])
        cp_ = mean_or_nan([res[(t, w, p)]["completed_pct"] for (t, w) in keys])
        e2e = mean_or_nan([res[(t, w, p)]["e2e"] for (t, w) in keys])
        print(f"{pname(p):>9} {mean_or_nan(topo_mean[p]):9.3f} {se(topo_mean[p]):7.3f} {ot:12.1f} {cp_:11.1f} {e2e:9.2f}")
    print("  (reward counts only tasks that finished before the cutoff: compare it together with completed% and ontime/gen%)")

    paired = []
    if baselines:
        print("\nPAIRED difference agent - baseline (same topology, same workload); positive = agent better")
        print(f"{'baseline':>9} {'mean diff':>10} {'SE(topo)':>9} {'win rate':>9} {'pairs':>6}")
        for b in baselines:
            d_pairs = [res[(t, w, "eval")]["reward"] - res[(t, w, b)]["reward"] for (t, w) in keys]
            d_pairs = [x for x in d_pairs if not math.isnan(x)]
            d_topo = [mean_or_nan([res[(t, w, "eval")]["reward"] - res[(t, w, b)]["reward"] for (t2, w) in keys if t2 == t]) for t in test]
            win = 100.0 * sum(1 for x in d_pairs if x > 0) / len(d_pairs) if d_pairs else float("nan")
            print(f"{b:>9} {mean_or_nan(d_pairs):10.3f} {se(d_topo):9.3f} {win:8.1f}% {len(d_pairs):6d}")
            paired.append(dict(baseline=b, mean_diff=mean_or_nan(d_pairs), se_across_topologies=se(d_topo),
                               win_rate_pct=win, pairs=len(d_pairs)))

    # ------------------------------------------------------------------ 5) epsilon review from the real training decisions
    D = sum(decisions_in(f"train-t{s}") for s in train)
    S = int(eps_steps) if eps_steps else int(agent_cfg.get("epsilon_decay_steps", 16000))
    frac = min(1.0, D / S)
    eps_end_train = eps0 + (eps1 - eps0) * frac
    avg_eps = (eps0 + eps_end_train) / 2 if D <= S else (S / D) * (eps0 + eps1) / 2 + (1 - S / D) * eps1
    rec = max(1, int(round(0.5 * D)))
    print(f"\nEPSILON REVIEW: training decisions D={D}, epsilon_decay_steps S={S}, schedule {eps0} -> {eps1} (linear in decisions)")
    print(f"  epsilon reached at the end of training = {eps_end_train:.3f}; average epsilon over training = {avg_eps:.3f}")
    if D < 0.5 * S:
        print(f"  WARNING: S is more than 2x D, epsilon is still {eps_end_train:.2f} when training stops (the agent never gets to exploit). "
              f"Suggested S ~ {rec} (= 0.5 x D), or use --epsilon-decay-steps auto.")
    elif D > 4 * S:
        print(f"  NOTE: the schedule ends after {100.0 * S / D:.0f}% of the training decisions; the remaining decisions run at epsilon={eps1}. "
              f"Suggested S ~ {rec} (= 0.5 x D) if you want exploration spread over more topologies.")
    else:
        print(f"  OK: exploration is spread over {100.0 * min(1.0, S / D):.0f}% of the training decisions. (S = 0.5 x D would be {rec}.)")

    with open(os.path.join(out, "summary.csv"), "w", newline="", encoding="utf-8") as f:
        w_ = csv.DictWriter(f, fieldnames=["topology_seed", "workload_seed", "policy", "n", "reward", "latency", "miss", "mix",
                                           "generated", "completed_pct", "on_time_gen_pct", "e2e"])
        w_.writeheader()
        w_.writerows(rows)
    if paired:
        with open(os.path.join(out, "paired_summary.csv"), "w", newline="", encoding="utf-8") as f:
            w_ = csv.DictWriter(f, fieldnames=list(paired[0]))
            w_.writeheader()
            w_.writerows(paired)
    print(f"\nfiles: {os.path.join(out, 'summary.csv')}" + (", paired_summary.csv" if paired else "")
          + f", models model_after_t*.json (+ .topologies.json ledgers), logs in {logs}")


if __name__ == "__main__":
    sys.exit(main())
