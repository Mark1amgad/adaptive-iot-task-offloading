# ربط iFogSim2 مع موديل Q-Learning (Local / Edge / Cloud)

> **الحالة:** الكود اتكتب واتعمله compile فقط. **ماتشغّلش في simulation ولا اتختبر.** كل الافتراضات تحت محتاجة مراجعة قبل الاعتماد على أي نتيجة.

## اللي اتغيّر في المشروع
| ملف | التغيير |
|---|---|
| `src/org/fog/offloading/RLClient.java` (جديد) | بيشغّل عملية بايثون ويكلمها بسطور JSON (timeout + قراءة stderr). |
| `src/org/fog/offloading/RLOffloadingManager.java` (جديد) | بيبني الـ observation، ويطبّق الـ action، ويبعت الـ outcome، ويقفل العملية. |
| `src/org/fog/entities/FogDevice.java` | إضافة hook في `processTupleArrival` وhook في `checkCloudletCompletion` + 4 دوال مساعدة `rl*`. |
| `src/org/fog/placement/Controller.java` | سطر واحد في `STOP_SIMULATION` بيقفل الجلسة ويحفظ الموديل. |
| `rl_model/` (جديد) | مجلد الموديل بايثون كامل (الكود، config، docs). |

**مطفي افتراضياً:** من غير `-Drl.enabled=true` كل الـ hooks مابتعملش حاجة، والمحاكاة بتشتغل زي الأول بالظبط.

## التشغيل
متطلبات: Python 3.10+ على الجهاز (الموديل مش محتاج مكتبات خارجية).

أضف خيارات الـ JVM لأي مثال (Eclipse/IntelliJ: VM options):
```
-Drl.enabled=true -Drl.mode=train -Drl.runId=train-seed1 -Drl.phase=train -Drl.simSeed=1 -Drl.modelOut=rl_model/artifacts/train_seed1.json -Drl.deadlineMs=500
```
- **Train:** `-Drl.mode=train` (استكشاف ε-greedy + تعلّم). لمتابعة تدريب: `-Drl.modelIn=...`.
- **تقييم:** `-Drl.mode=eval -Drl.modelIn=... -Drl.phase=test` (موديل متجمّد).
- **Baseline:** `-Drl.mode=baseline -Drl.policy=local|edge|cloud|random -Drl.phase=test`.
- باقي الخيارات: `rl.python` (الافتراضي `python`)، `rl.home` (الافتراضي `rl_model`، نسبةً لمجلد التشغيل)، `rl.timeoutMs` (10000)، `rl.agentSeed`، `rl.reportPendingAsFailed=true`.
- شغّل الـ JVM من مجلد المشروع الرئيسي عشان `rl_model` يتلاقى.
- النتائج بتتكتب في `rl_model/logs/run_<runId>.jsonl`، والمقارنة: `python -m rl_model.aggregate logs/run_*.jsonl` (راجع `rl_model/docs/WORKFLOWS.md`).

## إزاي القرار بيتطبّق
القرار بيتاخد لكل tuple جاي من **Sensor** لأول جهاز يوصله (gateway / mobile):

| Action | اللي بيحصل |
|---|---|
| **Local** | بيكمّل المعالجة العادية على نفس الجهاز. |
| **Edge** | `sendUp(tuple)` للجهاز الأب (بنموذج الـ link الأصلي: queue وbandwidth وlatency). |
| **Cloud** | إرسال مباشر لأعلى الشجرة، بجمع (latency + حجم/bandwidth) لكل hop. |

- الـ action بيتحط في الـ mask بس لو الجهاز المستهدف **فيه نسخة من الـ module** المطلوب. لو أقل من خيارين متاحين، الموديل مابيتدخلش وبيشتغل الـ placement الأصلي.
- **عشان يبقى فيه اختيار حقيقي** لازم الـ module الأول يتحط على أكتر من طبقة، مثلاً بـ `ModuleMapping.addModuleToDevice(moduleName, deviceName)` مع `ModulePlacementMapping` لجهاز الـ gateway وجهاز الـ edge والـ cloud.
- لو الأب هو الـ cloud نفسه (طبقتين)، الـ Edge بيتشال من الـ mask.

## الـ observation (قبل التنفيذ) والـ outcome (بعد التنفيذ)
| الحقل | المصدر في الكود |
|---|---|
| `task_mi` | `tuple.getCloudletLength()` |
| `wan_latency_ms` | مجموع `getUplinkLatency()` من الجهاز لأعلى الشجرة |
| `edge_utilization` | `rlCpuUtilization()` للجهاز الأب لحظة القرار |
| `deadline_ms` | **ثابت** من `-Drl.deadlineMs` (iFogSim مفيهوش deadline للـ tuple) |
| `latency_ms` (outcome) | `CloudSim.clock()` عند اكتمال التنفيذ − لحظة القرار |
| `bandwidth_bytes` | `getCloudletFileSize()` لو اتنفّذ بره الجهاز، وصفر لو Local |
| `executing_node_utilization` | استخدام CPU للجهاز اللي نفّذ لحظة الاكتمال |
| `action_executed` | بيتحدد من الجهاز اللي نفّذ فعلاً (نفس الجهاز = Local، جهاز بدون أب = Cloud، غير كده = Edge) |

## افتراضات وحدود (لازم تتراجع)
1. وحدة الزمن في iFogSim اتعاملت كأنها **ms** (`wan_latency_ms` و`latency_ms`). تأكد من topology بتاعتكم.
2. الـ deadline ثابت لكل الـ tasks. لو عندكم deadline حقيقي لكل app أو tuple، عدّل `RLOffloadingManager.tryOffload`.
3. الـ latency بتتحسب لحد اكتمال تنفيذ **أول module فقط** (مش الـ loop كله) وبتبدأ من وصول الـ tuple للجهاز الأول (من غير زمن الـ sensor→gateway).
4. الـ Cloud بيتبعت مباشرة بحساب الـ delay، من غير طابور الـ link (`northTupleQueue`). الـ Edge بيستخدم الطابور الأصلي، فالمقارنة فيها تحيّز بسيط.
5. `energy_joules` مش بيتبعت (اختياري في config الموديل).
6. الـ tuples اللي لسه شغّالة في آخر المحاكاة بتتسجّل `unreported` (مش فاشلة) إلا لو فعّلت `-Drl.reportPendingAsFailed=true`. الـ tuples اللي iFogSim بيرميها بدون ما تكمل بتتحسب نفس الشكل.
7. مسارات الـ mobility/clustering/microservices ما اتفحصتش.
8. الـ thresholds اللي علامتها `placeholder` في `rl_model/config/default.json` لازم تتظبط من الـ workload الحقيقي (راجع `rl_model/docs/BLOCKERS.md`).
9. أي خطأ أو timeout من بايثون: الكود بيرجع للسلوك الأصلي لـ iFogSim، وبعد 3 أخطاء I/O متتالية بيقفل الـ RL.
10. `Controller` بيعمل `System.exit(0)` عند `STOP_SIMULATION`؛ عشان كده الإغلاق بيتم قبله وكمان بـ shutdown hook.

---

# سيناريو جاهز: 4 IoT ← 2 Edge ← Cloud

الملف: `src/org/fog/test/perfeval/EdgeCloudOffloadingRL.java` (مثال جديد، مابيغيّرش أي مثال قديم).

```
IoT 1 + IoT 2 → Edge 1 ─(WAN 40ms)─┐
                                   ├→ Cloud
IoT 3 + IoT 4 → Edge 2 ─(WAN 120ms)┘
```
- كل جهاز IoT عنده 3 sensors (tasks صغيرة 200 MI، متوسطة 1000، كبيرة 4000) بأزمنة وصول عشوائية مرتبطة بـ `-Drl.simSeed` (تتكرر بنفس الـ seed).
- الـ module الوحيد `processing` موجود على **كل** الأجهزة (IoT وEdge وCloud)، فكل task ليها 3 اختيارات.
- من غير RL: كل الـ tasks بتتنفّذ Local (سلوك iFogSim العادي).
- كل الأرقام (MIPS، latency، أحجام الـ tasks، فترات الوصول) **قيم تجريبية للتطوير**، مش معايرة لدراسة حقيقية.

## التشغيل
Main class: `org.fog.test.perfeval.EdgeCloudOffloadingRL`، وخيارات الـ JVM (استبدل المسار بمسارك):
```
-Drl.enabled=true "-Drl.home=D:/computer network research/iFogSim2 (The New Version)/rl_model"
"-Drl.config=D:/computer network research/iFogSim2 (The New Version)/rl_model/config/edge_cloud_scenario.json"
-Drl.python=python -Drl.mode=train -Drl.runId=train-seed1 -Drl.phase=train -Drl.simSeed=1 -Drl.deadlineMs=80
"-Drl.modelOut=D:/computer network research/iFogSim2 (The New Version)/rl_model/artifacts/model.json"
```
- مدة المحاكاة: `-Dsim.time=20000` (الافتراضي 20000 وحدة زمن iFogSim).
- **التقييم:** `-Drl.mode=eval -Drl.phase=test -Drl.simSeed=<seed مختلف> -Drl.modelIn=...model.json`
- **Baselines:** `-Drl.mode=baseline -Drl.policy=local|edge|cloud -Drl.phase=test -Drl.simSeed=<نفس seed التقييم>`
- بعد التشغيلات: `python -m rl_model.aggregate logs/run_*.jsonl --train-seeds 1` من داخل `rl_model` (مع `PYTHONPATH=src`).

`config/edge_cloud_scenario.json` هو config الموديل الخاص بالسيناريو ده: 27 state (task × WAN × Edge)، وفيه `deadline_ms` معطّل لأن الـ deadline ثابت.

## اللي اتجرّب فعلاً وبنتيجته
تشغيل قصير (3000 وحدة زمن) في 4 أوضاع: بدون RL، train، eval، baseline (edge وcloud). كلها اشتغلت بدون أخطاء، بـ `fallbacks=0`، وكل الـ tasks المكتملة اتبعتت لبايثون واتسجّلت. ده **اختبار تشغيل (smoke test) بس**، والأرقام اللي طلعت منه مش نتائج بحثية.

## ملاحظات مهمة طلعت من التشغيل
1. **`edge_utilization` بتاخد قيمتين بس (0 أو 1):** `getUtilizationOfCpu()` في iFogSim بترجع 1 لو فيه task شغّالة و0 لو لأ، فمش مقياس تدريجي للحمل. الـ state بيشتغل بيها، بس معلومتها خشنة. لو عايز مقياس أدق (مثلاً عدد الـ tasks الجارية على الـ Edge) قولّي.
2. **الـ deadline ثابت** (80 افتراضياً) فمفيش داعي للـ feature بتاعته.
3. **tasks بتفضل غير مكتملة في آخر المحاكاة** (حوالي 0.3% في Local/Edge، وأكتر مع Cloud-only لأن الـ WAN بطيء). بتظهر `unreported` في آخر الـ console ومابتتحسبش ضمن النتائج، إلا لو فعّلت `-Drl.reportPendingAsFailed=true`.
4. الأرقام الأولية من تشغيلة التدريب القصيرة اتشافت (ممارسة استكشاف عشوائي)، فمتعتمدش عليها. التدريب الحقيقي محتاج `sim.time` أطول.
