package org.fog.offloading;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.fog.entities.FogDevice;
import org.fog.entities.Tuple;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Connects iFogSim to the Python Q-learning agent (rl_model).
 *
 * Decision point : a tuple emitted by a Sensor arrives at its first device (FogDevice.processTupleArrival).
 * Actions        : LOCAL = keep normal processing on that device,
 *                  EDGE  = send the tuple up to the parent device (normal link model, sendUp),
 *                  CLOUD = send it directly to the top of the tree (sum of per-hop delays).
 * Outcome        : reported when the tuple's execution completes (FogDevice.checkCloudletCompletion).
 *
 * DISABLED by default (existing simulations are unchanged). Enable with -Drl.enabled=true.
 * See RL_OFFLOADING.md at the project root. Every error falls back to iFogSim's normal behaviour.
 */
public final class RLOffloadingManager {
    public static final int LOCAL = 0, EDGE = 1, CLOUD = 2;
    private static final String[] NAMES = {"Local", "Edge", "Cloud"};
    private static final String V = "1.0";

    private static volatile boolean enabled = Boolean.getBoolean("rl.enabled");
    private static RLOffloadingManager instance;

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean on) {
        enabled = on;
    }

    public static synchronized RLOffloadingManager getInstance() {
        if (instance == null) instance = new RLOffloadingManager();
        return instance;
    }

    /** Called from Controller on STOP_SIMULATION and by a JVM shutdown hook; idempotent. */
    public static void finishIfEnabled() {
        if (instance != null) instance.finish();
    }

    private static final class Pending {
        int entryDeviceId;
        int decidedAction;
        double decisionTime;
        double deadlineMs;
        double fileSize;
    }

    private final Map<Integer, Pending> pending = new HashMap<Integer, Pending>();
    private final JSONParser parser = new JSONParser();
    private RLClient client;
    private boolean active = false;
    private boolean finished = false;
    private int ioFailures = 0;
    private long decisions = 0, outcomes = 0, fallbacks = 0;
    private final double defaultDeadlineMs = Double.parseDouble(System.getProperty("rl.deadlineMs", "1000"));
    private final boolean pendingAsFailed = Boolean.getBoolean("rl.reportPendingAsFailed");
    private boolean warnedDeadline = false;

    private RLOffloadingManager() {
        try {
            start();
            Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
                public void run() {
                    finish();
                }
            }, "rl-finish"));
        } catch (Exception e) {
            System.err.println("[rl] could not start the Python agent, using default iFogSim behaviour: " + e);
            active = false;
        }
    }

    // ------------------------------------------------------------------ startup
    private void start() throws IOException {
        File home = new File(System.getProperty("rl.home", "rl_model")).getAbsoluteFile();
        String python = System.getProperty("rl.python", "python");
        String mode = System.getProperty("rl.mode", "train");
        String runId = System.getProperty("rl.runId", "run-" + System.currentTimeMillis());
        String phase = System.getProperty("rl.phase", "dev");
        long timeout = Long.parseLong(System.getProperty("rl.timeoutMs", "10000"));

        List<String> cmd = new ArrayList<String>();
        cmd.add(python);
        cmd.add("-m");
        cmd.add("rl_model.server");
        cmd.add("--config");
        cmd.add(abs("rl.config", new File(home, "config/default.json").getPath()));
        cmd.add("--mode");
        cmd.add(mode);
        if ("baseline".equals(mode)) {
            cmd.add("--policy");
            cmd.add(System.getProperty("rl.policy", "edge"));
        }
        if (System.getProperty("rl.modelIn") != null) {
            cmd.add("--model-in");
            cmd.add(abs("rl.modelIn", null));
        }
        if (System.getProperty("rl.modelOut") != null) {
            cmd.add("--model-out");
            cmd.add(abs("rl.modelOut", null));
        }
        cmd.add("--log-dir");
        cmd.add(abs("rl.logDir", new File(home, "logs").getPath()));
        cmd.add("--artifacts-dir");
        cmd.add(abs("rl.artifactsDir", new File(home, "artifacts").getPath()));
        if (System.getProperty("rl.agentSeed") != null) {
            cmd.add("--seed");
            cmd.add(System.getProperty("rl.agentSeed"));
        }
        Map<String, String> env = new HashMap<String, String>();
        env.put("PYTHONPATH", new File(home, "src").getPath());
        env.put("PYTHONUNBUFFERED", "1");
        client = new RLClient(cmd, home, env, timeout);

        JSONObject hello = msg("hello");
        hello.put("run_id", runId);
        hello.put("phase", phase);
        if (System.getProperty("rl.simSeed") != null) hello.put("sim_seed", Long.valueOf(System.getProperty("rl.simSeed")));
        JSONObject sim = new JSONObject();
        sim.put("name", "iFogSim2");
        sim.put("version", "unknown");
        hello.put("simulator", sim);
        JSONObject ack = call(hello);
        if (ack == null || !"hello_ack".equals(ack.get("type"))) {
            throw new IOException("handshake failed: " + (ack == null ? "no reply" : ack.toJSONString()));
        }
        active = true;
        System.err.println("[rl] agent ready: " + ack.toJSONString());
    }

    private static String abs(String prop, String dflt) {
        String p = System.getProperty(prop, dflt);
        return new File(p).getAbsolutePath();
    }

    // ------------------------------------------------------------------ decision
    /**
     * @return true if the tuple was forwarded elsewhere (caller must stop processing it);
     *         false to continue with the normal local flow (action LOCAL, or any fallback).
     */
    public boolean tryOffload(FogDevice dev, Tuple tuple) {
        if (!active || finished || tuple.getDestModuleName() == null) return false;
        try {
            FogDevice parent = dev.getParentId() > 0 ? (FogDevice) CloudSim.getEntity(dev.getParentId()) : null;
            FogDevice cloud = topOf(dev);
            String app = tuple.getAppId(), mod = tuple.getDestModuleName();
            boolean localOk = dev.rlHostsModule(app, mod);
            boolean cloudOk = cloud != null && cloud != dev && cloud.rlHostsModule(app, mod);
            boolean edgeOk = parent != null && parent != cloud && parent.rlHostsModule(app, mod);
            if (((localOk ? 1 : 0) + (edgeOk ? 1 : 0) + (cloudOk ? 1 : 0)) < 2) {
                return false;      // nothing to choose between: leave iFogSim's own placement alone
            }
            if (!warnedDeadline) {
                warnedDeadline = true;
                System.err.println("[rl] WARNING: iFogSim tuples carry no deadline; using constant rl.deadlineMs="
                        + defaultDeadlineMs + " (TO CONFIRM)");
            }

            JSONObject f = new JSONObject();
            f.put("task_mi", num(tuple.getCloudletLength()));
            f.put("wan_latency_ms", num(pathLatency(dev, cloud)));
            f.put("edge_utilization", num(parent != null ? parent.rlCpuUtilization() : 0.0));
            f.put("deadline_ms", num(defaultDeadlineMs));
            JSONArray avail = new JSONArray();
            if (localOk) avail.add(NAMES[LOCAL]);
            if (edgeOk) avail.add(NAMES[EDGE]);
            if (cloudOk) avail.add(NAMES[CLOUD]);
            JSONObject o = msg("observation");
            o.put("task_id", tid(tuple));
            o.put("sim_time_ms", num(CloudSim.clock()));
            o.put("features", f);
            o.put("available_actions", avail);

            JSONObject r = call(o);
            if (r == null || !"action".equals(r.get("type")) || !tid(tuple).equals(r.get("task_id"))) {
                fallbacks++;
                if (r != null) System.err.println("[rl] agent error, default behaviour used: " + r.toJSONString());
                return false;
            }
            int action = ((Number) r.get("action_id")).intValue();
            if (action < 0 || action > 2 || !allowed(action, localOk, edgeOk, cloudOk)) {
                fallbacks++;
                return false;
            }
            Pending p = new Pending();
            p.entryDeviceId = dev.getId();
            p.decidedAction = action;
            p.decisionTime = CloudSim.clock();
            p.deadlineMs = defaultDeadlineMs;
            p.fileSize = tuple.getCloudletFileSize();
            pending.put(tuple.getCloudletId(), p);
            decisions++;

            if (action == EDGE) {
                dev.rlSendUp(tuple);
                return true;
            }
            if (action == CLOUD) {
                dev.rlSendDirect(cloud.getId(), tuple);
                return true;
            }
            return false;           // LOCAL
        } catch (RuntimeException e) {
            fallbacks++;
            System.err.println("[rl] unexpected error in tryOffload, default behaviour used: " + e);
            return false;
        }
    }

    private static boolean allowed(int a, boolean l, boolean e, boolean c) {
        return (a == LOCAL && l) || (a == EDGE && e) || (a == CLOUD && c);
    }

    // ------------------------------------------------------------------ outcome
    /** Called when the tuple finished executing on 'executedOn'. Ignores tuples that were never decided. */
    public void onTupleCompleted(FogDevice executedOn, Tuple tuple) {
        Pending p = pending.remove(tuple.getCloudletId());
        if (p == null || !active) return;
        double latency = CloudSim.clock() - p.decisionTime;
        int executedAction = executedOn.getId() == p.entryDeviceId ? LOCAL
                : (executedOn.getParentId() <= 0 ? CLOUD : EDGE);
        JSONObject rm = new JSONObject();
        rm.put("bandwidth_bytes", num(executedAction == LOCAL ? 0.0 : p.fileSize));
        rm.put("executing_node_utilization", num(executedOn.rlCpuUtilization()));
        JSONObject o = msg("outcome");
        o.put("task_id", tid(tuple));
        o.put("action_executed", NAMES[executedAction]);
        o.put("status", "completed");
        o.put("latency_ms", num(latency));
        o.put("deadline_met", Boolean.valueOf(latency <= p.deadlineMs));
        o.put("resource_metrics", rm);
        o.put("terminal", Boolean.TRUE);
        o.put("sim_time_ms", num(CloudSim.clock()));
        JSONObject r = call(o);
        outcomes++;
        if (r != null && "error".equals(r.get("type"))) {
            System.err.println("[rl] outcome rejected: " + r.toJSONString());
        }
    }

    // ------------------------------------------------------------------ end
    public synchronized void finish() {
        if (finished) return;
        finished = true;
        if (client == null) return;
        if (active && pendingAsFailed) {
            for (Map.Entry<Integer, Pending> e : pending.entrySet()) {
                Pending p = e.getValue();
                JSONObject rm = new JSONObject();
                rm.put("bandwidth_bytes", num(p.decidedAction == LOCAL ? 0.0 : p.fileSize));
                JSONObject o = msg("outcome");
                o.put("task_id", "t-" + e.getKey());
                o.put("action_executed", NAMES[p.decidedAction]);
                o.put("status", "failed");
                o.put("failure_reason", "not_completed_by_simulation_end");
                o.put("latency_ms", null);
                o.put("deadline_met", Boolean.FALSE);
                o.put("resource_metrics", rm);
                call(o);
            }
        }
        if (active) {
            JSONObject r = call(msg("shutdown"));
            System.err.println("[rl] finished: decisions=" + decisions + " outcomes=" + outcomes
                    + " fallbacks=" + fallbacks + " unreported=" + pending.size()
                    + (r != null ? " ack=" + r.toJSONString() : ""));
        }
        active = false;
        client.close();
    }

    // ------------------------------------------------------------------ helpers
    private JSONObject call(JSONObject m) {
        try {
            String line = client.request(m.toJSONString());
            ioFailures = 0;
            return (JSONObject) parser.parse(line);
        } catch (IOException e) {
            System.err.println("[rl] I/O problem: " + e.getMessage());
            if (++ioFailures >= 3) {
                System.err.println("[rl] too many failures: RL disabled, default iFogSim behaviour from now on");
                active = false;
            }
            return null;
        } catch (ParseException e) {
            System.err.println("[rl] unparsable reply: " + e);
            return null;
        }
    }

    private static JSONObject msg(String type) {
        JSONObject m = new JSONObject();
        m.put("protocol_version", V);
        m.put("type", type);
        return m;
    }

    private static String tid(Tuple t) {
        return "t-" + t.getCloudletId();
    }

    private static Double num(double x) {
        if (Double.isNaN(x) || Double.isInfinite(x) || x < 0) return Double.valueOf(0.0);
        return Double.valueOf(x);
    }

    /** Top of the tree reached by following parent ids (the cloud in the usual topologies). */
    private static FogDevice topOf(FogDevice dev) {
        FogDevice cur = dev;
        while (cur.getParentId() > 0) {
            SimEntity next = CloudSim.getEntity(cur.getParentId());
            if (!(next instanceof FogDevice)) break;
            cur = (FogDevice) next;
        }
        return cur;
    }

    /** Sum of uplink latencies from 'from' up to 'to' (iFogSim clock units, taken as ms). */
    static double pathLatency(FogDevice from, FogDevice to) {
        double sum = 0;
        FogDevice cur = from;
        while (cur != null && cur != to && cur.getParentId() > 0) {
            sum += cur.getUplinkLatency();
            SimEntity next = CloudSim.getEntity(cur.getParentId());
            cur = (next instanceof FogDevice) ? (FogDevice) next : null;
        }
        return sum;
    }
}
